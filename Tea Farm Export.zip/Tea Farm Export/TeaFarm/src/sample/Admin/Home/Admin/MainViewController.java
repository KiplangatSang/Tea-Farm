package sample.Admin.Home.Admin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;

import jdk.nashorn.internal.ir.WhileNode;
import sample.Admin.Chatroom.ViewPosts.PostsView;
import sample.Admin.Employee.Admin.RegisterEmployeeView;
import sample.Admin.Expenses.Admin.ExpensesView;
import sample.Admin.Fertilizer.Admin.FertilizerView;
import sample.Admin.Login.Admin.AdminLoginView;
import sample.Admin.Machinery.MachineryView;
import sample.Admin.Profit.ProfitView;
import sample.Admin.Sales.Admin.SalesView;
import sample.Admin.Seedlings.Admin.SeedlingsView;
import sample.DatabaseConnections.CreateDBTables.CreateDatabase;
import sample.DatabaseConnections.DBConnection;


import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ResourceBundle;


public class MainViewController implements Initializable {
    @FXML
    private MenuBar file;

    @FXML
    private MenuItem logoutmi;

    @FXML
    private MenuItem refreshmi;

    @FXML
    private Label datelb;

    @FXML
    private ComboBox<String> monthSelectioncb;

    @FXML
    private ComboBox<Integer> yearselectcb;

    @FXML
    private ComboBox<String> graphitemcb;

    @FXML
    private HBox linechartHBox;

    @FXML
    private Button employeebtn;

    @FXML
    private Button fertilizerbtn;

    @FXML
    private Button chatsbtn;

    @FXML
    private Button seedlingsbtn;

    @FXML
    private Button Expensesbtn;

    @FXML
    private Button machinerybtn;

    @FXML
    private Button salesbtn;

    @FXML
    private Button profitbtn;

    @FXML
    private LineChart<String, Integer> profitgraph;

    @FXML
    private CategoryAxis xAxisGraph;

    @FXML
    private NumberAxis yAxisGraph;

    @FXML
    private ListView<String> requiredfertilizerlv;

    @FXML
    private ListView<String> seedlingslv;

    @FXML
    private ListView<String> brokenmachinerylv;

    @FXML
    private Label profitlb;

    @FXML
    private Label expenselb;

    @FXML
    private Label saleslb;


    ObservableList<String> distinctdates;

    CreateDatabase dbcreater;
    DBConnection do1;


    String month,today;
    int dayOfMonth, dayOfYear, year;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
         do1 = new DBConnection();
        getDateTime();
        loadButtonActions();
        setdatelabel();
        try {
            setComboboxes();
            setData( year,month);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }


    //set date labels
    private void setdatelabel() {
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("E,MMM dd yyyy");
        String formattedDate = myDateObj.format(myFormatObj);
        datelb.setText(formattedDate);
    }


    //Button Actions
    public void loadButtonActions() {
      salesbtn.setOnAction(e -> new SalesView().display("Sales"));
       profitbtn.setOnAction(e -> new ProfitView().display("Profits"));
       machinerybtn.setOnAction(e -> new MachineryView().display("Machinery"));
        seedlingsbtn.setOnAction(e -> new SeedlingsView().display("Seedling Sales"));
        chatsbtn.setOnAction(e -> new PostsView().display("Chat Platform"));
       employeebtn.setOnAction(e -> new RegisterEmployeeView().display("Register Employee"));
      Expensesbtn.setOnAction(e -> new ExpensesView().display("Internal Expenses"));



        fertilizerbtn.setOnAction(e -> new FertilizerView().display("Fertilizer"));


        monthSelectioncb.setOnAction(e -> {
            try {
                getSelectedmonthdata();
            } catch (SQLException throwables) {
                try {
                    getSelectedyeardata();
                } catch (SQLException sqlException) {
                    sqlException.printStackTrace();
                }
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e-> {
            try {
                profitgraph.getData().clear();
                monthSelectioncb.setValue("");
                getSelectedyeardata();
                selectMonthsFromDB();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });

        graphitemcb.setOnAction(e->
        {
            try {
                setSelectedgraph();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
                );

        refreshmi.setOnAction(e->refresh());
        logoutmi.setOnAction(e->logout());
    }

    //Logout
    private void logout(){

       MainView.closeWindow();
        new AdminLoginView().display("Admin Login");
    }

    //Refresh
    private void refresh(){

        MainView.closeWindow();
        new MainView().display("Tea Farm Management");
    }

    //set comboboxes
    private void setComboboxes(){
        try {
            setYearselectcb( "companysales");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        selectMonthsFromDB();
        setGraphitemcb();

    }



    public Month getDateTime() {
        LocalDate currentDate = LocalDate.now();
        DayOfWeek dow = currentDate.getDayOfWeek();
        int dom = currentDate.getDayOfMonth();
        int doy = currentDate.getDayOfYear();
        Month m = currentDate.getMonth();
        year = currentDate.getYear();
        month = m.toString();
        today = currentDate.now().toString();


        this.dayOfMonth = dom;
        this.dayOfYear = doy;

        return m;
    }

    //getting distinct dates from db
    //getting distinct dates from db
    //getting months of data

    private void setYearselectcb(String Database) throws SQLException {
        ObservableList distinctyears =FXCollections.observableArrayList();
        Connection conn = do1.connect();
        String query = "Select distinct(year) from "+Database;
        System.out.println(query);
        ResultSet rs = conn.createStatement().executeQuery(query);
        while (rs.next()) {
            distinctyears.add(rs.getInt(1));
        }
        rs.close();
        conn.close();
        yearselectcb.getItems().addAll(distinctyears);

    }

    private void selectMonthsFromDB() {

        distinctdates = FXCollections.observableArrayList();
        this.distinctdates.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );

        setMonthSelectcb(distinctdates);
    }
    //adding months of data to combobox
    private void setMonthSelectcb(ObservableList monthlist){
        monthSelectioncb.setItems(monthlist);
    }


    //getting selected time data
    //getting selected month data
    private void getSelectedmonthdata() throws SQLException {
        profitgraph.getData().clear();

        try{
            int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
            String  selectedMonth = monthSelectioncb.getValue().toString();
            setData(selectedyear,selectedMonth);
        }
        catch(Exception e){
      if(monthSelectioncb.getValue()!= null){
            int selectedyear = this.year;
            String  selectedMonth = monthSelectioncb.getValue().toString();
            setData(selectedyear,selectedMonth);}
      else{
          getSelectedyeardata();
      }

        }
    }


    //getting selected year data
    private void getSelectedyeardata() throws SQLException {
        profitgraph.getData().clear();
        if(graphitemcb.getValue() == "" || graphitemcb.getValue() == null){
        try{
            int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
            setYearlydata( selectedyear);
        }
        catch(Exception e){

            int selectedyear = this.year;
            setYearlydata( selectedyear);
        }}
        else{
            String graph = graphitemcb.getValue();
            getSelectedgraph(  graph);
        }
    }



    //setting homeviewdata
    private void setData(int year, String month) throws SQLException {
        //graphs
        if(graphitemcb.getValue() == "" || graphitemcb.getValue() == null){
        setSalesGraph( year, month);
        setExpenseGraph( year, month);}
        else{
            String graph = graphitemcb.getValue();
            getSelectedgraph(  graph);
        }

       // labels
        setMonthlyLabels(year,month);
        //set List Views
        getListViews( year,  month);
    }



//graph data
    //setting graph combobox;
    private void setGraphitemcb(){
        graphitemcb.getItems().addAll("Sales","Expenses","All");


    }


    //setting selected graph
    private void setSelectedgraph() throws SQLException {
        String graph = graphitemcb.getValue();
        System.out.println(graph);
        getSelectedgraph(graph);
    }
    //getting selected graph
    private void getSelectedgraph( String graph) throws SQLException {
        profitgraph.getData().clear();

        if(graph == "Sales"){
            if(yearselectcb.getValue()!= null ){
                if(monthSelectioncb.getValue()!= null && monthSelectioncb.getValue() != "" ){
                int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
                String  selectedMonth = monthSelectioncb.getValue().toString();
                //graphs
                setSalesGraph( selectedyear, selectedMonth);
                }else  if(monthSelectioncb.getValue()== null && monthSelectioncb.getValue() == "" ){
                    int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
                    setSalesGraph( selectedyear);
                }

            }
            else if(yearselectcb.getValue() == null){
                if(monthSelectioncb.getValue()!= null && monthSelectioncb.getValue() != "" ){
                    int selectedyear = year;
                    String  selectedMonth = monthSelectioncb.getValue().toString();
                    //graphs
                    setSalesGraph( selectedyear, selectedMonth);
                }else{
                    setSalesGraph( year);
                }
                }
        }else if(graph == "Expenses"){

             if(yearselectcb.getValue()!= null ) {
                 if (monthSelectioncb.getValue() != null && monthSelectioncb.getValue() != "") {
                     int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
                     String selectedMonth = monthSelectioncb.getValue().toString();
                     setExpenseGraph(selectedyear, selectedMonth);
                 } else if (monthSelectioncb.getValue() == null && monthSelectioncb.getValue() == "") {

                     int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
                     setyearExpenseGraph(selectedyear);}

             }
                else if(yearselectcb.getValue() == null){
                 if (monthSelectioncb.getValue() != null && monthSelectioncb.getValue() != "") {
                     int selectedyear = year;
                     String selectedMonth = monthSelectioncb.getValue().toString();
                     setExpenseGraph(selectedyear, selectedMonth);
                 }else  if (monthSelectioncb.getValue() == null || monthSelectioncb.getValue() == ""){
                    setyearExpenseGraph( year);
                 }
                }

        }else if(graph == "All"){
            if(yearselectcb.getValue()!= null ) {
                if (monthSelectioncb.getValue() != null && monthSelectioncb.getValue() != "") {
                    int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
                    String selectedMonth = monthSelectioncb.getValue().toString();
                    setSalesGraph(selectedyear, selectedMonth);
                    setExpenseGraph(selectedyear, selectedMonth);
                } else {
                    int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
                    setSalesGraph(selectedyear);
                    setyearExpenseGraph(selectedyear);
                }
            }
                else if(yearselectcb.getValue() == null){
                if (monthSelectioncb.getValue() != null && monthSelectioncb.getValue() == "") {
                    int selectedyear = year;
                    String selectedMonth = monthSelectioncb.getValue().toString();
                    setSalesGraph(selectedyear, selectedMonth);
                    setExpenseGraph(selectedyear, selectedMonth);
                }else{
                setSalesGraph( year);
                    setyearExpenseGraph( year);
                }
                }
            }

        }


    //setting whole graph
    //sales graph
    // getting distinct dates for date sold
    private void getsalesdates(int year, String month) throws SQLException {
        distinctdates = FXCollections.observableArrayList();
        String query = "select distinct(datesold) from companysales where  month = '"+month+"' && year = '"+year+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while (rs.next()){
            distinctdates.addAll(rs.getString(1));
        }
        rs.close();
        con.close();
    }



     public void  setSalesGraph(int year,String month) throws SQLException {
         getsalesdates(year, month);
    xAxisGraph.setLabel("Date");
    yAxisGraph.setLabel("Amount in kshs");
         XYChart.Series salesSeries = new XYChart.Series();
         salesSeries.setName("Monthly Sales");
    distinctdates.forEach((date) -> {

        try{
            String salesquery = "SELECT SUM(price) from companysales where year = '"+year+"' && month = '"+month+"' && datesold = '"+date+"'";
            System.out.println(salesquery);
            Connection con= do1.connect();
            ResultSet rs = con.createStatement().executeQuery(salesquery);
            while(rs.next()){
               double sale =rs.getDouble(1);
               String  saledate = date;
               salesSeries.getData().add(new XYChart.Data(saledate,sale));

            }
        }catch (Exception e){
            e.printStackTrace();
        }
    });
    profitgraph.getData().addAll(salesSeries);
}

//setting expenses graph
// getting distinct dates for date sold
  private void getexpensedates(int year,String month) throws SQLException {
    distinctdates = FXCollections.observableArrayList();
    String query = "select distinct(datepaid) from companyexpenses where  month = '"+month+"' && year = '"+year+"'";
    Connection con = do1.connect();
    ResultSet rs = con.createStatement().executeQuery(query);
    while (rs.next()){
        distinctdates.addAll(rs.getString(1));
    }
    rs.close();
    con.close();
}

  public void  setExpenseGraph(int year,String month) throws SQLException {
      getexpensedates( year, month);
    xAxisGraph.setLabel("Date");
    yAxisGraph.setLabel("Amount in kshs");
    XYChart.Series expenseSeries = new XYChart.Series();
      expenseSeries.setName("Monthly Expenses");
    distinctdates.forEach((date) -> {

        try{
            String expensequery = "SELECT SUM(cost)  from companyexpenses where year = '"+year+"' && month = '"+month+"' && datepaid = '"+date+"'";
            System.out.println(expensequery);
            Connection con= do1.connect();
            ResultSet rs = con.createStatement().executeQuery(expensequery);
            while(rs.next()){
                double expense =rs.getDouble(1);
                String  expensedate = date;
                expenseSeries.getData().add(new XYChart.Data(expensedate,expense));

            }
        }catch (Exception e){
            e.printStackTrace();
        }


    });
    profitgraph.getData().addAll(expenseSeries);
}

    //setting profit graph
//profit graph
    /*
    public void  setprofitGraph(int year,String month) throws SQLException {
        xAxisGraph.setLabel("Date");
        yAxisGraph.setLabel("Amount in kshs");
        XYChart.Series profitSeries = new XYChart.Series();

        distinctdates.forEach((date) -> {

            try{
                String salesquery = "SELECT cost, datepaid from companysales where year = '"+year+"' and month = '"+month+"'";
                Connection con= do1.connect();
                ResultSet rs = con.createStatement().executeQuery(salesquery);
                while(rs.next()){
                    double expense =rs.getDouble(2);
                    String  expensedate = rs.getString(1);
                    profitSeries.getData().add(new XYChart.Data(expensedate,expense));


                }
            }catch (Exception e){



            }


        });
        profitgraph.getData().addAll(profitSeries);
    }
*/

    // setting yearly graph data

    private void setYearlydata(int year) throws SQLException {
        profitgraph.getData().clear();
        setSalesGraph( year);
        setyearExpenseGraph( year);
        setYearlyLabels( year);
    }

/*
    // getting distinct dates for date sold
    private void getsalesmonths(int year) throws SQLException {
        distinctdates = FXCollections.observableArrayList();
        String query = "select distinct(month) from companysales where   year = '"+year+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while (rs.next()){
            distinctdates.addAll(rs.getString(1));
        }
        rs.close();
        con.close();
    }*/



    public void  setSalesGraph(int year) throws SQLException {
        selectMonthsFromDB();
        //getsalesmonths( year);
        xAxisGraph.setLabel("Date");
        yAxisGraph.setLabel("Amount in kshs");
        XYChart.Series salesSeries = new XYChart.Series();
        salesSeries.setName("Year Sales");
        distinctdates.forEach((date) -> {

            try{
                String salesquery = "SELECT SUM(price) from companysales where year = '"+year+"' && month = '"+date+"'";
                Connection con= do1.connect();
                ResultSet rs = con.createStatement().executeQuery(salesquery);
                while(rs.next()){
                    double sale =rs.getDouble(1);
                    String  saledate = date;
                    salesSeries.getData().add(new XYChart.Data(saledate,sale));


                }
            }catch (Exception e){

             e.printStackTrace();

            }


        });
        profitgraph.getData().addAll(salesSeries);
    }

    //setting expenses graph
// getting distinct dates for date sold
    ObservableList<String> expensemonths;
    private void getexpenseMonths(int year) throws SQLException {
        expensemonths= FXCollections.observableArrayList();
        String query = "select distinct(month) from companyexpenses where  year = '"+year+"'";
        System.out.println(query);
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while (rs.next()){
            expensemonths.addAll(rs.getString(1));
        }
        rs.close();
        con.close();
    }

    public void  setyearExpenseGraph(int year) throws SQLException {

        //getexpenseMonths(year);
        selectMonthsFromDB();
        XYChart.Series expenseSeries = new XYChart.Series();
        expenseSeries.setName("Year Expenses");
        distinctdates.forEach((date) -> {
            try{
                String salesquery = "SELECT SUM(cost) from companyexpenses where year = '"+year+"' && month = '"+date+"'";
                Connection con= do1.connect();
                ResultSet rs = con.createStatement().executeQuery(salesquery);
                while(rs.next()){
                    double expense =rs.getDouble(1);
                    String  expensedate = date;
                    expenseSeries.getData().add(new XYChart.Data(expensedate,expense));


                }
            }catch (Exception e){

          e.printStackTrace();

            }


        });
        profitgraph.getData().addAll(expenseSeries);
    }


    // Labels
    double sales=0,expenses=0;
       //setting monthly labels
    private void setMonthlyLabels(int year, String month) throws SQLException {
        getSales(year,  month);
        getExpenses( year,  month);
        getProfit( sales,  expenses);

    }

    //set monthly sales lb
       private double getSales(int year, String month) throws SQLException {
           double sales = 0;
           String query = "Select SUM(price) from companysales where year = '"+year+"' && month = '"+month+"'";
           Connection con = do1.connect();
           ResultSet rs = con.createStatement().executeQuery(query);
           while(rs.next()){
               sales = rs.getDouble(1);
           }
           setSaleslb(String.valueOf(sales));
           this.sales = sales;
           return sales;
       }

    //setting sales label
    private void setSaleslb(String sales){
        saleslb.setText(sales);
    }


    //setting expenses
       private double getExpenses(int year, String month) throws SQLException {
           double expenses = 0;
           String query = "Select SUM(cost) from companyexpenses where year = '"+year+"' && month = '"+month+"'";
           Connection con = do1.connect();
           ResultSet rs = con.createStatement().executeQuery(query);
           while(rs.next()){
               expenses = rs.getDouble(1);
           }
           setExpenseslb(String.valueOf(expenses));
           this.expenses=expenses;
           return expenses;
       }

    //setting expense label
    private void setExpenseslb(String expenses){
        expenselb.setText(expenses);
    }

    //get profit
    private double getProfit(double Sales, double Expenses){
        double profit = Sales - Expenses;
      setProfitlb(String.valueOf(profit));
            return profit;
    }

    //setting profit label
    private void setProfitlb(String profit){
        profitlb.setText(profit);
    }

    // set yearly labels
    private void setYearlyLabels(int year) throws SQLException {
        getYearSales(year);
        getYearExpenses(year);
        getYearProfit( sales,  expenses);

    }

    //set monthly sales lb
    private double getYearSales(int year) throws SQLException {
        double sales = 0;
        String query = "Select SUM(price) from companysales where year = '"+year+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            sales = rs.getDouble(1);
        }
        setYearSaleslb(String.valueOf(sales));
        this.sales = sales;
        return sales;
    }

    //setting sales label
    private void setYearSaleslb(String sales){
        saleslb.setText(sales);
    }


    //setting expenses
    private double getYearExpenses(int year) throws SQLException {
        double expenses = 0;
        String query = "Select SUM(cost) from companyexpenses where year = '"+year+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            expenses = rs.getDouble(1);
        }
        setYearExpenseslb(String.valueOf(expenses));
        this.expenses=expenses;
        return expenses;
    }

    //setting expense label
    private void setYearExpenseslb(String expenses){
        expenselb.setText(expenses);
    }

    //get profit
    private double getYearProfit(double Sales, double Expenses){
        double profit = Sales - Expenses;
        setYearProfitlb(String.valueOf(profit));
        return profit;
    }

    //setting profit label
    private void setYearProfitlb(String profit){
        profitlb.setText(profit);
    }


    //setting listviews
    private void getListViews(int year, String month) {
        try {
            getBrokenMachinery();
            getRequiredfertilizer( );
            getRequiredSeedlings();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }

    //getting broken machinery
    private ObservableList getBrokenMachinery() throws SQLException {
        ObservableList<String> brokenMachinelist = FXCollections.observableArrayList();
        String query = "Select machine from companymachinery where status = 'Broken Down'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            brokenMachinelist.addAll(rs.getString(1));
        }
        setBrokenmachinerylv(brokenMachinelist);
        return brokenMachinelist;
    }

    //setting broken Machinerylv
    private void  setBrokenmachinerylv(ObservableList  brokenmachinerylist){
        brokenmachinerylv.setItems(brokenmachinerylist);

    }

    //getting required fertilizer
    private ObservableList getRequiredfertilizer() throws SQLException {
        ObservableList<String> requiredfertlist = FXCollections.observableArrayList();
        String query = "Select fertilizertype, farmerid from fertilizerorders where status = 'Allocated'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            requiredfertlist.addAll(rs.getString(1) + " for " + rs.getString(2));
        }
        setRequiredfertilizerlv(requiredfertlist);
        return requiredfertlist;
    }

    //setting required fertilizer lv
    private void  setRequiredfertilizerlv(ObservableList  brokenmachinerylist){
        requiredfertilizerlv.setItems(brokenmachinerylist);

    }



    //getting required fertilizer
    private ObservableList getRequiredSeedlings() throws SQLException {
        ObservableList<String> requiredSeedlinglist = FXCollections.observableArrayList();
        String query = "Select seedlingtype,farmerid from seedlingsorders where status = 'Allocated'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            requiredSeedlinglist.addAll(rs.getString(1) + " for " + rs.getString(2));
        }
        setSeedlingslv(requiredSeedlinglist);
        return requiredSeedlinglist;
    }

    //setting required fertilizer lv
    private void  setSeedlingslv(ObservableList brokenmachinerylist){
        seedlingslv.setItems(brokenmachinerylist);

    }

}

















