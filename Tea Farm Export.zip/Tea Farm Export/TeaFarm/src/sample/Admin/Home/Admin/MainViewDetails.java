package sample.Admin.Home.Admin;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class MainViewDetails {
    public final DoubleProperty milkPrice;
     public final DoubleProperty feedsCost;
    public final StringProperty month;

    public MainViewDetails(String month,double milkPrice,double feedsCost){
     this.month = new SimpleStringProperty(month);
        this.milkPrice = new SimpleDoubleProperty(milkPrice);
        this.feedsCost = new SimpleDoubleProperty(feedsCost);
    }

    //getters
    public String getMonth() {
        return month.get();
    }
    public double getMilkPrice() {
        return milkPrice.get();
    }


    public double getFeedsCost() {
        return feedsCost.get();
    }


    //setters
    public void setMonth(String value) {
        month.set(value);
    }
    public void setMilkPrice(double value) {
        milkPrice.set(value);
    }

    public void setFeedsCost(double value) {
        feedsCost.set(value);
    }



    public StringProperty monthProperty() {
        return month;
    }
    public DoubleProperty milkPriceProperty() {
        return milkPrice;
    }

    public DoubleProperty feedsCostProperty() {
        return feedsCost;
    }
}
