package sample.Admin.Home.Admin;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class MainView {

/*
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        try {
            Parent newroot = FXMLLoader.load(getClass().getResource("MainView.fxml"));
            primaryStage.setScene(new Scene(newroot));
            primaryStage.setTitle("Farm System");
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
*/

    public static Stage stage;
    public  void display(String title) {

        try {
            stage =new Stage();
            Parent homeroot = FXMLLoader.load(getClass().getResource("MainView.fxml"));
            stage.setScene(new Scene(homeroot));
            stage.setTitle(title);
            stage.setResizable(false);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void closeWindow(){
        stage.close();

    }


}
