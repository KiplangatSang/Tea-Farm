package sample.Admin.Machinery;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;
import sample.Admin.Expenses.Admin.ExpensesController;
import sample.Admin.Profit.ProfitController;
import sample.DatabaseConnections.DBConnection;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class MachineryController implements Initializable {

    @FXML
    private Label totalmaintenancecostlb;

    @FXML
    private Label datelabel;
    @FXML
    private Label totalmachinenolb;

    @FXML
    private ListView<String> workingmachineslv;

    @FXML
    private ListView<String> brokenmachineslv;

    @FXML
    private TableView<MachineryDetails> machinerytable;

    @FXML
    private TableColumn<MachineryDetails, String> machinecolumn;

    @FXML
    private TableColumn<MachineryDetails, String> registrationcolumn;

    @FXML
    private TableColumn<MachineryDetails,Double> purchaseamountcolumn;

    @FXML
    private TableColumn<MachineryDetails, String> purchasedatecolumn;

    @FXML
    private TableColumn<MachineryDetails, String> empoperatorcolumn;

    @FXML
    private TableColumn<MachineryDetails, String> statuscolumn;

    @FXML
    private TableColumn<MachineryDetails,Double> maintenancecostcolumn;

    @FXML
    private TextField machinetf;

    @FXML
    private TextField regnotf;

    @FXML
    private TextField purchaseamounttf;

    @FXML
    private DatePicker purchasedatecb;

    @FXML
    private TextField empoperatortf;

    @FXML
    private ComboBox<?> statuscb;

    @FXML
    private Button savemachinebtn;

    @FXML
    private Button tableDeleteButton;

    @FXML
    private ComboBox<String> monthselectcb;

    @FXML
    private ComboBox<Integer> yearselectcb;

    DBConnection do1;
    ObservableList data;
    String   month,machine,regno,dateofpurchase,operator,status,dateEntered;

    Double price,amount,mainenancecost;
    String date;
    int year,adminid;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        do1 = new  DBConnection();
        setMonth();
        setStatuscb();
        this.adminid =3534;
        buttonActions();

        try {
            setmonthcb();
            setyearcb();
            setLabels(year,month);
            setsqlqueryfortable();
            setbrokenmachineslv();
            setworkingmachineslv();
            setcomboboxesactions();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    //setting comboboxes actions
    private void setcomboboxesactions() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{
                    try {
                        getSelectedatedata(year,month);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
        );
    }



    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {

        setLabels(year,  month);
        setsqlqueryfortable(year,  month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data

    private void setyearcb() throws SQLException {
        ObservableList<Integer>datayears  = FXCollections.observableArrayList();
        String query= " select distinct(year) from companysales";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }

    private void setmonthcb() {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
        monthselectcb.getItems().addAll(datamonths);

    }



    //fetching selected data
    // setting sql table queries for the days to display

    public void buttonActions(){
        savemachinebtn.setOnAction(e->{
            try {
                saveInputData();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }


        });

        tableDeleteButton.setOnAction(e-> {

            try {
                rundeletequery();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        });
    }


    // set month and date
    public void setMonth(){
        LocalDate currentDate = LocalDate.now();

        this.dateEntered = currentDate.toString();
        this.month = currentDate.getMonth().toString();
        this.year = currentDate.getYear();
        this.date = currentDate.toString();
        datelabel.setText(dateEntered);
    }




    //get user input and clear fields
    private  void getuserinput(){

        if(machinetf.getText()!="" && regnotf.getText()!="" && purchaseamounttf.getText()!="" && purchasedatecb.getValue().toString()!="" && statuscb.getValue().toString()!=""){
            if(machinetf.getText()!=null && regnotf.getText()!=null && purchaseamounttf.getText()!=null &&  purchasedatecb.getValue().toString()!=null && statuscb.getValue().toString()!=null){
                machine = machinetf.getText();
                regno =regnotf.getText();
                price = Double.parseDouble(purchaseamounttf.getText());
                dateofpurchase = purchasedatecb.getValue().toString();
                operator = empoperatortf.getText();
                status = statuscb.getValue().toString();
                mainenancecost = 0.0;
            }     else{
                new MachineryAlertBox("No null values accepted");
            }
        }
        else{
            new MachineryAlertBox("Fill in all areas");

        }

    }
     private ObservableList setStatuscb(){
       ObservableList Status = FXCollections.observableArrayList();
        Status.addAll("Working", "Broken Down", "Being Serviced");
         statuscb.getItems().addAll(Status);
         return Status;
     }


    // clearing input
    private void clearuserinput(){
        machinetf.clear();
    regnotf.clear();
        purchaseamounttf.clear();
        purchasedatecb.setValue(null);
        empoperatortf.clear();
        statuscb.getItems().clear();
        setStatuscb();
    }

    private void setTablewithinput(ObservableList inputdata){
        machinerytable.getItems().clear();
        machinerytable.setItems(inputdata);
    }

    //save Input datanu/
    public void saveInputData() throws SQLException {
        getuserinput();
        ObservableList<MachineryDetails> inputdata = FXCollections.observableArrayList();
        inputdata.addAll(new MachineryDetails(machine,regno,price,dateofpurchase,operator,status,mainenancecost));
        savemachinery(machine,regno,price,dateofpurchase,operator,status,mainenancecost);
        new ExpensesController().insertDatatoDB(adminid,machine+" Purchase",price, date, month, year);
        setTablewithinput(inputdata);
        clearuserinput();
    }

    // setting input to sales table
    private void savemachinery(String machine,String regno,double price,String dateofpurchase,String operator,String status,double mainenancecost) throws SQLException {
        String insertquery = "Insert into companymachinery(adminid,machine,registration,purchaseamount,purchasedate,empoperator,status,maintainancecost,month,year) " +
                "values('"+ adminid+"','"+ machine+"','"+ regno+"','"+ price+"','"+ dateofpurchase+"','"+ operator+"','"+ status+"','"+ mainenancecost+"','"+ month+"','" +year+ "')";
       System.out.println(insertquery);
        Connection connect = do1.connect();
        Statement stat = connect.prepareStatement(insertquery);
        stat.execute(insertquery);
        stat.close();
        connect.close();


    }



    //sql query for setting table
    private void setsqlqueryfortable(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select machine,registration,purchaseamount,purchasedate,empoperator,status,maintainancecost from companymachinery where  year = '"+year+"'";

        }   else {
             sqlquery = "select machine,registration,purchaseamount,purchasedate,empoperator,status,maintainancecost from companymachinery where  year = '"+year+"' && month = '"+month+"'";
        }
        System.out.println(sqlquery);
        setTable(sqlquery);
    }
    private void setsqlqueryfortable() throws SQLException {
        String sqlquery = "select machine,registration,purchaseamount,purchasedate,empoperator,status,maintainancecost from companymachinery";
        System.out.println(sqlquery);
        setTable(sqlquery);
    }

    // set sales table

    public  void setTable(String sqlquery) throws SQLException {
        machinerytable.getItems().clear();
        machinerytable.setEditable(true);
        data = FXCollections.observableArrayList();
        setMonth();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while (rs.next()) {

            data.addAll(new MachineryDetails(rs.getString(1),rs.getString(2),rs.getDouble(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getDouble(7)));
            machinecolumn.setCellValueFactory(new PropertyValueFactory<>("machine"));
            maintenancecostcolumn.setCellValueFactory(new PropertyValueFactory<>("maintenancecost"));
            purchaseamountcolumn.setCellValueFactory(new PropertyValueFactory<>("purchaseamount"));
            registrationcolumn.setCellValueFactory(new PropertyValueFactory<>("registration"));
            purchasedatecolumn.setCellValueFactory(new PropertyValueFactory<>("purchasedate"));
            empoperatorcolumn.setCellValueFactory(new PropertyValueFactory<>("empoperator"));
            statuscolumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        }

        machinerytable.setItems(data);
        updateTableData();
    }

    private void updateTableData(){
         ComboBoxTableCell statustbc = new ComboBoxTableCell();
        machinecolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        maintenancecostcolumn.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        purchaseamountcolumn.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        registrationcolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        purchasedatecolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        empoperatorcolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        statuscolumn.setCellFactory(statustbc.forTableColumn("Working", "Broken Down", "Being Serviced"));


        machinecolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<MachineryDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<MachineryDetails, String> event) {
                MachineryDetails machineryDetails = event.getRowValue();

                String oldItemSold = event.getOldValue();
                String newItemSold= event.getNewValue();

                //setters

                machineryDetails.setMachine(newItemSold);

                //getters
                Double itemprice = machineryDetails.getPurchaseamount();
                String regno = machineryDetails.getRegistration();
                machineryDetails.getPurchasedate();

                try {

                    updateStringdetails("companymachinery","machine",newItemSold, "registration" ,regno,"machine" ,oldItemSold);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );
        purchaseamountcolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<MachineryDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<MachineryDetails, Double> event) {
                MachineryDetails machineryDetails = event.getRowValue();

                Double newPriceAmount = event.getNewValue();


                //getters

                //setters


                machineryDetails.setPurchaseamount(newPriceAmount);


                String columnnameValue= machineryDetails.getMachine();
                String columnReg= machineryDetails.getRegistration();

                try {
                    updateDoubledetails("companymachinery","purchaseamount",newPriceAmount, "machine" ,columnnameValue,"registration" ,columnReg);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );
        maintenancecostcolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<MachineryDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<MachineryDetails, Double> event) {
                MachineryDetails machineryDetails = event.getRowValue();

                double dayTotal,monthlyTotal,yearlyTotal,changeDifference;
                Double oldPriceAmount = event.getOldValue();
                Double newPriceAmount = event.getNewValue();

                //getting the change difference
                changeDifference = newPriceAmount + oldPriceAmount;

                //getters

                //setters


                machineryDetails.setMaintenancecost(newPriceAmount);

                String columnnameValue= machineryDetails.getMachine();
                String columnReg= machineryDetails.getRegistration();


                try {
                    new ExpensesController().insertDatatoDB(adminid,columnnameValue+" Maintain",changeDifference, date, month, year);
                    updateDoubledetails("companymachinery","maintainancecost",newPriceAmount, "machine" ,columnnameValue,"registration" ,columnReg);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        registrationcolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<MachineryDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<MachineryDetails, String> event) {
                MachineryDetails machineryDetails = event.getRowValue();

                double dayTotal,monthlyTotal,yearlyTotal,changeDifference;
                String oldregistration = event.getOldValue();
                String newregistration = event.getNewValue();


                //getters
                String columnnameValue= machineryDetails.getMachine();
                String columnRegistration = machineryDetails.getRegistration();
                String columnDateBought= machineryDetails.getPurchasedate();
                //setters
                machineryDetails.setRegistration(newregistration);




                try {
                    updateStringdetails("companymachinery","registration",newregistration,  "machine" ,columnnameValue,"registration" ,oldregistration);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        purchasedatecolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<MachineryDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<MachineryDetails, String> event) {
                MachineryDetails machineryDetails = event.getRowValue();

                //getters
                String oldDateSold = event.getOldValue();
                String newDatebought = event.getNewValue();

                //setters

                machineryDetails.setPurchasedate(newDatebought);


                String columnnameValue= machineryDetails.getMachine();
                String columnRegistration = machineryDetails.getRegistration();

                try {
                    updateStringdetails("companymachinery","purchasedate",newDatebought, "machine" ,columnnameValue,"registration" ,columnRegistration);

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        empoperatorcolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<MachineryDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<MachineryDetails, String> event) {
                MachineryDetails machineryDetails = event.getRowValue();

                //getters
                String oldDateSold = event.getOldValue();
                String newOperator = event.getNewValue();

                //setters

                machineryDetails.setEmpoperator(newOperator);

                String columnnameValue= machineryDetails.getMachine();
                String columnRegistration = machineryDetails.getRegistration();
                String columnDateBought= machineryDetails.getPurchasedate();
                try {
                    updateStringdetails("companymachinery","empoperator",newOperator, "machine" ,columnnameValue,"registration" ,columnRegistration);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        statuscolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<MachineryDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<MachineryDetails, String> event) {
                MachineryDetails machineryDetails = event.getRowValue();

                //getters
                String oldDateSold = event.getOldValue();
                String newStatus = event.getNewValue();

                //setters

                machineryDetails.setStatus(newStatus);

                String columnnameValue= machineryDetails.getMachine();
                String columnRegistration = machineryDetails.getRegistration();


                try {
                    updateStringdetails("companymachinery","status",newStatus, "machine" ,columnnameValue,"registration" ,columnRegistration);
                    setbrokenmachineslv();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );
    }

    //Update database methods

    // update methods with String and Double values as foreign keys
    private void updateStringdetails(String dataTable,String wheretoupdate,String newValue, String key1 ,String value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    // update methods with String and String Values as foreign keys
    private void updateDoubledetails(String dataTable,String wheretoupdate,Double newValue, String key1 ,String value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }
    private void rundeletequery() throws SQLException {
        getItemsToDelete();
        removeItemsFromTable();
    }

    private void getItemsToDelete() throws SQLException {
        String machine,registration,purchasedate, empoperator,status;
        double purchaseamount,maintenancecost;


        MachineryDetails machineryDetails = machinerytable.getSelectionModel().getSelectedItem();
        machine = machineryDetails.getMachine();
        registration =machineryDetails.getRegistration();
        purchaseamount = machineryDetails.getPurchaseamount();
        purchasedate = machineryDetails.getPurchasedate();


        deleteSelectedItemsFromDB("companymachinery","machine",machine, "purchaseamount",purchaseamount, "registration",registration);
    }


    private void removeItemsFromTable(){

        ObservableList<MachineryDetails> removedData,tabledata;
        tabledata = machinerytable.getItems();
        removedData =  machinerytable.getSelectionModel().getSelectedItems();
        removedData.forEach(tabledata::remove);

    }

    private void deleteSelectedItemsFromDB(String Database,String key1,String value1, String key2,double value2, String key3,String value3) throws SQLException {
        String deleteQuery = "delete from "+Database+" where "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"' && "+key3+" = '"+value3+"'";

        System.out.println(deleteQuery);

        do1 = new DBConnection();
        Connection conn =do1.connect();
        Statement statement =(Statement)conn.prepareStatement(deleteQuery);
        statement.execute(deleteQuery);
        statement.close();
        conn.close();


    }

    double totalsales,totalseedlingsales,totalfertilizersales;
    int totalseedlingsold,totalfertilizersold,itemsum;
    double sumprice;
    //get sum of item
    private int getItemSum(String item,String key1, int value1, String key2, String value2) throws SQLException {
        Connection con =  do1.connect();
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select machine,registration,purchaseamount,purchasedate,empoperator,status,maintainancecost from companymachinery where  year = '"+year+"'";

        }   else {
            sqlquery = "SELECT SUM(amount) FROM companysales where item ='" + item + "' && " + key1 + " = '" + value1 + "' && " + key2 + " = '" + value2 + "'";
        }
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            itemsum = rs.getInt(1);
        }
        rs.close();
        con.close();
        return itemsum;
    }

private void setworkingmachineslv() throws SQLException {
        ObservableMap<String,String> workingmachines = FXCollections.observableHashMap();
        workingmachines.put("Machine",   "Registration ");
    String workingmachineslvquery = "SELECT machine, registration FROM companymachinery where   status ='Working'";
   Connection con = do1.connect();
   ResultSet rs = con.createStatement().executeQuery(workingmachineslvquery);
   while(rs.next()){
       workingmachines.put(rs.getString(1),rs.getString(2));
   }
    rs.close();
   con.close();
    workingmachines.forEach((key,value)->{
        workingmachineslv.getItems().addAll(key + " " + value);
    });
   // workingmachineslv.getItems().addAll(String.valueOf(workingmachines));
}


    private void setbrokenmachineslv() throws SQLException {
        ObservableMap<String,String> brokenmachines = FXCollections.observableHashMap();
        brokenmachines.put("machine",   "Registration ");
        String brokenmachineslvquery = "SELECT machine, registration FROM companymachinery where status = 'Broken Down'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(brokenmachineslvquery);
        while(rs.next()){
            brokenmachines.put(rs.getString(1),rs.getString(2));
        }
        rs.close();
        con.close();
        brokenmachines.forEach((key,value)->{
            brokenmachineslv.getItems().addAll(key + " " + value);
        });

    }


    //gettottalsales
    private double getMachineNumber( int year, String month) throws SQLException {
        double machineno = 0;
        Connection con =  do1.connect();
        String machinenoquery = "SELECT count(machine) FROM companymachinery";
        ResultSet rs = con.createStatement().executeQuery(machinenoquery);
        while(rs.next()){
            machineno = rs.getInt(1);
        }
        rs.close();
        con.close();
        totalmachinenolb.setText(String.valueOf(machineno));
        return  machineno;
    }


    //gettottalsales
    private double gettotalmaintenancecost( int year, String month) throws SQLException {
        double maintenancecost=0;
        Connection con =  do1.connect();
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery= "SELECT SUM(maintainancecost) FROM companymachinery where  year= '" + year + "'";

        }   else {
            sqlquery= "SELECT SUM(maintainancecost) FROM companymachinery where  year= '" + year + "' && month = '" + month + "'";
        }
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            maintenancecost = rs.getDouble(1);
        }
        rs.close();
        con.close();
        totalmaintenancecostlb.setText(String.valueOf(maintenancecost));
        return  maintenancecost;
    }



    // setting labels
    private void setLabels(int year, String month) throws SQLException {
        getMachineNumber(  year,  month);
        gettotalmaintenancecost(year,  month);

    }


}
