package sample.Admin.Machinery;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class MachineryDetails {

    private final StringProperty machine;
    private final StringProperty registration;
    private final DoubleProperty purchaseamount;
    private final StringProperty purchasedate;
    private final StringProperty empoperator;
    private final StringProperty status;
    private final DoubleProperty maintenancecost;



    public MachineryDetails(String machine,String registration,double purchaseamount,String purchasedate,String empoperator,String status,double maintenancecost){
        this.machine = new SimpleStringProperty(machine);
        this.registration = new SimpleStringProperty(registration);
        this.purchaseamount = new SimpleDoubleProperty(purchaseamount);
        this.purchasedate = new SimpleStringProperty(purchasedate);
        this.empoperator = new SimpleStringProperty(empoperator);
        this.status = new SimpleStringProperty(status);
        this.maintenancecost = new SimpleDoubleProperty(maintenancecost);

    }

    //getters
    public String getMachine() {
        return machine.get();
    }
    public String getRegistration() {
        return registration.get();
    }
    public double getPurchaseamount() {
        return purchaseamount.get();
    }
    public String getPurchasedate() {
        return purchasedate.get();
    }
    public String getEmpoperator() {
        return empoperator.get();
    }
    public String getStatus() {
        return status.get();
    }
    public double getMaintenancecost() {
        return maintenancecost.get();
    }


    //setters

    public void setMachine(String value) {
        machine.set(value);
    }
    public void setRegistration(String value) {
        registration.set(value);
    }
    public void setPurchaseamount(double value) {
        purchaseamount.set(value);
    }
    public void setPurchasedate(String value) {
        purchasedate.set(value);
    }
    public void setEmpoperator(String value) {
        empoperator.set(value);
    }
    public void setStatus(String value) {
        status.set(value);
    }
    public void setMaintenancecost(double value) {
        maintenancecost.set(value);
    }

    //property setting

    public StringProperty machineProperty() {
        return machine;
    }
    public StringProperty registrationProperty() {
        return registration;
    }
    public DoubleProperty purchaseamountProperty() {
        return purchaseamount;
    }
    public StringProperty purchasedateProperty() {
        return purchasedate;
    }
    public StringProperty empoperatorProperty() {
        return empoperator;
    }
    public StringProperty statusProperty() {
        return status;
    }
    public DoubleProperty maintenancecostProperty() {
        return maintenancecost;
    }


}
