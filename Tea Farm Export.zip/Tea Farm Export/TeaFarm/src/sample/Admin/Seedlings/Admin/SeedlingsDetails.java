package sample.Admin.Seedlings.Admin;

import javafx.beans.property.*;

public class SeedlingsDetails {
    private final IntegerProperty farmerid;
    private final StringProperty seedlingtype;
    private final StringProperty description;
    private final DoubleProperty price;
    private final StringProperty dateSold;
    private final IntegerProperty amount;
    private final StringProperty orderid;
    private final StringProperty status;



    public SeedlingsDetails( int farmerid,String seedlingtype ,String description,int amount,  double price, String dateSold, String orderid,String status){
            this.farmerid = new SimpleIntegerProperty(farmerid);
            this.seedlingtype = new SimpleStringProperty(seedlingtype);
            this.description = new SimpleStringProperty(description);
            this.amount = new SimpleIntegerProperty(amount);
            this.price = new SimpleDoubleProperty(price);
            this.dateSold = new SimpleStringProperty(dateSold);
            this.orderid = new SimpleStringProperty(orderid);
            this.status = new SimpleStringProperty(status);


        }

        //getters
        public Integer getFarmerid() {
            return farmerid.get();
        }
        public String getSeedlingtype() {
            return seedlingtype.get();
        }
        public String getDescription() {
        return description.get();
    }
        public double getPrice() {
            return price.get();
        }

        public String getDateSold() {
            return dateSold.get();
        }

        public int getAmount() {
            return amount.get();
        }
        public String getOrderid() {
        return orderid.get();
    }

        public String getStatus() {
        return status.get();
    }


    //setters
        public void setFarmerid(int value) {
        farmerid.set(value);
    }
        public void setSeedlingtype(String value) {
            seedlingtype.set(value);
        }
        public void setDescription(String value) {
        description.set(value);
    }
        public void setPrice(double value) {
            price.set(value);
        }

        public void setAmount(int value) {
            amount.set(value);
        }
        public void setDateSold(String value) {
            dateSold.set(value);
        }
        public void setOrderid(String value) {
        orderid.set(value);
    }
        public void setStatus(String value) {
        status.set(value);
    }


        //property setting
        public IntegerProperty farmeridProperty() {
            return farmerid;
        }
        public StringProperty seedlingtypeProperty() {
            return seedlingtype;
        }
        public StringProperty descriptionProperty() {
        return description;
    }
        public DoubleProperty priceProperty() {
            return price;
        }
        public IntegerProperty amountProperty() {
            return amount;
        }
        public StringProperty datesoldProperty() {
            return dateSold;
        }
        public StringProperty orderidProperty() {
        return orderid;
    }
        public StringProperty statusProperty() {
        return status;
    }
    }