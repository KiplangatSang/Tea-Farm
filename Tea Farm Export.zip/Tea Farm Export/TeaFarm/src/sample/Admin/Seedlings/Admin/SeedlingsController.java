package sample.Admin.Seedlings.Admin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import sample.Admin.Fertilizer.Admin.FertilizerDetails;
import sample.Admin.SeedlingPrices.PricesView;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Login.Farmer.FarmerLoginDetails;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class SeedlingsController  implements Initializable {

    @FXML
    private Label totalSeedlingcostlb;

    @FXML
    private Label totalseedlingnolb;

    @FXML
    private ListView<?> seedlingdeliverylv;

    @FXML
    private TableView<SeedlingsDetails> seedlingstable;

    @FXML
    private TableColumn<SeedlingsDetails, Integer> farmeridcolumn;

    @FXML
    private TableColumn<SeedlingsDetails, String> seedlingtypecolumn;

    @FXML
    private TableColumn<SeedlingsDetails, String> descriptioncol;

    @FXML
    private TableColumn<SeedlingsDetails, Integer> seedlingnocolumn;

    @FXML
    private TableColumn<SeedlingsDetails, Double> seedlingpricecolumn;

    @FXML
    private TableColumn<SeedlingsDetails, String> datecolumn;

    @FXML
    private TableColumn<SeedlingsDetails, String> seedlingorderidcolumn;

    @FXML
    private TableColumn<SeedlingsDetails, String> seedlingstatuscolumn;

    @FXML
    private TextField farmeridtf;

    @FXML
    private ComboBox<String> seedlingtypetf;

    @FXML
    private TextField seedlingnumbertf;

    @FXML
    private Button seedlingorderbtn;

    @FXML
    private Button seedlingpricebtn;

    @FXML
    private Button tableDeleteButton;

    @FXML
    private ComboBox<Integer> yearselectcb;

    @FXML
    private ComboBox<String> monthselectcb;

    @FXML
    private ComboBox<String> descriptioncb;


    DBConnection do1;
      String seedlingtype,orderid,dateoforder,status,date,month,description;
      double seedlingcost,price;
      int noofseedlings,farmerid,year;
      ObservableList<SeedlingsDetails> tabledata;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setDate();
      do1 = new DBConnection();

        try {
            setSeedlingtypetf();
            setDescriptioncb();
            setyearcb();
            setmonthcb();
            setButtonActions();
            setcomboboxesactions();
            settotalSeedlingcostlbquery(year,month);
            settotalseedlingnolbquery(year,month);
            setseedlingdeliverylvquery(year,month);
            setsqlqueryfortable(year,month);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    //set button actions
    private void setButtonActions(){
        seedlingorderbtn.setOnAction(e->{
            try {
                runinsertions();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        tableDeleteButton.setOnAction(e->
        {
            try {
                rundeletequery();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        seedlingpricebtn.setOnAction(e-> new PricesView().display("Seedling Prices"));
    }

    //setting comboboxes actions
    private void setcomboboxesactions() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{
                    try {
                        getSelectedatedata( year,  month);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
                );
    }



    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {

        settotalSeedlingcostlbquery(year,month);
        settotalseedlingnolbquery(year,month);
        setseedlingdeliverylvquery(year,month);
        setsqlqueryfortable(year,month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data
    private void setyearcb() throws SQLException {
        ObservableList<Integer>datayears  = FXCollections.observableArrayList();
       String query=" select distinct(year) from seedlingsorders where farmerid= farmerid";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }
    private void setmonthcb() throws SQLException {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
               monthselectcb.getItems().addAll(datamonths);

    }


    //setting date and time
    private void setDate(){
        LocalDate currentDate = LocalDate.now();
        DayOfWeek getDayOfWeek =currentDate.getDayOfWeek();
        this.date = LocalDate.now().toString();
        this.month = currentDate.getMonth().toString();
        this.year= currentDate.getYear();
    }

    //setting seedlingtypestf
    private  void setSeedlingtypetf() throws SQLException {
        String query = "Select distinct(type) from seedlingprices";
        ObservableList seedlingtypes = FXCollections.observableArrayList();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while (rs.next()){
            seedlingtypes.add(rs.getString(1));
        }
        rs.close();
        con.close();
        seedlingtypetf.setItems(seedlingtypes);
    }

    //setting seedlingtypestf
    private  void setDescriptioncb() throws SQLException {
        String query = "Select distinct(description) from seedlingprices";
        ObservableList seedlingdesc = FXCollections.observableArrayList();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while (rs.next()){
            seedlingdesc.add(rs.getString(1));
        }
        rs.close();
        con.close();
        descriptioncb.setItems(seedlingdesc);

    }


    //getting user input
    private void getUserInput(){
        if( seedlingtypetf.getValue() != "" && seedlingnumbertf.getText()!=""){
            if(seedlingtypetf.getValue() != null && seedlingnumbertf.getText()!=null){
                try{
                    farmerid = Integer.parseInt(farmeridtf.getText());
                    seedlingtype =  seedlingtypetf.getValue().toString();
                     description = descriptioncb.getValue();
                    noofseedlings= Integer.parseInt(seedlingnumbertf.getText());
                    status = "Received";

                    //get price
                    getItemPrice( seedlingtype, description);

                    farmeridtf.clear();
                    seedlingtypetf.setValue(null);
                    seedlingnumbertf.clear();
                    setSeedlingtypetf();

                }catch (Exception e){
                    new SeedlingsAlertBox("null values not accepted");
                }

            }else{
                new SeedlingsAlertBox("null values not accepted");
            }
        }else{
           new SeedlingsAlertBox("Fill in all values");
        }

    }


    //getting price of items
    private double getItemPrice(String item,String description) throws SQLException {
        String query = "Select price from seedlingprices where type = '"+item+"' && description = '"+description+"'";
       System.out.println(query);
        Connection con = do1.connect();
       ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            price = rs.getDouble(1);
        }
        rs.close();
        con.close();

        price = noofseedlings * price;

        System.out.println(price + "getItemPrice()");
        return price;
    }


    //generating orderid
    private String generateorderid(int farmerid,String date ,int amount ){
        String orderid = date+"/"+farmerid+"/"+amount;
        this.orderid = orderid;
        return orderid;
    }

    //set insert sql query
    String query;
    public void setsqlinputinsert()  {
        query = "insert into seedlingsorders(farmerid,seedlingtype ,description,seedlingamount , seedlingprice ,date ,orderid, status,month,year)" +
                " values('"+farmerid+"','"+seedlingtype+"','"+description+"' ,'"+noofseedlings+"' , '"+price+"' ,'"+date+"' ,'"+orderid+"', '"+status+"', '"+month+"', '"+year+"')";

    }

    //saving data to database
    private void saveinputdatatoDb(String query) throws SQLException {
        Connection con = do1.connect();
        Statement statement = con.prepareStatement(query);
        statement.execute(query);
        statement.close();
        con.close();
    }

    //adding user input to table
    private void adduserinputtotable(int farmerid,String type,String description,int amount,double price,String date,String orderid,String status){
        ObservableList<SeedlingsDetails> inputtabledata = FXCollections.observableArrayList();
        inputtabledata.addAll(new SeedlingsDetails(farmerid,type,description,amount,price,date,orderid,status));
        seedlingstable.setItems(inputtabledata);
    }



    //perform insertions
    private void runinsertions() throws SQLException {
        getUserInput();
        generateorderid(farmerid,date ,noofseedlings);
        setsqlinputinsert();
        saveinputdatatoDb(query);
        adduserinputtotable(farmerid,seedlingtype,description ,noofseedlings,price,date,orderid,status);

        settotalSeedlingcostlbquery(year,month);
        settotalseedlingnolbquery(year,month);
        setseedlingdeliverylvquery(year,month);

    }

    //sql query for setting table
    private void setsqlqueryfortable( int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select farmerid,seedlingtype ,description,seedlingamount , seedlingprice ,date ,orderid, status from seedlingsorders where year = '" + year + "'";

        }   else {
             sqlquery = "select farmerid,seedlingtype ,description,seedlingamount , seedlingprice ,date ,orderid, status from seedlingsorders where year = '" + year + "' && month = '" + month + "'";
        }
        setTable(sqlquery);
    }

    //setting table
        public void setTable(String sqlquery) throws SQLException {
        seedlingstable.getItems().clear();
            seedlingstable.setEditable(true);

           setDate();
     do1 = new DBConnection();
        Connection conn = do1.connect();
            tabledata = FXCollections.observableArrayList();

System.out.println(sqlquery);

            ResultSet rs = conn.createStatement().executeQuery(sqlquery);

        while (rs.next()){
       tabledata.add(new SeedlingsDetails(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getDouble(5), rs.getString(6), rs.getString(7),rs.getString(8)));

            farmeridcolumn.setCellValueFactory(new PropertyValueFactory<>("farmerid"));
            seedlingtypecolumn.setCellValueFactory(new PropertyValueFactory<>("seedlingtype"));
            descriptioncol.setCellValueFactory(new PropertyValueFactory<>("description"));
            seedlingnocolumn.setCellValueFactory(new PropertyValueFactory<>("amount"));
            seedlingpricecolumn.setCellValueFactory(new PropertyValueFactory<>("price"));
            datecolumn.setCellValueFactory(new PropertyValueFactory<>("dateSold"));
            seedlingorderidcolumn.setCellValueFactory(new PropertyValueFactory<>("orderid"));
            seedlingstatuscolumn.setCellValueFactory(new PropertyValueFactory<>("status"));

            //setting taable items
            seedlingstable.setItems(tabledata);

        }
            updateTableData();
    }


    //setting labels

    //setting sql quey for totalSeedlingcostlb
    private String settotalSeedlingcostlbquery(int year ,String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(seedlingprice) from seedlingsorders where year = '"+year+"'";
        }   else {
             sqlquery = "select SUM(seedlingprice) from seedlingsorders where year = '"+year+"' && month = '"+month+"'";
        }
        totalSeedlingcostlb(sqlquery);
        return sqlquery;
    }

    //setting cost label
    private void totalSeedlingcostlb(String totalSeedlingcostquery) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(totalSeedlingcostquery);
        while(rs.next()){
            totalSeedlingcostlb.setText(String.valueOf(rs.getDouble(1)));
        }
      rs.close();
        con.close();
    }




    //setting sql query for totalSeedlingcostlb

    private String settotalseedlingnolbquery(int year ,String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(seedlingprice) from seedlingsorders where year = '"+year+"'";
        }   else {
             sqlquery = "select SUM(seedlingamount) from seedlingsorders where year = '" + year + "' && month = '" + month + "'";
        }
        settotalseedlingnolb(sqlquery);
        return sqlquery;
    }

    private void settotalseedlingnolb(String totalseedlingno) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(totalseedlingno);
        while(rs.next()){
            totalseedlingnolb.setText(String.valueOf(rs.getDouble(1)));
        }
        rs.close();
        con.close();
    }

    //setting seedlingdeliverylv
    private String setseedlingdeliverylvquery(int year ,String month) throws SQLException {
        String sqlquery = "select type ,description, amount  from seedlingprices";

        setseedlingdeliverylv(sqlquery);
        return sqlquery;
    }

    private void setseedlingdeliverylv(String seedlingdeliveryquery) throws SQLException {
        ObservableList seedlingsondelivery = FXCollections.observableArrayList();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(seedlingdeliveryquery);
        while(rs.next()){
            seedlingsondelivery.addAll(rs.getString(1)+ "  "+rs.getString(2) +" Amount: " +rs.getInt(3));
        }

        seedlingdeliverylv.setItems(seedlingsondelivery);

        rs.close();
        con.close();
    }

    //update table details
    private void updateTableData(){

        //setting table items
        seedlingstable.setItems(tabledata);

        seedlingtypecolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        seedlingnocolumn.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        seedlingpricecolumn.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        seedlingstatuscolumn.setCellFactory(ComboBoxTableCell.forTableColumn("Received","Allocated","Delivered"));

        seedlingtypecolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<SeedlingsDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<SeedlingsDetails, String> event) {
                SeedlingsDetails seedlingsDetails = event.getRowValue();


                String oldType = event.getOldValue();
                String newType = event.getNewValue();

                //getting the change difference


                //getters
                Double cost= seedlingsDetails.getPrice();
                String orderid =seedlingsDetails.getOrderid();


                //setters

                seedlingsDetails.setSeedlingtype(newType);

                try {
                    updateStringdetails("seedlingsorders","seedlingtype", newType, "seedlingprice" ,cost,"orderid",orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        seedlingnocolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<SeedlingsDetails, Integer>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<SeedlingsDetails, Integer> event) {
                SeedlingsDetails seedlingsDetails = event.getRowValue();

                int  oldamount = event.getOldValue();
                int newamount = event.getNewValue();

                //getters

                //setters

                seedlingsDetails.setAmount(newamount);
                String orderid= seedlingsDetails.getOrderid();
                Double price = seedlingsDetails.getPrice();
                try {
                    updateintegerdetails("seedlingsorders","seedlingamount",newamount,"seedlingprice" ,price,"orderid",orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        seedlingpricecolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<SeedlingsDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<SeedlingsDetails, Double> event) {
                SeedlingsDetails seedlingsDetails = event.getRowValue();


                Double oldprice = event.getOldValue();
                Double newprice = event.getNewValue();

                //getting the change difference


                //getters
                String datepaid =seedlingsDetails.getDateSold();
                String orderid =seedlingsDetails.getOrderid();
                //setters

                seedlingsDetails.setPrice(newprice);

                try {
                    updatedoubledetails("seedlingsorders","seedlingprice", newprice, "date" ,datepaid,"orderid",orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        seedlingstatuscolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<SeedlingsDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<SeedlingsDetails, String> event) {
                SeedlingsDetails seedlingsDetails = event.getRowValue();

                String oldstatus = event.getOldValue();
                String newstatus = event.getNewValue();

                //getters

                //setters

                seedlingsDetails.setStatus(newstatus);
                String orderid= seedlingsDetails.getOrderid();
                Double price= seedlingsDetails.getPrice();
               String item = seedlingsDetails.getSeedlingtype();
               String description = seedlingsDetails.getDescription();
               int seedlingno =  seedlingsDetails.getAmount();


                if(newstatus == "Allocated"){
                    try {
                        selectSeedlingamount(item, description, seedlingno);
                        setseedlingdeliverylvquery(year,month);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }

                try {
                    updateStringdetails("seedlingsorders","status",newstatus,"seedlingprice" ,price,"orderid",orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );
    }

    //update amount of seedlings available
    int amount;
    //getting amoint of items
    private int selectSeedlingamount(String item,String description,int seedlingno) throws SQLException {
        String query = "Select amount from seedlingprices where type = '"+item+"' && description = '"+description+"'";
        System.out.println(query);
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        if(rs.next()){
            amount = rs.getInt(1);
            amount = amount - seedlingno;
            updateSeedlingamount( item, description, amount);
        }
        rs.close();
        con.close();


        return amount;
    }

    //update seedling amount
    private void updateSeedlingamount(String item,String description,int amount) throws SQLException {
        String query = "update  seedlingprices set amount = '"+amount+"'  where type = '"+item+"' && description = '"+description+"'";
        System.out.println(query);
        Connection con = do1.connect();
        Statement stat  = con.prepareStatement(query);
        stat.execute(query);
        stat.close();
        con.close();

    }

    // update method
    // update methods with String and Double values as foreign keys
    private void updateStringdetails(String dataTable,String wheretoupdate,String newValue, String key1 ,double value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    // update methods with double and String Values as foreign keys
    private void updatedoubledetails(String dataTable,String wheretoupdate,double newValue, String key1 ,String value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }
    // update methods with integer and String Values as foreign keys
    private void updateintegerdetails(String dataTable,String wheretoupdate,int newValue, String key1 ,double value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }
    private void rundeletequery() throws SQLException {
        getItemsToDelete();
        removeItemsFromTable();
    }

    private void getItemsToDelete() throws SQLException {
        String type,dateapplied;
        int farmerid;

        SeedlingsDetails seedlingsDetails = seedlingstable.getSelectionModel().getSelectedItem();
        type = seedlingsDetails.getSeedlingtype();
        farmerid =seedlingsDetails.getFarmerid();
        dateapplied = seedlingsDetails.getDateSold();

        deleteSelectedItemsFromDB("seedlingsorders","seedlingtype",type, "farmerid",farmerid, "date",dateapplied);



    }


    private void removeItemsFromTable(){

        ObservableList<SeedlingsDetails> removedData,tabledata;
        tabledata = seedlingstable.getItems();
        removedData =  seedlingstable.getSelectionModel().getSelectedItems();
        removedData.forEach(tabledata::remove);

    }

    private void deleteSelectedItemsFromDB(String Database,String key1,String value1, String key2,double value2, String key3,String value3) throws SQLException {
        String deleteQuery = "delete from "+Database+" where "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"' && "+key3+" = '"+value3+"'";

        System.out.println(deleteQuery);

        do1 = new DBConnection();
        Connection conn =do1.connect();
        Statement statement =(Statement)conn.prepareStatement(deleteQuery);
        statement.execute(deleteQuery);
        statement.close();
        conn.close();


    }

}



