package sample.Admin.FertilizerPrices;

import javafx.beans.property.*;

public class PriceDetails {

        private final StringProperty fertilizertype;
        private final DoubleProperty bagsize;
        private final DoubleProperty price;
        private final IntegerProperty amount;



        public PriceDetails(String fertilizertype,double bagsize,double price,int amount){
            this.fertilizertype = new SimpleStringProperty(fertilizertype);
            this.bagsize = new SimpleDoubleProperty(bagsize);
            this.amount = new SimpleIntegerProperty(amount);
            this.price = new SimpleDoubleProperty(price);
        }

        //getters
        public String getFertilizertype() {
            return fertilizertype.get();
        }
        public double getPrice() {
            return price.get();
        }
        public double getBagsize() {
            return bagsize.get();
        }
        public double getAmount() {
            return amount.get();
        }

        //setters

        public void setFertilizertype(String value) {
            fertilizertype.set(value);
        }
        public void setPrice(double value) {
            price.set(value);
        }
        public void setBagsize(double value) {
            bagsize.set(value);
        }
        public void setAmount(int value) {
            amount.set(value);
        }

        //property setting
        public StringProperty  fertilizertypeProperty() {
            return fertilizertype;
        }
        public DoubleProperty  priceProperty() {
            return price;
        }
        public DoubleProperty  bagsizeProperty() {
            return bagsize;
        }
        public IntegerProperty amountProperty() {
            return amount;
        }


}
