package sample.Admin.FertilizerPrices;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sample.Admin.Expenses.Admin.ExpensesView;

import java.io.IOException;


    public class PricesView {
        static Stage  stage;
        public void display(String title)  {
            stage = new Stage();

            try {
                Parent root = FXMLLoader.load(getClass().getResource("Prices.fxml"));
                stage.setScene(new Scene(root));
                stage.setTitle(title);
                stage.setResizable(false);
                stage.initModality(Modality.APPLICATION_MODAL);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        public static void closeWindow(){
            stage.close();
            new ExpensesView();
        }
    }

 /*
        @Override
        public void start(Stage primaryStage) throws Exception {
            try {
                Parent root = FXMLLoader.load(getClass().getResource("Prices.fxml"));
                primaryStage.setScene(new Scene(root));
                primaryStage.setTitle("Company Sales");
                primaryStage.setResizable(false);
                primaryStage.show();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }*/

