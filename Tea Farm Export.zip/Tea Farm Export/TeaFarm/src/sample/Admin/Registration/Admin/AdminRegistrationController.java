package sample.Admin.Registration.Admin;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.apache.commons.codec.digest.DigestUtils;
import sample.DatabaseConnections.CreateDBTables.CreateDatabase;
import sample.DatabaseConnections.DBConnection;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;

import static sample.Admin.Registration.Admin.AdminRegistrationAlertBox.guideToSetRecoveryQuestion;


public class AdminRegistrationController implements Initializable {

    @FXML
    private TextField fnametxt;

    @FXML
    private TextField lnametxt;

    @FXML
    private TextField usernametxt;

    @FXML
    private PasswordField passwordtxt;

    @FXML
    private PasswordField confirmpasswordtxt;

    @FXML
    private TextField adminidtf;

    @FXML
    private Button registerbtn;

    CreateDatabase dbcreater;
    DBConnection do1;
    String firstname, lastname, username, password, confirmpassword, recoveryquestion = "", recoveryanswer = "";
    String  UsernameInputFromAlert, month;
    String userloginname;
    int adminid;


    int year;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadButtonActions();
    }

    //loading button Actions
    private void loadButtonActions() {


        registerbtn.setOnAction(e -> {
            try {
                storeregistrationdetails();

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (ClassNotFoundException classNotFoundException) {
                classNotFoundException.printStackTrace();
            }

        });
    }

    // check login button value

    private void getRegisterbtnTextValue() throws SQLException, ClassNotFoundException {
      String  btntext = registerbtn.getText();
      if(btntext.equals("Update")){
          updateUserRegistrationDetails();
      }
      else if(btntext.equals("Register")){;
          storeregistrationdetails();
      }
      else{
         AdminRegistrationAlertBox.dataerror("Data Error");
        }
      System.out.println(" getRegisterbtnTextValue " +btntext);

    }

    //get user registrationinput
    private void getUserRegistrationInput() throws SQLException, ClassNotFoundException {
        if(fnametxt.getText()!= null && lnametxt.getText()!= "" &&  usernametxt.getText()!= "" && passwordtxt.getText()!= "" && confirmpasswordtxt.getText()!= ""){

            try{
                adminid = Integer.parseInt(adminidtf.getText());
                try{
                    Integer.parseInt(fnametxt.getText());
                    Integer.parseInt(lnametxt.getText());
                    Integer.parseInt(usernametxt.getText());

                    AdminRegistrationAlertBox.dataerror("Use correct characters");
                    fnametxt.setText("");lnametxt.setText("");usernametxt.setText("");
                }catch(Exception e){
                    firstname = fnametxt.getText();
                    lastname = lnametxt.getText();
                    try{
                        Integer.parseInt(usernametxt.getText());
                        usernametxt.setText("");
                        AdminRegistrationAlertBox.dataerror("Enter correct details");
                    }catch (Exception ex){
                        if(usernametxt.getText().length() <= 1 ){
                            usernametxt.setText("");
                            AdminRegistrationAlertBox.dataerror("Enter correct details");
                        }else{
                            username = usernametxt.getText();
                        }
                    }

                    if(passwordtxt.getText().length() <= 5 ){
                        if(passwordtxt.getText().length() <=0 ){
                            AdminRegistrationAlertBox.dataerror("No Password");
                        }
                        else{
                            passwordtxt.setText("");
                            confirmpasswordtxt.setText("");
                            AdminRegistrationAlertBox.dataerror("Weak Password");}
                    }else{
                        password = DigestUtils.md5Hex(passwordtxt.getText());
                    }

                    confirmpassword = DigestUtils.md5Hex(confirmpasswordtxt.getText());
                    month = LocalDate.now().getMonth().toString();
                    year = LocalDate.now().getYear();
                }
            }catch(Exception idex){
                AdminRegistrationAlertBox.dataerror("Id is an Integer");
            }

        }
    }

    // Storing registration Details
    private void storeregistrationdetails() throws SQLException, ClassNotFoundException {
        getUserRegistrationInput();


        do1 = new DBConnection();
        Connection con = do1.connect();

        if (!firstname.equals("") && !lastname.equals("") && !username .equals("") && !password.equals("") && !confirmpassword.equals("")) {
            if (firstname!= null && lastname!= null && username != null && password !=null && confirmpassword!= null) {
                if ( password.equals(confirmpassword)) {

                    String query = "insert into admin_users(firstname,lastname,username,adminid,password,recoveryquestion,recoveryanswer,month,year) values('" + firstname + "','" + lastname + "','" + username + "','" + adminid + "','" + password + "','" + recoveryquestion + "','" + recoveryanswer + "','" + month + "','" + year + "') ";

                    con.createStatement().execute(query);
                    con.close();

                    guideToSetRecoveryQuestion("Hello "+username + " \n " + "Set a recovery Question" +" \n ", username);


                }

                else {
                    AdminRegistrationAlertBox.dataerror("Please Fill in same password values");
                }
            }
            else if(username == "" || password == "" && firstname == ""){
                AdminRegistrationAlertBox.dataerror("Please Fill In all Fields");
            }

            }
        else {
            AdminRegistrationAlertBox.dataerror("Please Fill In all Fields");
        }

    }

    //store registration Details
    private String updateUserRegistrationDetails() throws SQLException, ClassNotFoundException {

        getusernamefromuser();
        String updatecheckquery = "SELECT (username) FROM adminusers where username ='" + UsernameInputFromAlert + "'";


        do1 = new DBConnection();
        if (UsernameInputFromAlert != "" || UsernameInputFromAlert != null) {
            Connection con = do1.connect();
            ResultSet rs = con.createStatement().executeQuery(updatecheckquery);

            if (rs.next()) {
                rs.close();
                updatePassword();
            }

            else {
                String query = "insert into adminusers(firstname,lastname,username,password,recoveryquestion,recoveryanswer,month,year) values('" + firstname + "','" + lastname + "','" + username + "','" + password + "','" + recoveryquestion + "','" + recoveryanswer + "','" + month + "','" + year + "') ";
                if (password != null || password != "" && password.equals(confirmpassword)) {


                    Statement stat = con.prepareStatement(query);
                    stat.execute(query);
                    stat.close();
                    con.close();

                }
                else if(password == null|| password == " "){
                    AdminRegistrationAlertBox.dataerror("Enter Password");
                }
            }
        }

                else {
                    AdminRegistrationAlertBox.dataerror("Passwords are not the same");
                }


        userloginname = username;
        System.out.println(userloginname);
        new AdminRegistrationDetails(userloginname);
        return userloginname;

    }

    //check user input
    private void getusernamefromuser() {
        UsernameInputFromAlert = AdminRegistrationDetails.getUsername();
        System.out.println(UsernameInputFromAlert);
    }


    private void updatePassword() throws SQLException {
        getusernamefromuser();

        String insertQuery = "UPDATE adminusers  SET password = '" + password + "'WHERE username ='" + UsernameInputFromAlert + "'";

        do1 = new DBConnection();
        Connection conn = do1.connect();
        Statement statement = conn.prepareStatement(insertQuery);
        statement.execute(insertQuery);
    }



}

   /*  try {
           // getUsernamesFromDB();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }*/
        /*
forgotpasswordbtn.setOnAction(e->{
    AdminLoginAlertBox.getUserName("Enter Username and Press Okey" );
});
        loginbtn.setOnAction(e-> {
            try {


                loginUser();
            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        });
        saveRecoveryItemsbtn.setOnAction(e-> {
            try {
                storeRecoveryQuestionAndAnswer();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });*/


   /* //get user login input
    private void getUserLoginInput(){
        try{
        this.username = loginusernamecb.getValue().toString();
        this.password = loginpasswordtxt.getText();}
        catch (Exception e){
            AdminLoginAlertBox.dataerror("Input Your Details");
        }
    }



    //fetching username and password from db
    private void fetchUserDetails(String Username) throws SQLException {
        do1 =new DBConnection();
        Connection con = do1.connecttoDB("registration");
        String query = "SELECT username,password  FROM registration where username ='"+Username+"'";
System.out.println(query);
        ResultSet rs = con.createStatement().executeQuery(query);



        if(rs.next()){
                this.dbUsername = rs.getString(1);
                this.dbPassword = rs.getString(2);
                System.out.println("fetchUserDetails dbusername "+dbUsername); System.out.println("fetchUserDetails dbpassword "+dbPassword);

            System.out.println("UserPresent");

        }
        else{
            AdminLoginAlertBox.dataerror("User Name Not Registered");
        }
        con.close();

    }

    //validate and authenticate user
    private String authenticateuser(String username,String password) throws SQLException, ClassNotFoundException {
        fetchUserDetails(username);

    // System.out.println("authenticateuser dbUsername " +dbUsername); System.out.println("authenticateuser dbPassword "+dbPassword);

    // System.out.println("authenticateuser Username " +username); System.out.println("authenticateuser Password "+password);
        if(username.equals(dbUsername) && password.equals(dbPassword)){
            new CreateDatabase().performdbCreation(username.toLowerCase()+"farmsystem");
          this.userloginname = username;
            //AdminRegistrationView.closeWindow()

           new AdminRegistrationDetails(username);
            MainView mainView = new MainView();
            mainView.display(username +" Farmsystem");        }
        else if(username.equals(dbUsername) && !password.equals(dbPassword)){
AdminLoginAlertBox.dataerror("Wrong Password");
        }
        else{
            AdminLoginAlertBox.dataerror("Input correct credentials");
        }
       new AdminRegistrationDetails(userloginname);
      return userloginname;
    }

    //Login user
    //set login cb.
    private void getUsernamesFromDB() throws SQLException {

    ObservableList usernames = FXCollections.observableArrayList();
        do1 =new DBConnection();
        Connection con = do1.connecttoDB("registration");
        String query = "SELECT(username)  FROM registration";
//System.out.println(query);
        ResultSet rs = con.createStatement().executeQuery(query);
        if(rs.next()){
            while(rs.next()){
                usernames.add(rs.getString(1));
            }
    }
        loginusernamecb.getItems().addAll(usernames);
    }


    private void loginUser() throws SQLException, ClassNotFoundException {
        getUserLoginInput();

        authenticateuser(username,password);
    }
    //Logout user
    private void logoutUser(){

    }

    //get recovery question
private void getrecoveryquestionfromdb(String Username) throws SQLException {
    do1 = new DBConnection();
    Connection con = do1.connecttoDB("registration");
    String query = "SELECT username,recoveryquestion FROM registration where username ='" + Username + "'";
    System.out.println(query);

    ResultSet rs = con.createStatement().executeQuery(query);
    if (rs.next()) {
        while (rs.next()) {
            dbUsername = rs.getString(1);
            dbrecoveryquestion= rs.getString(2);
        }
    }
}



    //recover passwords
    public void recoverPassword() throws SQLException {
        //getting username
        getusernamefromuser();
        getrecoveryquestionfromdb(UsernameInputFromAlert);
        AdminLoginAlertBox.closeWindow1();

        //getting recovery question from database
       // AdminLoginAlertBox.recoverAccount(dbrecoveryquestion);
        String recoveryanswer = AdminLoginAlertBox.recoveryAnswerInput;
        AdminLoginAlertBox.closeWindow1();
        if(recoveryanswer.equals(dbrecoveryanswer)){
            AdminLoginAlertBox.dataerror("You must set a new password");
            new AdminRegistrationView();
            disableLoginView();
        }
        else{
            AdminLoginAlertBox.dataerror("This is not the correct answer!");
        }



    }

    //updating password after recovery
    private void validateUserPasswords(){

    }





    //disabling login site
    private void disableLoginView(){
        loginpasswordtxt.isDisabled();
        loginusernamecb.isDisabled();
        loginbtn.isDisabled();

    }
    //Disabling registration site
    private void disableRegistrationView(){
       fnametxt.isDisabled();
        lnametxt.isDisabled();
        usernametxt.isDisabled();;
      passwordtxt.isDisabled();;
      confirmpasswordtxt.isDisabled();;
   recoveryquestioncb.isDisabled();;
   recoveryanswertxt.isDisabled();;
   registerbtn.isDisabled();
    }

    //disabling registration for updating password
    private void disablePartlyRegistrationView(){
        getusernamefromuser();
        registerbtn.setText("Update");
        fnametxt.isDisabled();
        lnametxt.isDisabled();
        usernametxt.setText(UsernameInputFromAlert);
        recoveryquestioncb.isDisabled();;
        recoveryanswertxt.isDisabled();;
        registerbtn.isDisabled();
    }
 */

