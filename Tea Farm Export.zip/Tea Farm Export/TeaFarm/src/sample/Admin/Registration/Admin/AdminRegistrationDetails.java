package sample.Admin.Registration.Admin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class AdminRegistrationDetails {
    public static StringProperty username;

    public AdminRegistrationDetails(String username){
        this.username = new SimpleStringProperty(username);
    }


    //getters
    public static String getUsername() {
        return username.get();
    }


    //setters

    public void setUsername(String value) {
        username.set(value);
    }

    //property setting
    public StringProperty usernameProperty() {
        return username;
    }


}
