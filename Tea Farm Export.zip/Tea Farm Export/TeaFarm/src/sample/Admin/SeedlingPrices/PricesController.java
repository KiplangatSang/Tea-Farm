package sample.Admin.SeedlingPrices;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

import sample.DatabaseConnections.DBConnection;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class PricesController implements Initializable {
    @FXML
     private Button tabledeletebtn;

    @FXML
    private ComboBox yearselectcb;

    @FXML
    private ComboBox monthselectcb;

    @FXML
    private TableView<PriceDetails> pricestv;

    @FXML
    private TableColumn<PriceDetails, String> typecol;

    @FXML
    private TableColumn<PriceDetails, String> bagsizecol;

    @FXML
    private TableColumn<PriceDetails, Double> pricecol;

    @FXML
    private TableColumn<PriceDetails, Integer> amountcol;

    @FXML
    private ComboBox bagsizecb;

    @FXML
    private ComboBox typecb;

    @FXML
    private TextField pricetf;

    @FXML
    private TextField amounttf;

    @FXML
    private Button savebtn;
    DBConnection do1;
    String type,month,date,description;
    double price;
    int year,amount;
    ObservableList tabledata;



    @Override
    public void initialize(URL location, ResourceBundle resources) {


    setDate();
    // this.farmerid = FarmerLoginDetails.getUserid();
    do1 = new DBConnection();

        try {
        setyearcb();
        setmonthcb();
        setButtonActions();
        setcomboboxesactions();
        setBagssizecb();
        setSeedlingTypes();
            setsqlqueryfortable2();

    } catch (
    SQLException throwables) {
        throwables.printStackTrace();
    }

}


    //set button actions
    private void setButtonActions(){
        savebtn.setOnAction(e->{
            try {
               getUserInput();
                setsqlqueryfortable("year",year,"month",month);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        tabledeletebtn.setOnAction(e->{
            try {
                rundeletequery();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
    }

    //setting comboboxes actions
    private void setcomboboxesactions() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{

                }
        );
    }



    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = (String) monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {

        setsqlqueryfortable("year",year,"month",month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data
    private void setyearcb() throws SQLException {
        ObservableList<Integer> datayears  = FXCollections.observableArrayList();
        String query=" select distinct(year) from seedlingprices ";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }
    private void setmonthcb() throws SQLException {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
        monthselectcb.getItems().addAll(datamonths);

    }

    //set date

    //setting date and time
    private void setDate(){
        LocalDate currentDate = LocalDate.now();
        DayOfWeek getDayOfWeek =currentDate.getDayOfWeek();
        this.date = LocalDate.now().toString();
        this.month = currentDate.getMonth().toString();
        this.year= currentDate.getYear();
    }

    //set input comboboxes
    //set bagsize cb
    private void setBagssizecb() throws SQLException {
        ObservableList bagsizes = FXCollections.observableArrayList();
        String query=" select distinct(description) from seedlingprices ";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            bagsizes.add(rs.getString(1));
        }
        rs.close();
        con.close();
        bagsizecb.getItems().addAll(bagsizes);


    }
    //set Fertilizer Types
    private void setSeedlingTypes() throws SQLException {
        ObservableList fertilizertypes = FXCollections.observableArrayList();
        String query=" select distinct(type) from seedlingprices ";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            fertilizertypes.add(rs.getString(1));
        }
        rs.close();
        con.close();
        typecb.getItems().addAll(fertilizertypes);



    }

    //get user input
    private void getUserInput() throws SQLException {
        if(typecb.getValue()!="" && bagsizecb.getValue()!="" && pricetf.getText()!="" && amounttf.getText()!="" ){

            if(typecb.getValue()!= null && bagsizecb.getValue()!= null &&  pricetf.getText()!= null &&  amounttf.getText()!= null){

                type = typecb.getValue().toString();
                description= bagsizecb.getValue().toString();
                price =Double.parseDouble(pricetf.getText());
                amount = Integer.parseInt(amounttf.getText());
                selectSeedlingamount(type, description, amount, price);


                //clearng inputs
                typecb.setValue(null);
                bagsizecb.setValue(null);
                pricetf.setText("");
                amounttf.setText("");
                setSeedlingTypes();
                setBagssizecb();

            }else{
                new PricesAlertBox("No null values");
            }

        }else{
            new PricesAlertBox("Fill in all values");

        }


    }
    //Saving data to database
    private void savedatatodb(String item,String description,int seedlingno,double price) throws SQLException {
        String insertquery = "Insert into seedlingprices(type,description,price,amount,month,year) values('"+type+"','"+description+"','"+price+"','"+amount+"','"+month+"','"+year+"')";
        Connection con = do1.connect();
        Statement statement = con.prepareStatement(insertquery);
        statement.execute(insertquery);
        statement.close();
        con.close();
    }


    //add user input to table
    //adding user input to table
    private void adduserinputtotable(String type,String bagsize,double price,int amount) throws SQLException {
        ObservableList<PriceDetails> inputtabledata = FXCollections.observableArrayList();
        String bagsizekg = bagsize+ " kg bag";
        inputtabledata.addAll(new PriceDetails(type,bagsizekg,price,amount));
        pricestv.setItems(inputtabledata);


    }
    //getting amoint of items
    int seedlingamt;
    private int selectSeedlingamount(String item,String description,int seedlingno,double price) throws SQLException {
        String query = "Select type,amount from seedlingprices where type = '"+item+"' && description = '"+description+"'";
        System.out.println(query);
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        if(rs.next()){
           seedlingamt = rs.getInt(2);
           seedlingamt = seedlingamt + seedlingno;
           updateSeedlingamount( rs.getString(1), description, seedlingamt,price);
            System.out.println("item present");
            rs.close();
            con.close();
        }else{
            savedatatodb(item, description, seedlingno, price);
            System.out.println("Item Absent");
            rs.close();
            con.close();
        }

        addinputtotable(item, description, seedlingno, price);
       return seedlingamt;
    }

    //update seedling amount
    private void updateSeedlingamount(String item,String description,int amount,double price) throws SQLException {
        String query = "update  seedlingprices set amount = '"+amount+"', price = '"+price+"' where type = '"+item+"' && description = '"+description+"'";
        System.out.println(query);
        Connection con = do1.connect();
        Statement stat  = con.prepareStatement(query);
        stat.execute(query);
        stat.close();
        con.close();

    }

    // run insertion of inputs
    private void addinputtotable(String item,String description,int amount,double price) throws SQLException {
        adduserinputtotable(item,description,price,amount);
        setsqlqueryfortable2();
    }

    //set table
    //sql query for setting table
    private void setsqlqueryfortable(String key1, int value1, String key2, String value2) throws SQLException {
        String sqlquery = "select type,description, price ,amount from seedlingprices where  "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"'";
        setTable(sqlquery);
    }

    //sql query for setting table
    private void setsqlqueryfortable2() throws SQLException {
        String sqlquery = "select type,description, price ,amount from seedlingprices";
        setTable(sqlquery);
    }
    //setting table
    public void setTable(String sqlquery) throws SQLException {
        pricestv.getItems().clear();
        pricestv.setEditable(true);

        setDate();
        do1 = new DBConnection();
        Connection conn = do1.connect();
        tabledata = FXCollections.observableArrayList();

        System.out.println(sqlquery);

        ResultSet rs = conn.createStatement().executeQuery(sqlquery);

        while (rs.next()){

            tabledata.add(new PriceDetails(rs.getString(1),rs.getString(2),rs.getDouble(3),rs.getInt(4)));

            typecol.setCellValueFactory(new PropertyValueFactory<>("type"));
            bagsizecol.setCellValueFactory(new PropertyValueFactory<>("description"));
            amountcol.setCellValueFactory(new PropertyValueFactory<>("amount"));
            pricecol.setCellValueFactory(new PropertyValueFactory<>("price"));


            //setting taable items
            pricestv.setItems(tabledata);
            updateTableData();
        }

    }
    //update table
    private void updateTableData(){

        typecol.setCellFactory(TextFieldTableCell.forTableColumn());
        bagsizecol.setCellFactory(TextFieldTableCell.forTableColumn());
        pricecol.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        amountcol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));

        typecol.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<PriceDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<PriceDetails, String> event) {
              PriceDetails priceDetails= event.getRowValue();


                String oldtype = event.getOldValue();
                String newtype = event.getNewValue();

                //getting the change difference


                //getters
                Double price= priceDetails.getPrice();
                String description =priceDetails.getDescription();

                //setters

                priceDetails.setType(newtype);

                try {
                    updateStringdetails("seedlingprices","type", newtype, "type" ,oldtype,"description",description);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        bagsizecol.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<PriceDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<PriceDetails, String> event) {
               PriceDetails priceDetails= event.getRowValue();

                double dayTotal,monthlyTotal,yearlyTotal,changeDifference;
                String oldPriceAmount = event.getOldValue();
                String newPriceAmount = event.getNewValue();


                //getters

                //setters
                priceDetails.setDescription(newPriceAmount);

                String columnnameValue= priceDetails.getType();
                String description= priceDetails.getDescription();
                try {
                    updateStringdetails("seedlingprices","price",newPriceAmount, "type" ,columnnameValue,"description" ,description);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        pricecol.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<PriceDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<PriceDetails, Double> event) {
               PriceDetails priceDetails= event.getRowValue();

                double oldprice = event.getOldValue();
                double newprice = event.getNewValue();

                //getters

                //setters

                priceDetails.setPrice(newprice);
                String type= priceDetails.getType();
                String description= priceDetails.getDescription();;
                try {
                    updatedetails("seedlingprices","price",newprice,"type" ,type,"description",description);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );
        amountcol.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<PriceDetails, Integer>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<PriceDetails, Integer> event) {
               PriceDetails priceDetails= event.getRowValue();

                int  oldamount = event.getOldValue();
                int newamount = event.getNewValue();

                //getters

                //setters

                priceDetails.setAmount(newamount);
                String type= priceDetails.getType();
                String description= priceDetails.getDescription();
                try {
                    updatedetails("seedlingprices","amount",newamount,"type" ,type,"description",description);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

    }

    // update method
    // update methods with String and Double values as foreign keys
    private void updateStringdetails(String dataTable,String wheretoupdate,String newValue, String key1 ,String value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    // update methods with String and String Values as foreign keys
    private void updatedetails(String dataTable,String wheretoupdate,double newValue, String key1 ,String value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    private void rundeletequery() throws SQLException {
        getItemsToDelete();
        removeItemsFromTable();
    }

    private void getItemsToDelete() throws SQLException {
        String type,description;
        double price;
        double amount;

        PriceDetails priceDetails = pricestv.getSelectionModel().getSelectedItem();
        type = priceDetails.getType();
        price =priceDetails.getPrice();
        amount = priceDetails.getAmount();
        description = priceDetails.getDescription();
        deleteSelectedItemsFromDB("seedlingprices","type",type, "price",price, "description",description);



    }


    private void removeItemsFromTable(){

        ObservableList<PriceDetails> removedData,tabledata;
        tabledata = pricestv.getItems();
        removedData =  pricestv.getSelectionModel().getSelectedItems();
        removedData.forEach(tabledata::remove);

    }
    //delete items from table

    private void deleteSelectedItemsFromDB(String Database,String key1,String value1, String key2,double value2, String key3,String value3) throws SQLException {
        String deleteQuery = "delete from "+Database+" where "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"' && "+key3+" = '"+value3+"'";

        System.out.println(deleteQuery);

        do1 = new DBConnection();
        Connection conn =do1.connect();
        Statement statement =(Statement)conn.prepareStatement(deleteQuery);
        statement.execute(deleteQuery);
        statement.close();
        conn.close();


    }



}

