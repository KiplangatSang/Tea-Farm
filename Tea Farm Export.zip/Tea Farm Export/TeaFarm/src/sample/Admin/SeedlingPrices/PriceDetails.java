package sample.Admin.SeedlingPrices;

import javafx.beans.property.*;

public class PriceDetails {

    private final StringProperty type;
    private final StringProperty description;
    private final DoubleProperty price;
    private final IntegerProperty amount;



    public PriceDetails(String type,String description,double price,int amount){
        this.type = new SimpleStringProperty(type);
        this.description = new SimpleStringProperty(description);
        this.amount = new SimpleIntegerProperty(amount);
        this.price = new SimpleDoubleProperty(price);
    }

    //getters
    public String getType() {
        return type.get();
    }
    public double getPrice() {
        return price.get();
    }
    public String getDescription() {
        return description.get();
    }
    public double getAmount() {
        return amount.get();
    }

    //setters

    public void setType(String value) {
        type.set(value);
    }
    public void setPrice(double value) {
        price.set(value);
    }
    public void setDescription(String value) {
        description.set(value);
    }
    public void setAmount(int value) {
        amount.set(value);
    }

    //property setting
    public StringProperty typeProperty() {
        return type;
    }
    public DoubleProperty  priceProperty() {
        return price;
    }
    public StringProperty descriptionProperty() {
        return description;
    }
    public IntegerProperty amountProperty() {
        return amount;
    }


}
