package sample.Admin.Sales.Admin;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class SalesDetails {
        private final StringProperty item;
        private final DoubleProperty price;
        private final StringProperty dateSold;
        private final DoubleProperty amount;




        public SalesDetails(String item, double price, double amount, String dateSold){
            this.item = new SimpleStringProperty(item);
            this.price = new SimpleDoubleProperty(price);

            this.dateSold = new SimpleStringProperty(dateSold);
            this.amount = new SimpleDoubleProperty(amount);

        }

        //getters
        public String getItem() {
            return item.get();
        }
        public double getPrice() {
            return price.get();
        }

        public String getDateSold() {
            return dateSold.get();
        }

        public double getAmount() {
            return amount.get();
        }
        //setters

        public void setItem(String value) {
            item.set(value);
        }
        public void setPrice(double value) {
            price.set(value);
        }

        public void setAmount(double value) {
            amount.set(value);
        }
        public void setDateSold(String value) {
            dateSold.set(value);
        }


        //property setting
        public StringProperty itemProperty() {
            return item;
        }
        public DoubleProperty priceProperty() {
            return price;
        }
        public DoubleProperty amountProperty() {
            return amount;
        }
        public StringProperty dateSoldProperty() {
            return dateSold;
        }

    }
