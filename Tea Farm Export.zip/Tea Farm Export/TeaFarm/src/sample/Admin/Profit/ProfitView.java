package sample.Admin.Profit;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ProfitView  {

    static  Stage stage = new Stage();
    public void display(String title)  {


        try {
            Parent profitroot  = FXMLLoader.load(getClass().getResource("Profit.fxml"));
            stage.setScene(new Scene(profitroot,1300,650));
            stage.setTitle(title);
            //stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void closeWindow(){
        stage.close();
    }
}
/*
    @Override
    public void start(Stage primaryStage) throws Exception {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("Profit.fxml"));
            primaryStage.setScene(new Scene(root));
            primaryStage.setTitle("Company Profit");
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
*/