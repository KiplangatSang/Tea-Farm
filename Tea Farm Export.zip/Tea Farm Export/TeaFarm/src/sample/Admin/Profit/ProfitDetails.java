package sample.Admin.Profit;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ProfitDetails {
    private final StringProperty expenses;
    private final DoubleProperty cost;
    private final StringProperty sales;
    private final DoubleProperty revenue;



    public ProfitDetails(String expenses, double cost){
        this.expenses = new SimpleStringProperty(expenses);
        this.cost = new SimpleDoubleProperty(cost);
        this.sales = new SimpleStringProperty();
        this.revenue = new SimpleDoubleProperty();

    }


    public ProfitDetails( double revenue,String sales){
        this.expenses = new SimpleStringProperty();
        this.cost = new SimpleDoubleProperty();
        this.sales = new SimpleStringProperty(sales);
        this.revenue = new SimpleDoubleProperty(revenue);

    }

    //getters
    public String getExpenses() {
        return expenses.get();
    }
    public double getCost() {
        return cost.get();
    }

    public String getSales() {
        return sales.get();
    }

    public double getRevenue() {
        return revenue.get();
    }
    //setters

    public void setExpenses(String value) {
        expenses.set(value);
    }
    public void setCost(double value) {
        cost.set(value);
    }

    public void setRevenue(double value) {
        revenue.set(value);
    }
    public void setSales(String value) {
        sales.set(value);
    }


    //property setting
    public StringProperty expensesProperty() {
        return expenses;
    }
    public DoubleProperty costProperty() {
        return cost;
    }
    public DoubleProperty revenueProperty() {
        return revenue;
    }
    public StringProperty salesProperty() {
        return sales;
    }


}
