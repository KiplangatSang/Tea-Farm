package sample.Admin.Login.Admin;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class AdminLoginDetails {
    public static StringProperty username;
    public static IntegerProperty userid;
    public static StringProperty password;

    public AdminLoginDetails(String username,int userid,String password){

        this.username = new SimpleStringProperty(username);
        this.password = new SimpleStringProperty(password);
        this.userid = new SimpleIntegerProperty(userid);
    }


    //getters

    public static String getUsername() {
        return username.get();
    }
    public static String getPassword() {
        return password.get();
    }
    public static int getUserid() {
        return userid.get();
    }


    //setters

    public void setUsername(String value) {
        username.set(value);
    }
    public void setPassword(String value) {
        password.set(value);
    }
    public void setUserid(String value) {
        userid.set(Integer.parseInt(value));
    }

    //property setting

    public StringProperty usernameProperty() {
        return username;
    }
    public IntegerProperty useridProperty() {
        return userid;
    }
    public StringProperty passwordProperty() {
        return password;
    }

}
