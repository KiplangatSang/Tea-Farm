package sample.Admin.Fertilizer.Admin;

import javafx.beans.property.*;

public class FertilizerDetails {
    private final IntegerProperty farmerid;
    private final StringProperty fertilizertype;
    private final IntegerProperty amount;
    private final DoubleProperty bagsize;
    private final DoubleProperty price;
    private final StringProperty dateSold;
    private final StringProperty orderid;
    private final StringProperty status;



    public FertilizerDetails(int farmerid, String fertilizertype,double bagsize,int amount,  double price, String dateSold, String orderid,String status){
        this.farmerid = new SimpleIntegerProperty(farmerid);
        this.fertilizertype = new SimpleStringProperty(fertilizertype);
        this.bagsize = new SimpleDoubleProperty(bagsize);
        this.amount = new SimpleIntegerProperty(amount);
        this.price = new SimpleDoubleProperty(price);
        this.dateSold = new SimpleStringProperty(dateSold);
        this.orderid = new SimpleStringProperty(orderid);
        this.status = new SimpleStringProperty(status);


    }

    //getters
    public String getFertilizertype() {
        return fertilizertype.get();
    }
    public Integer getFarmerid() {
        return farmerid.get();
    }
    public double getPrice() {
        return price.get();
    }
    public double getBagsize() {
        return bagsize.get();
    }
    public String getDateSold() {
        return dateSold.get();
    }

    public double getAmount() {
        return amount.get();
    }
    public String getOrderid() {
        return orderid.get();
    }

    public String getStatus() {
        return status.get();
    }


    //setters
    public void setFarmerid(int value) {
        farmerid.set(value);
    }
    public void setFertilizertype(String value) {
        fertilizertype.set(value);
    }

    public void setPrice(double value) {
        price.set(value);
    }
    public void setBagsize(double value) {
        bagsize.set(value);
    }
    public void setAmount(int value) {
        amount.set(value);
    }
    public void setDateSold(String value) {
        dateSold.set(value);
    }
    public void setOrderid(String value) {
        orderid.set(value);
    }
    public void setStatus(String value) {
        status.set(value);
    }


    //property setting
    public IntegerProperty farmeridProperty() {
        return farmerid;
    }
    public StringProperty fertilizertypeProperty() {
        return fertilizertype;
    }
    public DoubleProperty priceProperty() {
        return price;
    }
    public DoubleProperty bagsizeProperty() {
        return bagsize;
    }
    public IntegerProperty amountProperty() {
        return amount;
    }
    public StringProperty datesoldProperty() {
        return dateSold;
    }
    public StringProperty orderidProperty() {
        return orderid;
    }
    public StringProperty statusProperty() {
        return status;
    }
}