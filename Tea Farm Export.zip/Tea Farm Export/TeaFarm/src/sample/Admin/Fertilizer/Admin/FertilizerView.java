package sample.Admin.Fertilizer.Admin;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sample.Admin.Expenses.Admin.ExpensesView;

import java.io.IOException;

public class FertilizerView {
/*
    @Override
    public void start(Stage primaryStage) throws Exception {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("Fertilizer.fxml"));
            primaryStage.setScene(new Scene(root));
            primaryStage.setTitle("Company Sales");
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}*/
    static Stage  stage;
    public void display(String title)  {
        stage = new Stage();

        try {
            Parent salesroot= FXMLLoader.load(getClass().getResource("Fertilizer.fxml"));
            stage.setScene(new Scene(salesroot,1300,650));
            stage.setTitle(title);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public static void closeWindow(){
        stage.close();
        new ExpensesView();
    }
}







    /*
   static Stage  stage;
    public void display(String title)  {
        stage = new Stage();

        try {
            Parent salesroot= FXMLLoader.load(getClass().getResource("Fertilizer.fxml"));
            stage.setScene(new Scene(salesroot,1300,650));
            stage.setTitle(title);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public static void closeWindow(){
        stage.close();
        new ExpensesView();
    }
}
  */