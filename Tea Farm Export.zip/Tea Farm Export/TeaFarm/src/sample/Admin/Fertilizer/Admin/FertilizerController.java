package sample.Admin.Fertilizer.Admin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import sample.Admin.FertilizerPrices.PricesView;
import sample.Admin.Login.Admin.AdminLoginDetails;
import sample.Admin.Profit.ProfitController;
import sample.Admin.Sales.Admin.SalesController;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Fertilizer.Farmer.FertilizerAlertBox;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class FertilizerController implements Initializable {
    @FXML
    private Button fertilizerpricesbtn;

    @FXML
    private Label totalfertilizersaleslb;

    @FXML
    private Label totalfertilizerbagslb;

    @FXML
    private Label kgsorderedlb;

    @FXML
    private ListView fertilizertypelv;

    @FXML
    private TableView<FertilizerDetails> fertilizertableview;

    @FXML
    private TableColumn<FertilizerDetails,String> farmeridcolumn;

    @FXML
    private TableColumn<FertilizerDetails,String> typecolumn;

    @FXML
    private TableColumn<FertilizerDetails, Double> bagsizecolumn;

    @FXML
    private TableColumn<FertilizerDetails, Integer> amountcolumn;

    @FXML
    private TableColumn<FertilizerDetails, Double> pricecolumn;

    @FXML
    private TableColumn<FertilizerDetails,String> datecolumn;

    @FXML
    private TableColumn<FertilizerDetails,String> orderidcolumn;

    @FXML
    private TableColumn<FertilizerDetails,String> statuscolumn;

    @FXML
    private TextField farmeridtf;


    @FXML
    private ComboBox<?> fertilizertypecb;

    @FXML
    private ComboBox<?> bagssizecb;

    @FXML
    private TextField amounttf;

    @FXML
    private Button orderbtn;

    @FXML
    private Button tableDeleteButton;

    @FXML
    private ComboBox<Integer> yearselectcb;

    @FXML
    private ComboBox<String> monthselectcb;


    DBConnection do1;

    String  fertilizertype,orderid,dateoforder,status,date,month;
    double cost;double price = 0,bagsize;
    int noofbags,farmerid,year,adminid;
    ObservableList<FertilizerDetails> tabledata;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setDate();
        do1 = new DBConnection();
       this.adminid = AdminLoginDetails.getUserid();

        try {
            setyearcb();
            setmonthcb();
            setButtonActions();
            setcomboboxesaction();
            getFertilizertype();
            setBagssizecb();
            setfertilizerdeliverylvquery(year,month);
            settotalfertilizerkgslbquery( year,  month);
            settotalfertilizernolbquery(year,  month);
            settotalferytilizercostlbquery(year,  month);
            setsqlqueryfortable(year,  month);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    //set button actions
    private void setButtonActions(){
        orderbtn.setOnAction(e->{
            try {
                runinsertions();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        tableDeleteButton.setOnAction(e->
        {
            try {
                rundeletequery();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        fertilizerpricesbtn.setOnAction(e->
                new PricesView().display("Fertilizer Prices")
                );
    }

    //setting comboboxes actions
    private void setcomboboxesaction() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{
                    try {
                        getSelectedatedata(year,month);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
        );
        bagssizecb.setOnAction(e-> {
            try {
                setSelectedPrice();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });

    }



    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = (String) monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {
        setfertilizerdeliverylvquery(year,month);
        settotalfertilizerkgslbquery(year,month);
        settotalfertilizernolbquery(year,month);
        settotalferytilizercostlbquery(year,month);

        setsqlqueryfortable(year,month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data
    private void setyearcb() throws SQLException {
        ObservableList<Integer>datayears  = FXCollections.observableArrayList();
        String query=" select distinct(year) from fertilizerorders ";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }
    private void setmonthcb() throws SQLException {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
        monthselectcb.getItems().addAll(datamonths);

    }


    //setting date and time
    private void setDate(){
        LocalDate currentDate = LocalDate.now();
        DayOfWeek getDayOfWeek =currentDate.getDayOfWeek();
        this.date = LocalDate.now().toString();
        this.month = currentDate.getMonth().toString();
        this.year= currentDate.getYear();
    }
    //set bagsize cb
    private void setBagssizecb(){
        ObservableList bagsizes = FXCollections.observableArrayList();
        bagsizes.addAll("25 ","50 ","90");
        bagssizecb.getItems().addAll(bagsizes);
    }
    //set Fertilizer Types
    //getting fertilizertypes

    private void getFertilizertype() throws SQLException {
        ObservableList fertilizertypes = FXCollections.observableArrayList();
        String myquery = "select type from fertilizerprices";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(myquery);
        while(rs.next()){
            fertilizertypes.addAll(rs.getString(1));
        }
        rs.close();
        con.close();
        setFertilizeType( fertilizertypes);
    }

    private void setFertilizeType(ObservableList Fertilizertypes){

        fertilizertypecb.getItems().addAll(Fertilizertypes);
    }

    // getting prices
    private void setSelectedPrice() throws SQLException {
       if( fertilizertypecb.getValue()!= null) {
           String type = fertilizertypecb.getValue().toString();
           double bag = Double.parseDouble(bagssizecb.getValue().toString());

           String query = " select price from fertilizerprices where type = '" + type + "' && description = '" + bag + "'";
           System.out.println(query);
           Connection con = do1.connect();
           ResultSet rs = con.createStatement().executeQuery(query);
           while (rs.next()) {
               price = rs.getDouble(1);
           }
           rs.close();
           con.close();
           System.out.println(price);
       }


    }

    //getting user input
    private void getUserInput(){
        if( fertilizertypecb.getValue() != "" && bagssizecb.getValue() != "" && amounttf.getText()!=""){
            if(fertilizertypecb.getValue() != null && bagssizecb.getValue() != "" && amounttf.getText()!=null){
                try{
                    farmerid = Integer.parseInt(farmeridtf.getText());
                    fertilizertype =  fertilizertypecb.getValue().toString();
                    noofbags= Integer.parseInt(amounttf.getText());
                    this.cost = noofbags * price;
                    bagsize = Double.parseDouble(bagssizecb.getValue().toString());
                    status = "Received";

                    clearinputfields();
                }catch (Exception e){
                    new FertilizerAlertBox("null values not accepted");
                }

            }else{
              new  FertilizerAlertBox("null values not accepted");
            }
        }else{
            new FertilizerAlertBox("Fill in all values");
        }

    }


    //saving user input

    //generating orderid
    private String generateorderid(int farmerid,String date ,int amount ){
        String orderid = date+"/"+farmerid+"/"+amount;
        this.orderid = orderid;
        return orderid;
    }

    //set insert sql query
    String query;
    public void setsqlinputinsert()  {
        query = "insert into fertilizerorders(farmerid,fertilizertype ,bagsize,fertilizeramount , fertilizerprice ,date ,orderid, status,month,year)" +
                " values('"+farmerid+"','"+fertilizertype+"' ,'"+bagsize+"' ,'"+noofbags+"' , '"+cost+"' ,'"+date+"' ,'"+orderid+"', '"+status+"', '"+month+"', '"+year+"')";

    }

    //saving data to database
    private void saveinputdatatoDb(String query) throws SQLException {
        Connection con = do1.connect();
        Statement statement = con.prepareStatement(query);
        statement.execute(query);
        statement.close();
        con.close();
        //saving to sales table
        new SalesController().savesales(adminid,fertilizertype,cost,noofbags, date,month,year);

    }

    //adding user input to table
    private void adduserinputtotable(int farmeid,String type,double bagsize,int amount,double price,String date,String orderid,String status) throws SQLException {
        ObservableList<FertilizerDetails> inputtabledata = FXCollections.observableArrayList();
        inputtabledata.addAll(new FertilizerDetails(farmeid,type,bagsize,amount,price,date,orderid,status));
        fertilizertableview.setItems(inputtabledata);
        setsqlqueryfortable(year,month);
    }

    //perform insertions
    private void runinsertions() throws SQLException {
        getUserInput();
        generateorderid(farmerid,date ,noofbags);
        setsqlinputinsert();
        saveinputdatatoDb(query);
        adduserinputtotable(farmerid,fertilizertype,bagsize,noofbags,cost,dateoforder,orderid,status);
        setExpensetotable(farmerid,fertilizertype,cost,dateoforder,month,year);
        setfertilizerdeliverylvquery(year,month);
        settotalfertilizerkgslbquery(year,month);
        settotalfertilizernolbquery(year,month);
        settotalferytilizercostlbquery(year,month);


    }
    //clear input fields
    private void clearinputfields() throws SQLException {
        farmeridtf.setText("");
        fertilizertypecb.setValue(null);
        bagssizecb.setValue(null);
        amounttf.setText("");

        getFertilizertype();
        setBagssizecb();

    }

    //insert expense to expenses
    private void  setExpensetotable(int farmerid,String  workdone , double cost ,String datepaid,  String month, int year) throws SQLException {
        String sqlquery = "insert into farmerexpenses(farmerid, workdone , cost ,datepaid, month, year)  values ('"+farmerid+"','"+workdone+"' , '"+cost+"' ,'"+datepaid+"', '"+month+"', '"+year+"')";
        Connection con = do1.connect();
        Statement st = con.prepareStatement(sqlquery);
        st.execute(sqlquery);
        st.close();
        con.close();
    }


    //sql query for setting table
    private void setsqlqueryfortable( int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select farmerid,fertilizertype,bagsize,fertilizeramount , fertilizerprice ,date ,orderid, status from fertilizerorders where year = '"+year+"'";

        }   else {
             sqlquery = "select farmerid,fertilizertype,bagsize,fertilizeramount , fertilizerprice ,date ,orderid, status from fertilizerorders where year = '"+year+"' && month = '"+month+"'";
        }
        setTable(sqlquery);
    }

    //setting table
    public void setTable(String sqlquery) throws SQLException {
        fertilizertableview.getItems().clear();
        fertilizertableview.setEditable(true);

        setDate();
        do1 = new DBConnection();
        Connection conn = do1.connect();
        tabledata = FXCollections.observableArrayList();

        System.out.println(sqlquery);

        ResultSet rs = conn.createStatement().executeQuery(sqlquery);

        while (rs.next()){

            tabledata.add(new FertilizerDetails(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getInt(4),rs.getDouble(5), rs.getString(6), rs.getString(7),rs.getString(8)));

            farmeridcolumn.setCellValueFactory(new PropertyValueFactory<>("farmerid"));
            typecolumn.setCellValueFactory(new PropertyValueFactory<>("fertilizertype"));
            bagsizecolumn.setCellValueFactory(new PropertyValueFactory<FertilizerDetails, Double>("bagsize"));
            amountcolumn.setCellValueFactory(new PropertyValueFactory<>("amount"));
            pricecolumn.setCellValueFactory(new PropertyValueFactory<>("price"));
            datecolumn.setCellValueFactory(new PropertyValueFactory<>("dateSold"));
            orderidcolumn.setCellValueFactory(new PropertyValueFactory<>("orderid"));
            statuscolumn.setCellValueFactory(new PropertyValueFactory<>("status"));

            //setting taable items
            fertilizertableview.setItems(tabledata);

        }
        updateTableData();
    }

    //setting labels

    //setting sql quey for totalSeedlingcostlb
    private String settotalferytilizercostlbquery(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(fertilizerprice) from fertilizerorders where farmerid= farmerid && year= '"+year+"'";

        }   else {
             sqlquery = "select SUM(fertilizerprice) from fertilizerorders where farmerid= farmerid && year= '"+year+"' && month = '"+month+"'";
        }
        totalfertilizercostlb(sqlquery);
        return sqlquery;
    }

    //setting cost label
    private void totalfertilizercostlb(String totalSeedlingcostquery) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(totalSeedlingcostquery);
        while(rs.next()){
            totalfertilizersaleslb.setText(String.valueOf(rs.getDouble(1)));
        }
        rs.close();
        con.close();
    }



    //setting sql query for totalfertilizeramountlb

    private String settotalfertilizernolbquery(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(fertilizeramount) from fertilizerorders where farmerid= farmerid && year = '" + year + "'";

        }   else {
             sqlquery = "select SUM(fertilizeramount) from fertilizerorders where farmerid= farmerid && year = '" + year + "' && month = '" + month + "'";
        }
        settotalfertilizernolb(sqlquery);
        return sqlquery;
    }

    private void settotalfertilizernolb(String totalseedlingno) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(totalseedlingno);
        while(rs.next()){

            totalfertilizerbagslb.setText(String.valueOf(rs.getDouble(1)));
        }
        rs.close();
        con.close();
    }

    //setting sql query for totalfertilizerkgslb

    private String settotalfertilizerkgslbquery(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(bagsize * fertilizeramount) from fertilizerorders where farmerid= farmerid && year = '" + year + "'";

        }   else {
             sqlquery = "select SUM(bagsize * fertilizeramount) from fertilizerorders where farmerid= farmerid && year = '" + year + "' && month = '" + month + "'";
        }
        settotalfertilizerkglb(sqlquery);
        return sqlquery;
    }

    private void settotalfertilizerkglb(String totalseedlingno) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(totalseedlingno);
        while(rs.next()){
            kgsorderedlb.setText(String.valueOf(rs.getDouble(1)));
        }
        rs.close();
        con.close();
    }

    //setting seedlingdeliverylv
    private String setfertilizerdeliverylvquery(   int year, String month) throws SQLException {
        String sqlquery = "select type ,amount  from fertilizerprices";
        setFertilizerdeliverylv(sqlquery);
        return sqlquery;
    }

    private void setFertilizerdeliverylv(String fertilizeramount) throws SQLException {
        ObservableList fertilizerondelivery = FXCollections.observableArrayList();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(fertilizeramount);
        while(rs.next()){
            fertilizerondelivery.addAll(rs.getString(1) +"     Amount  : " +rs.getInt(2));
        }

        fertilizertypelv.setItems(fertilizerondelivery);

        rs.close();
        con.close();
    }

    private void updateTableData(){

        //setting taable items
        fertilizertableview.setItems(tabledata);

        typecolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        bagsizecolumn.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        amountcolumn.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        pricecolumn.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        statuscolumn.setCellFactory(ComboBoxTableCell.forTableColumn("Received","Allocated","Delivered"));

        typecolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<FertilizerDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<FertilizerDetails, String> event) {
                FertilizerDetails fertilizerDetails = event.getRowValue();


                String oldType = event.getOldValue();
                String newType = event.getNewValue();

                //getting the change difference


                //getters
                Double cost= fertilizerDetails.getPrice();
                String orderid =fertilizerDetails.getOrderid();


                //setters

                fertilizerDetails.setFertilizertype(newType);

                try {
                    updateStringdetails("fertilizerorders","fertilizertype", newType, "fertilizerprice" ,cost,"orderid",orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        bagsizecolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<FertilizerDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<FertilizerDetails, Double> event) {
                FertilizerDetails fertilizerDetails = event.getRowValue();


                double oldbagsize = event.getOldValue();
                double newbagsize = event.getNewValue();


                //setters
                fertilizerDetails.setBagsize(newbagsize);

                String orderid= fertilizerDetails.getOrderid();
                Double  price = fertilizerDetails.getPrice();
                try {
                    updateStringdetails("fertilizerorders","bagsize",String.valueOf(newbagsize), "fertilixerprice" ,price,"orderid" ,orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();

                }
            }
        } );

        amountcolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<FertilizerDetails, Integer>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<FertilizerDetails, Integer> event) {
                FertilizerDetails fertilizerDetails = event.getRowValue();

                int  oldamount = event.getOldValue();
                int newamount = event.getNewValue();

                //getters

                //setters

                fertilizerDetails.setAmount(newamount);
                String orderid= fertilizerDetails.getOrderid();
                Double price = fertilizerDetails.getPrice();
                try {
                    updateintegerdetails("fertilizerorders","fertilizeramount",newamount,"fertilizerprice" ,price,"orderid",orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        pricecolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<FertilizerDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<FertilizerDetails, Double> event) {
                FertilizerDetails fertilizerDetails = event.getRowValue();


              Double oldprice = event.getOldValue();
                Double newprice = event.getNewValue();

                //getting the change difference


                //getters
                String datepaid =fertilizerDetails.getDateSold();
                String orderid =fertilizerDetails.getOrderid();
                //setters

                fertilizerDetails.setPrice(newprice);

                try {
                    updatedoubledetails("fertilizerorders","fertilizerprice", newprice, "date" ,datepaid,"orderid",orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        statuscolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<FertilizerDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<FertilizerDetails, String> event) {
                FertilizerDetails fertilizerDetails = event.getRowValue();

                String oldstatus = event.getOldValue();
                String newstatus = event.getNewValue();

                //getters

                //setters

                fertilizerDetails.setStatus(newstatus);
                  String orderid= fertilizerDetails.getOrderid();
                Double price= fertilizerDetails.getPrice();
                int fertamount = (int) fertilizerDetails.getAmount();
                 double fertbagsize =fertilizerDetails.getBagsize();
                 String ferttype    = fertilizerDetails.getFertilizertype();

                if(newstatus == "Allocated"){
                    try {
                        selectFertFromdb(ferttype, fertbagsize,fertamount);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
                try {
                    updateStringdetails("fertilizerorders","status",newstatus,"fertilizerprice" ,price,"orderid",orderid);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );
    }

    // update method
    // update methods with String and Double values as foreign keys
    private void updateStringdetails(String dataTable,String wheretoupdate,String newValue, String key1 ,double value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    // update methods with double and String Values as foreign keys
    private void updatedoubledetails(String dataTable,String wheretoupdate,double newValue, String key1 ,String value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"' && "+key2+" ='"+value2+"'";
                      System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }
    // update methods with integer and String Values as foreign keys
    private void updateintegerdetails(String dataTable,String wheretoupdate,int newValue, String key1 ,double value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }
    private void rundeletequery() throws SQLException {
        getItemsToDelete();
        removeItemsFromTable();
    }

    private void getItemsToDelete() throws SQLException {
        String type,orderid;
       int farmerid;

        FertilizerDetails fertilizerDetails = fertilizertableview.getSelectionModel().getSelectedItem();
        type = fertilizerDetails.getFertilizertype();
        farmerid =fertilizerDetails.getFarmerid();
        orderid = fertilizerDetails.getOrderid();

        deleteSelectedItemsFromDB("fertilizerorders","fertilizertype",type, "farmerid",farmerid, "orderid",orderid);



    }


    private void removeItemsFromTable(){

        ObservableList<FertilizerDetails> removedData,tabledata;
        tabledata = fertilizertableview.getItems();
        removedData =  fertilizertableview.getSelectionModel().getSelectedItems();
        removedData.forEach(tabledata::remove);

    }

    private void deleteSelectedItemsFromDB(String Database,String key1,String value1, String key2,double value2, String key3,String value3) throws SQLException {
        String deleteQuery = "delete from "+Database+" where "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"' && "+key3+" = '"+value3+"'";

        System.out.println(deleteQuery);

        do1 = new DBConnection();
        Connection conn =do1.connect();
        Statement statement =(Statement)conn.prepareStatement(deleteQuery);
        statement.execute(deleteQuery);
        statement.close();
        conn.close();


    }
   //check if item exists in Table
    ;
    private void  selectFertFromdb(String type, double bagsize, int amount) throws SQLException {
        String selectquery = "Select amount from fertilizerprices where type = '"+type+"' && description = '"+bagsize+"'";
        System.out.println(selectquery);
        do1 =  new DBConnection();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(selectquery);
        if(rs.next()){

            int dbfertamount= rs.getInt(1);
            System.out.println(dbfertamount +"dbfertamount");

            dbfertamount = dbfertamount - amount;
            System.out.println(dbfertamount +"dbfertamount + amount" );
            updateFertilizerPriceTable( type, bagsize,dbfertamount);
        }

        rs.close();
        con.close();
    }

    // update fertilizerprices table fro amount available
    private void updateFertilizerPriceTable(String type, double bagsize,int dbfertamount) throws SQLException {
        String updatequery = "Update fertilizerprices set amount = '"+dbfertamount+"',month = '"+month+"',year = '"+year+"' where type = '"+type+"' && description='"+bagsize+"'";
        System.out.println(updatequery);
        do1 =  new DBConnection();
        Connection con = do1.connect();
        Statement statement = con.prepareStatement(updatequery);
        statement.execute(updatequery);
        statement.close();
        con.close();

        setfertilizerdeliverylvquery(year,month);
    }

}
