package sample.Admin.Employee.Admin;

import javafx.beans.property.*;

public class RegisterEmployeeDetails {
    private final StringProperty empname;
    private final IntegerProperty empid;
    private final IntegerProperty empage;
    private final StringProperty gender;
    private final IntegerProperty phoneno;
    private final StringProperty address;
    private final StringProperty bankacc;
    private final DoubleProperty empsalary;
    private final StringProperty department;
    private final StringProperty dateemployed;






    public RegisterEmployeeDetails( String empname, int empid, int empage,String gender,int phoneno,String address,String bankacc, double empsalary, String department, String dateemployed){
        this.empname = new SimpleStringProperty(empname);
        this.empid = new SimpleIntegerProperty(empid);
        this.empage = new SimpleIntegerProperty(empage);
        this.gender = new SimpleStringProperty(gender);
        this.phoneno = new SimpleIntegerProperty(phoneno);
        this.address = new SimpleStringProperty(address);
        this.bankacc = new SimpleStringProperty(bankacc);
        this.empsalary = new SimpleDoubleProperty(empsalary);
        this.department = new SimpleStringProperty(department);
        this.dateemployed = new SimpleStringProperty(dateemployed);


    }

    //getters

    public String getEmpName() {
        return empname.get();
    }
    public int getEmpId(){return empid.get();}
    public int getEmpAge(){return empage.get();}
    public String getGender(){return gender.get();}
    public int getPhoneno(){return phoneno.get();}
    public String getAddress(){return address.get();}
    public String getBankacc(){return bankacc.get();}
    public double getEmpSalary() {
        return empsalary.get();
    }

    public String getDepartment() {
        return department.get();
    }
    public String getDateEmployed() {
        return dateemployed.get();
    }


    //setters

    public void setEmpName(String value) { empname.set(value); }
    public void setEmpId(int value) {
        empid.set(value);
    }
    public void setEmpAge(int value) {
        empage.set(value);
    }
    public void setGender(String value) {
        gender.set(value);
    }
    public void setPhoneno(int value) {
        phoneno.set(value);
    }
    public void setAddress(String value) {
        address.set(value);
    }
    public void setBankacc(String value) {
        bankacc.set(value);
    }
    public void setEmpSalary(double value) {
        empsalary.set(value);
    }
    public void setDepartment(String value) {
        department.set(value);
    }
    public void setDateEmployed(String value) {
        dateemployed.set(value);
    }


    //property setting

    public StringProperty empnameProperty() {
        return empname;
    }
    public IntegerProperty empidProperty(){return empid;}
    public IntegerProperty empageProperty(){return empage;}
    public StringProperty genderProperty(){return gender;}
    public IntegerProperty phonenoProperty(){return phoneno;}
    public StringProperty addressProperty(){return address;}
    public StringProperty bankaccProperty(){return bankacc;}
    public DoubleProperty empsalaryProperty() {
        return empsalary;
    }
    public StringProperty departmentProperty() {
        return department;
    }
    public StringProperty dateemployedProperty() {
        return dateemployed;
    }

}


