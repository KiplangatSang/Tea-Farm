package sample.Admin.Employee.Admin;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class RegisterEmployeeAlertBox {

    private static Scene scene1;
    private static Stage window1;
    Stage window;
    Scene scene;
    public RegisterEmployeeAlertBox(String message){
        window = new Stage();
        Label label = new Label();
        label.setText(message);

        Button button = new Button();
        button.setText("Okey");
        button.setOnAction(e ->closeWindow());

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.getChildren().add(label);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20,20,20,20));
        hbox1.getChildren().add(button);


        BorderPane pane = new BorderPane();
        pane.setCenter(hbox);
        pane.setBottom(hbox1);
        scene = new Scene(pane,300,200);

        //window
        window.setResizable(false);
        window.setScene(scene);
        window.initModality(Modality.APPLICATION_MODAL);
        window.show();
    }
    public void closeWindow(){
        window.close();

    }

    public static void closeWindow1(){
        window1.close();

    }
    public static void closeWindow2(){
        window1.close();

    }
    public static void cancelWindow(String message){
        window1 = new Stage();
        Label label1 = new Label();
        // label1.setStyle("-fx-background-color:red");
        label1.setPadding(new Insets(10,10,10,10));
        label1.setText(message);

        Button okeybtn = new Button();
        okeybtn.setText("Yes");
        // okeybtn.setStyle("-fx-background-color:red");
        okeybtn.setOnAction(e ->closeWindow2());
        Button cancelbtn = new Button();
        cancelbtn.setText("No");
        cancelbtn.setStyle("-fx-background-color:green");
        cancelbtn.setOnAction(e ->closeWindow1());

        Region region = new Region();
        region.setMinWidth(70);

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.getChildren().add(label1);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20,20,20,20));
        hbox1.getChildren().addAll(okeybtn,region,cancelbtn);


        BorderPane pane = new BorderPane();
        pane.setCenter(hbox);
        pane.setBottom(hbox1);
        scene1 = new Scene(pane,300,200);

        //window
        window1.setResizable(false);
        window1.setScene(scene1);
        window1.initModality(Modality.APPLICATION_MODAL);
        window1.show();
    }


}
