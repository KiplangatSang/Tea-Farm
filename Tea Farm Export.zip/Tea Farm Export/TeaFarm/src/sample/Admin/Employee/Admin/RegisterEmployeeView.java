package sample.Admin.Employee.Admin;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class RegisterEmployeeView {


/*

    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {

        try {
            Parent newroot = FXMLLoader.load(getClass().getResource("RegisterEmployee.fxml"));
            primaryStage.setScene(new Scene(newroot));
            primaryStage.setTitle("Farm System");
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}*/
    static Stage stage = new Stage();
    public void display(String title) {

        try {
            Parent registerEmployee = FXMLLoader.load(getClass().getResource("RegisterEmployee.fxml"));
            stage.setScene(new Scene(registerEmployee, 1300,650));
            stage.setTitle("Register Employee");
            //stage.initModality(Modality.WINDOW_MODAL);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void closeWindow(){
        stage.close();
    }
    }
