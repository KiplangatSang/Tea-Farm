package sample.Admin.Employee.Admin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;
import sample.DatabaseConnections.DBConnection;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class RegisterEmployeeController implements Initializable {
    @FXML
    private AnchorPane empancpane;

    @FXML
    private VBox dashboardVbox;

    @FXML
    private Label noofworkerslb;

    @FXML
    private Label totalsalarypaidlb;

    @FXML
    private Label averageempagelb;

    @FXML
    private ListView<?> noofempperdepartmentlv;

    @FXML
    private TableView<RegisterEmployeeDetails> employeeTable;

    @FXML
    private TableColumn<RegisterEmployeeDetails,String> columnGender;

    @FXML
    private TableColumn<RegisterEmployeeDetails,String> columnEmpName;

    @FXML
    private TableColumn<RegisterEmployeeDetails,Integer> columnEmpID;

    @FXML
    private TableColumn<RegisterEmployeeDetails,Integer> columnEmpAge;

    @FXML
    private TableColumn<RegisterEmployeeDetails,Double> columnEmpSalary;

    @FXML
    private TableColumn<RegisterEmployeeDetails,String> columnEmpDepartment;

    @FXML
    private TableColumn<RegisterEmployeeDetails,String> columnDateEmployed;
    @FXML
    private TableColumn<RegisterEmployeeDetails,String> phonenocol;

    @FXML
    private TableColumn<RegisterEmployeeDetails,String> addresscol;

    @FXML
    private TableColumn<RegisterEmployeeDetails,String> bankaccountcol;

    @FXML
    private TextField empNametf;

    @FXML
    private TextField empIDtf;

    @FXML
    private TextField empAgetf;

    @FXML
    private RadioButton empFemalerb;

    @FXML
    private ToggleGroup togglegroup;

    @FXML
    private RadioButton empMalerb;

    @FXML
    private TextField phonenotf;

    @FXML
    private TextField addresstf;

    @FXML
    private TextField bankaccounttf;

    @FXML
    private TextField empDepartmenttf;

    @FXML
    private TextField empSalarytf;

    @FXML
    private DatePicker dateEmployedcb;

    @FXML
    private Button saveEmployeebtn;

    @FXML
    private ComboBox<String> monthselectcb;

    @FXML
    private ComboBox<Integer> yearselectcb;

    @FXML
    private Button tableDeleteButton;


    DBConnection do1;
    ObservableList data,departmentsAvailable;
    String date,month;
    String empname,department,dateemployed,gender="",address,bankaccount;
    int empid,empage,empcount,year,phoneno;
    double salary, averageage,totalsalary;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        setLabelDate();
        do1 = new DBConnection();
        getGender();
        setButtonActions();


        try {
            setmonthcb();
            setyearcb();
            setcomboboxesactions();
            setnoofempperdepartmentlv();
           setlabels("year",year,"month",month);
            setemptable();
        } catch (SQLException throwables) {
            new RegisterEmployeeAlertBox("Data Error ");

            throwables.printStackTrace();
        }

    }


    //setting comboboxes actions
    private void setcomboboxesactions() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{

                }
        );
    }



    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {

        setlabels("year",year,"month",month);
        setsqlqueryfortable("year",year,"month",month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data

    private void setyearcb() throws SQLException {
        ObservableList<Integer>datayears  = FXCollections.observableArrayList();
        String query= " select distinct(year) from companyemployees";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }

    private void setmonthcb() {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
        monthselectcb.getItems().addAll(datamonths);

    }
    //setting button actions
    private void setButtonActions(){
        saveEmployeebtn.setOnAction(e-> {
            try {
                saveDataToDB();
                addingInputDatatoTable();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });

        tableDeleteButton.setOnAction(e-> {
            try {
                rundeletequery();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });

    }

    // getting and setting date
    public void setLabelDate(){
        LocalDate currentDate = LocalDate.now();
        DayOfWeek getDayOfWeek =currentDate.getDayOfWeek();
        this.date = LocalDate.now().toString();
        this.month = currentDate.getMonth().toString();
        this.year= currentDate.getYear();

    }
    //sql query for setting table
    private void setsqlqueryfortable(String key1, int value1, String key2, String value2) throws SQLException {
        String sqlquery = "select * from companyemployees where  "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"'";
        System.out.println(sqlquery);
        setTable(sqlquery);
    }
    //sql query for setting table
    private void setemptable() throws SQLException {
        String sqlquery = "select * from companyemployees";
        System.out.println(sqlquery);
        setTable(sqlquery);
    }

    // getting data from database and setting it to table
    public void setTable(String sqlquery) throws SQLException {
        employeeTable.setEditable(true);

        Connection conn = do1.connect();
        data = FXCollections.observableArrayList();
        ResultSet rs = conn.createStatement().executeQuery(sqlquery);

        while (rs.next()) {

        data.add(new RegisterEmployeeDetails(rs.getString(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getInt(6), rs.getString(7),rs.getString(8), rs.getDouble(9), rs.getString(10), rs.getString(11)));


            columnEmpName.setCellValueFactory(new PropertyValueFactory<>("empname"));
            columnEmpID.setCellValueFactory(new PropertyValueFactory<>("empid"));
            columnEmpAge.setCellValueFactory(new PropertyValueFactory<>("empage"));
            columnGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
            phonenocol.setCellValueFactory(new PropertyValueFactory<>("phoneno"));
            addresscol.setCellValueFactory(new PropertyValueFactory<>("gender"));
            bankaccountcol.setCellValueFactory(new PropertyValueFactory<>("bankacc"));
            columnEmpSalary.setCellValueFactory(new PropertyValueFactory<>("empsalary"));
            columnEmpDepartment.setCellValueFactory(new PropertyValueFactory<>("department"));
            columnDateEmployed.setCellValueFactory(new PropertyValueFactory<>("dateemployed"));

            //setting taable items
            employeeTable.setItems(data);

        }

        updateTableData();
    }
    // getting the departmments available
    public void getDepartments() throws SQLException {
        departmentsAvailable = FXCollections.observableArrayList();
        do1 = new DBConnection();
        String query = "SELECT DISTINCT(empdepartment) FROM `companyemployees`";

        Connection conn = do1.connect();
        ResultSet resultSet1 = conn.createStatement().executeQuery(query);
        while (resultSet1.next()) {
            String depEmp = resultSet1.getString(1);
            departmentsAvailable.add(depEmp);
        }
        conn.close();


    }

    //setting listview of department workers
    public void setnoofempperdepartmentlv() throws SQLException {
        getDepartments();
        ObservableList departmentemp = FXCollections.observableArrayList();

        departmentsAvailable.forEach((depatments) ->{
            String query = "SELECT count(empname) FROM companyemployees WHERE empdepartment = '"+depatments+"'";

            Connection conn = do1.connect();
            ResultSet resultSet1 = null;
            try {
                resultSet1 = conn.createStatement().executeQuery(query);
                while (resultSet1.next()) {
                    String depEmp = depatments+" :  " +resultSet1.getInt(1);
                    departmentemp.add(depEmp);
                }
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        });


        noofempperdepartmentlv.setItems(departmentemp);

    }

    //getting inputed data
    private void getInputData(){
        if(empNametf.getText()!="null" && empAgetf.getText()!= "" && empIDtf.getText()!= "" &&gender !="" && phonenotf.getText()!=""){
            if(addresstf.getText()!="" && bankaccounttf.getText()!="" && empDepartmenttf.getText()!="" && empSalarytf.getText()!=""){
                if(dateEmployedcb.getValue()!= null){
                    try{
                        Integer.parseInt(phonenotf.getText());
                        Integer.parseInt(empAgetf.getText());
                        try{
                            Double.parseDouble(empSalarytf.getText());

                            empname = empNametf.getText();
                            empid = Integer.parseInt(empIDtf.getText());
                            empage = Integer.parseInt(empAgetf.getText());
                            String gender = this.gender;
                            phoneno = Integer.parseInt(phonenotf.getText());
                            address = addresstf.getText();
                            bankaccount = bankaccounttf.getText();
                            department = empDepartmenttf.getText();
                            salary = Double.parseDouble(empSalarytf.getText());
                            dateemployed = dateEmployedcb.getValue().toString();

                        }catch(Exception salaryex){
                           new    RegisterEmployeeAlertBox("input correct Salary");
                        }
                    }catch (Exception phonnoex){
                        new RegisterEmployeeAlertBox("input correct Phone number or Age");
                    }

                }else{
                    new RegisterEmployeeAlertBox("Input Date Employed");
                }

            }else{
                new RegisterEmployeeAlertBox("Input Correct data");
            }

        } else{
            new RegisterEmployeeAlertBox("Input Correct data");
        }
    }

    //saving inputed data
    private void saveDataToDB() throws SQLException {
        getInputData();
        getGender();
        Connection conn = do1.connect();

        String insertquery = "insert into companyemployees(empname,empid,empage,empgender,phoneno,address,bankacc,empsalary,empdepartment,dateemployed,month,year) values('"+empname+"','"+empid+"','"+empage+"','"+gender+"','"+phoneno+"','"+address+"','"+bankaccount+"','"+salary+"','"+department+"','"+dateemployed+"','"+month+"','"+year+"')";
        System.out.println(insertquery);

        Statement stat = conn.prepareStatement(insertquery);
        stat.execute(insertquery);

    }

   // adding inputed data to table
    private void addingInputDatatoTable() throws SQLException {
        getInputData();
        getGender();
        data.add(new RegisterEmployeeDetails(empname,empid,empage,gender,phoneno,address,bankaccount,salary,department,dateemployed));
        setsqlqueryfortable("year",year,"month",month);

        empAgetf.clear();
        empNametf.clear();
        empIDtf.clear();
        empSalarytf.clear();
        empDepartmenttf.clear();
        employeeTable.setItems(data);
        phonenotf.clear();
        addresstf.clear();
        bankaccounttf.clear();
        dateEmployedcb.setValue(null);

    }

    //posting monthly salary to expense table

    //inserting
    public void insertEmployeeExpense(String work,double cost,String mydate,String mymonth,int myyear ) throws SQLException {
       do1 = new DBConnection();
        Connection conn = do1.connect();
        String insertquery = "insert into companyexpenses(workdone,cost,paid,datepaid,month,year)" +
                "values('"+work+"','"+ cost +"','yes','"+mydate+"','"+mymonth+"','"+myyear+"')";



        Statement stat =conn.prepareStatement(insertquery);
        stat.execute(insertquery);
        stat.close();
        conn.close();

    }

    //checking if already inserted
    private void postmonthlysalary(String work,double cost,String mydate,String mymonth, int myyear) throws SQLException {


            Connection conn = do1.connect();
            try {

                ResultSet expenseresultset = conn.createStatement().executeQuery("Select workdone,cost from companyexpenses where workdone =' Salary' && month ='" + mymonth+ "'");
                if(expenseresultset.next()){
                   System.out.println(expenseresultset.getString(1)+ expenseresultset.getDouble(2));
               }
                else{
                    insertEmployeeExpense(work,cost,mydate,mymonth,myyear);
                }
               expenseresultset.close();
            } catch (SQLException throwables) {


            }
          conn.close();
    }

    //updating monthly salary dues for the month
    public  void setmonthlysalarytodb(String key1, int value1, String key2, String value2) throws SQLException {
        getTotalSalaryPaid(key1, value1,key2,value2);
        postmonthlysalary("Salary",totalsalary,date,month,year);
    }


    //getting data from database for number of employees
    private void getNumberOfEmployees(String key1, int value1, String key2, String value2) throws SQLException {

        String query = "SELECT count(empname) FROM `companyemployees`";

        Connection conn = do1.connect();
        ResultSet resultSet1 = conn.createStatement().executeQuery(query);
        while (resultSet1.next()) {
    empcount = resultSet1.getInt(1);
        }
        resultSet1.close();
        conn.close();
    }

    //Calculating total salary paid
    private void getTotalSalaryPaid(String key1, int value1, String key2, String value2) throws SQLException {

        String query = "SELECT sum(empsalary) FROM `companyemployees` ";

        Connection conn = do1.connect();
        ResultSet resultSet1 = conn.createStatement().executeQuery(query);
        while (resultSet1.next()) {
            totalsalary =resultSet1.getDouble(1);
        }
        resultSet1.close();
        conn.close();

    }


    //calculating average employee age
private void calculateAverageEmployeeAge(String key1, int value1, String key2, String value2) throws SQLException {

    do1 = new DBConnection();
    String query = "SELECT AVG(empage) FROM `companyemployees`";

    Connection conn = do1.connect();
    ResultSet resultSet1 = conn.createStatement().executeQuery(query);
    while (resultSet1.next()) {
             this.averageage = resultSet1.getDouble(1);
    }
    conn.close();
}

    // setting labels
public void setlabels(String key1, int value1, String key2, String value2){
    try {
        getNumberOfEmployees( key1,  value1,  key2,  value2);
        calculateAverageEmployeeAge(key1,  value1,  key2,  value2);
        getTotalSalaryPaid(key1,  value1,  key2,  value2);
    } catch (SQLException throwables) {
        throwables.printStackTrace();
    }
    averageempagelb.setText(String.valueOf(averageage));
        noofworkerslb.setText(String.valueOf(empcount));
        totalsalarypaidlb.setText(String.valueOf(totalsalary));
}

//getting gender
private void getGender(){
    empFemalerb.setOnAction(e->setFemale());
    empMalerb.setOnAction(e->setMale());

}

    //setting gender methods

    public void setMale(){
        gender ="Male";
    }
    public void setFemale(){
        gender = "Female";
    }



    // checking if salaries of the  month have  been posted

    public void checkmonthsalary(String key1, int value1, String key2, String value2) throws SQLException {
        try {
            String query = "SELECT Salary FROM internalcosts";
            Connection conn = do1.connect();
            ResultSet resultSet1 = null;
            resultSet1 = conn.createStatement().executeQuery(query);
            while (resultSet1.next()) {
                String depEmp = resultSet1.getString(1);
              System.out.println("Salaries added");
            }
            conn.close();

        } catch (SQLException throwables) {
            getTotalSalaryPaid(key1,value1,key2, value2);
            savecost("Salary",totalsalary,date,month,year );
          //  System.out.println("Salaries has just been added");

        }

    }
    private void savecost(String work,double cost,String date,String month,int year ) throws SQLException {

        String insertquery = "Insert into companyexpenses(workdone,cost,paid,datepaid,month)values('"+ work+"','"+ cost+"','Yes','"+ date+"','"+ month+"','"+ year+"')";
        Connection connect = do1.connect();
        Statement stat = connect.prepareStatement(insertquery);
        stat.execute(insertquery);


    }

    private void updateTableData(){

        columnEmpName.setCellFactory(TextFieldTableCell.forTableColumn());
        columnEmpID.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        columnEmpAge.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        columnGender.setCellFactory(TextFieldTableCell.forTableColumn());
        columnEmpSalary.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        columnEmpDepartment.setCellFactory(TextFieldTableCell.forTableColumn());
        columnDateEmployed.setCellFactory(TextFieldTableCell.forTableColumn());

        columnEmpName.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<RegisterEmployeeDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<RegisterEmployeeDetails, String> event) {
                RegisterEmployeeDetails registerEmployeeDetails = event.getRowValue();


                String oldEmpName = event.getOldValue();
                String newEmpName = event.getNewValue();

                //getting the change difference


                //getters
                String columnDateEmployedValue =registerEmployeeDetails.getDateEmployed();
                Integer columnIdValue = registerEmployeeDetails.getEmpId();

                //setters

                registerEmployeeDetails.setEmpName(newEmpName);

                try {
                    updateStringdetails("companyemployees","empname",newEmpName, "empid" ,columnIdValue,"dateemployed" ,columnDateEmployedValue);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        columnEmpID.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<RegisterEmployeeDetails, Integer>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<RegisterEmployeeDetails, Integer> event) {
                RegisterEmployeeDetails registerEmployeeDetails = event.getRowValue();

                double dayTotal,monthlyTotal,yearlyTotal,changeDifference;
                Integer oldEmpID = event.getOldValue();
                Integer newEmpID = event.getNewValue();


                //getters

                //setters


                registerEmployeeDetails.setEmpId(newEmpID);

                String columnnameValue= registerEmployeeDetails.getEmpName();

                try {
                    updateIntegerdetails("companyemployees","empid",newEmpID, "empname" ,columnnameValue,"empid" ,oldEmpID);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        columnEmpAge.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<RegisterEmployeeDetails, Integer>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<RegisterEmployeeDetails, Integer> event) {
                RegisterEmployeeDetails registerEmployeeDetails = event.getRowValue();

                Integer oldEmpAge = event.getOldValue();
                Integer newEmpAge = event.getNewValue();

                //getters

                //setters

                registerEmployeeDetails.setEmpAge(newEmpAge);

                Integer columnIdValue = registerEmployeeDetails.getEmpId();
                String columnnameValue= registerEmployeeDetails.getEmpName();
                try {
                    updateIntegerdetails("companyemployees","empage",newEmpAge, "empname" ,columnnameValue,"empid" ,columnIdValue);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );


     columnGender.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<RegisterEmployeeDetails, String>>() {
        @Override
        public void handle(TableColumn.CellEditEvent<RegisterEmployeeDetails, String> event) {
            RegisterEmployeeDetails registerEmployeeDetails = event.getRowValue();

            String newGender = event.getNewValue();

            //getting the change difference


            //getters

            //setters

            registerEmployeeDetails.setGender(newGender);
            String columnnameValue= registerEmployeeDetails.getEmpName();
            Integer columnIdValue = registerEmployeeDetails.getEmpId();

            try {
                updateStringdetails("companyemployees","empgender",newGender, "empid" ,columnIdValue,"empname" ,columnnameValue);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    } );

        columnEmpSalary.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<RegisterEmployeeDetails, Double>>() {
        @Override
        public void handle(TableColumn.CellEditEvent<RegisterEmployeeDetails, Double> event) {
            RegisterEmployeeDetails registerEmployeeDetails = event.getRowValue();

            double dayTotal,monthlyTotal,yearlyTotal,changeDifference;
            Double oldSalaryAmount = event.getOldValue();
            Double newSalaryAmount = event.getNewValue();

            //getting the change difference
            changeDifference = newSalaryAmount - oldSalaryAmount;

            //getters

            //setters


            registerEmployeeDetails.setEmpSalary(newSalaryAmount);

            String columnnameValue= registerEmployeeDetails.getEmpName();
            Integer columnIdValue = registerEmployeeDetails.getEmpId();

            try {
                updateDoubledetails("companyemployees","empsalary",newSalaryAmount,"empid" ,columnIdValue,"empname" ,columnnameValue);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    } );

        columnEmpDepartment.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<RegisterEmployeeDetails, String>>() {
        @Override
        public void handle(TableColumn.CellEditEvent<RegisterEmployeeDetails, String> event) {
            RegisterEmployeeDetails registerEmployeeDetails = event.getRowValue();

            String oldEmpDepartment = event.getOldValue();
            String newEmpDepartment = event.getNewValue();

            //getters

            //setters

            registerEmployeeDetails.setDepartment(newEmpDepartment);

            String columnnameValue= registerEmployeeDetails.getEmpName();
            Integer columnIdValue = registerEmployeeDetails.getEmpId();

            try {
                updateStringdetails("companyemployees","empdepartment",newEmpDepartment, "empid" ,columnIdValue,"empname" ,columnnameValue);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    } );


 columnDateEmployed.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<RegisterEmployeeDetails, String>>() {
@Override
public void handle(TableColumn.CellEditEvent<RegisterEmployeeDetails, String> event) {
    RegisterEmployeeDetails registerEmployeeDetails = event.getRowValue();

        String oldDate = event.getOldValue();
        String newDate = event.getNewValue();

        //getters

        //setters

    registerEmployeeDetails.setDateEmployed(newDate);
    String columnnameValue= registerEmployeeDetails.getEmpName();
    Integer columnIdValue = registerEmployeeDetails.getEmpId();

    try {
        updateStringdetails("companyemployees","dateemployed",newDate, "empid" ,columnIdValue,"empname" ,columnnameValue);
    } catch (SQLException throwables) {
        throwables.printStackTrace();
    }

}
        } );

}

     //Update database methods

    // update methods with String and Double values as foreign keys
    private void updateStringdetails(String dataTable,String wheretoupdate,String newValue, String key1 ,double value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    // update methods with String and Double Values as foreign keys
    private void updateDoubledetails(String dataTable,String wheretoupdate,double newValue, String key1 ,Integer value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }
    // update methods with String and Integer Values as foreign keys
    private void updateIntegerdetails(String dataTable,String wheretoupdate,Integer newValue, String key1 ,String value1,String key2 ,Integer value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }
    private void rundeletequery() throws SQLException {
        getItemsToDelete();
        removeItemsFromTable();
    }

    private void getItemsToDelete() throws SQLException {
        String name,date;
        int id;

        RegisterEmployeeDetails registerEmployeeDetails = employeeTable.getSelectionModel().getSelectedItem();
        name = registerEmployeeDetails.getEmpName();
        id =registerEmployeeDetails.getEmpId();
        date= registerEmployeeDetails.getDateEmployed();

       deleteSelectedItemsFromDB("employeedata","empname",name, "empid",id, "dateemployed",date);



    }


    private void removeItemsFromTable(){

        ObservableList<RegisterEmployeeDetails> removedData,tabledata;
        tabledata = employeeTable.getItems();
        removedData =  employeeTable.getSelectionModel().getSelectedItems();
        removedData.forEach(tabledata::remove);

    }

    private void deleteSelectedItemsFromDB(String Database,String key1,String value1, String key2,int value2, String key3,String value3) throws SQLException {
        String deleteQuery = "delete from "+Database+" where "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"' && "+key3+" = '"+value3+"'";

        System.out.println(deleteQuery);

        do1 = new DBConnection();
        Connection conn =do1.connect();
        Statement statement =(Statement)conn.prepareStatement(deleteQuery);
        statement.execute(deleteQuery);
        statement.close();
        conn.close();


    }
}
