package sample.Admin.Chatroom.CreatePost;

public class CreatePostDetails {
}
