package sample.Admin.Chatroom.CreatePost;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;

public class CreatePostView  {
    static Stage stage = new Stage();
    public void display(String title) {

        try {
            Parent root = FXMLLoader.load(getClass().getResource("CreatePost.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.initModality(Modality.WINDOW_MODAL);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void closeWindow(){
        stage.close();
    }
}


    /*
    @Override
    public void start(Stage primaryStage) throws Exception {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("CreatePost.fxml"));
            primaryStage.setScene(new Scene(root));
            primaryStage.setTitle("Create Post");
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}*/