package sample.Admin.Chatroom.CreatePost;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import sample.Admin.Chatroom.ViewPosts.PostsView;
import sample.Admin.Login.Admin.AdminLoginDetails;
import sample.DatabaseConnections.DBConnection;
import sample.Images.ImageDetails;


import java.io.*;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

import static sample.Admin.Login.Admin.AdminLoginDetails.userid;

public class CreatePostController implements Initializable {

    @FXML
    private Label datelb;

    @FXML
    private Button chooseimagebtn;

    @FXML
    public HBox uploadivhbox;

    @FXML
    private TextArea uploadta;

    @FXML
    private Button postbtn;

    String message="", uploadimage ="";
    String date, month;
    int year,hour,minute,sec;
    String time;
    int userid;
    String username;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setLabelDate();
        buttonactions();

        this.userid = AdminLoginDetails.getUserid();
        this.username = AdminLoginDetails.getUsername();
    }


    // getting and setting date
    public void setLabelDate(){
        LocalDate currentDate = LocalDate.now();
        DayOfWeek getDayOfWeek =currentDate.getDayOfWeek();
        this.date = LocalDate.now().toString();
        this.month = currentDate.getMonth().toString();
        this.year= currentDate.getYear();
        this.hour = LocalDateTime.now().getHour();
        this.minute = LocalDateTime.now().getMinute();
        this.sec = LocalDateTime.now().getSecond();
        this.time = hour+":"+minute+":"+sec;
        datelb.setText(date);

    }
    private void buttonactions() {
        postbtn.setOnAction(e -> {
            try {
                uploaddatatodb();
                CreatePostView.closeWindow();
                PostsView.closeWindow();
                new PostsView().display("Chats");
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        });
        chooseimagebtn.setOnAction(e -> {
            // new CopyImage().dialogbox();
            //setChooseimagebtn();
            try {
                post();
            } catch (MalformedURLException malformedURLException) {
                malformedURLException.printStackTrace();
            }
        });
    }


    public void post() throws MalformedURLException {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("choose image");
        //Set extension filter
        FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.JPG", "*.PNG", "*.JPEG", "*.JFIF");
        FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.PNG");
        FileChooser.ExtensionFilter extFilterjfif = new FileChooser.ExtensionFilter("JFIF files (*.JFIF)", "*.JFIF");



        chooser.getExtensionFilters().addAll(extFilterJPG, extFilterPNG,extFilterjfif);
        File file = chooser.showOpenDialog(null);
        System.out.println(file.getPath());

        // copy image to images folder
        System.out.println(file.toPath() +" to path");
        File newfile = null;
        try{
            newfile = new File("src\\sample\\Images\\" + file.getName());
            System.out.println("Created");
        }
        catch(Exception ex1){
            System.out.println("cannot create file");
        }
        try{
            System.out.println(newfile.toPath());
            Files.copy(file.toPath(), newfile.toPath());

            System.out.println("Copied");
        }catch (Exception copyex) {
            copyex.printStackTrace();
            System.out.println("cannot copy");
            if (file.exists()) {
                File filefolder = new File("src\\sample\\Images");
                new ImageDetails(file.getName());

            }

        }

        //setting up image
        Image image = new Image(file.toURI().toURL().toExternalForm());
        ImageView uploadiv = new ImageView();
        uploadiv.setFitWidth(300);
        uploadiv.setFitHeight(300);
        uploadiv.setImage(image);
        uploadivhbox.getChildren().add(uploadiv);
        this.uploadimage = newfile.getName();

    }


       private void getUserMessage(){
       this.message =  uploadta.getText();
       }


        // uploading to database


    private void uploaddatatodb() throws SQLException {
        getUserMessage();

        if(uploadimage!=null && message!= ""){
            String insert = "insert into chats(userid,username,chat, imagepath,comments,date,time,month,year) values('"+userid+"','"+username+"','"+message+"','"+uploadimage+"','  ','"+date+"','"+time+"','"+month+"','"+year+"')";
            System.out.println(insert);
            Connection con = new DBConnection().connect();
            Statement stat = con.prepareStatement(insert);
            stat.execute(insert);


        }
        else{
            System.out.println("empty Values");
        }


    }


    //ImageView imageView


    }

