package sample.Images;

import javafx.beans.property.*;

public class ImageDetails {
    private final StringProperty imagename;

    public ImageDetails( String imagename){
        this.imagename = new SimpleStringProperty(imagename);

    }
    //getters
    public String getImagename(){return imagename.get();}
    //setters
    public void setImagename(String value) {
        imagename.set(value);
    }
    //property setting
    public StringProperty imagenameProperty(){return imagename;}


}



