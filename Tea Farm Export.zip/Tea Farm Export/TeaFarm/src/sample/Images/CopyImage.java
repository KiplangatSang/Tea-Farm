package sample.Images;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sample.Admin.Chatroom.CreatePost.CreatePostController;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CopyImage {
    String date,month;
    int year;
    // getting and setting date
    public void setLabelDate(){
        LocalDate currentDate = LocalDate.now();
        DayOfWeek getDayOfWeek =currentDate.getDayOfWeek();
        this.date = LocalDate.now().toString();
        this.month = currentDate.getMonth().toString();
        this.year= currentDate.getYear();

    }

    VBox vBox;
    Button button;
    Label label;
    Image image;
    String filename;
    Scene scene;
    String userid = "3534";
    Stage window;
    public File renamedfile;

    public void dialogbox() {
        label = new Label();
        label.setPadding(new Insets(20, 20, 20, 20));
        label.setText("Choose picture from drive");
        button = new Button("Choose Image");

        button.setPadding(new Insets(5, 5, 5, 5));
        button.setOnAction(e -> {
            try {
                chooseimagefile();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            }
        });


        BorderPane borderPane = new BorderPane();
        borderPane.setMargin(button, new Insets(10, 10, 10, 10));
        borderPane.setMargin(label, new Insets(10, 10, 10, 10));
        borderPane.setTop(label);
        borderPane.setCenter(button);
        vBox = new VBox();
        vBox.getChildren().addAll(borderPane);

        scene = new Scene(vBox, 300, 200);
        //window
        window = new Stage();
        window.setResizable(false);
        window.setScene(scene);
        window.initModality(Modality.APPLICATION_MODAL);
        window.show();
    }

    //renaming file
    private String renameImageFile(File filename) throws IOException {
        setLabelDate();

        String oldfilename = filename.getName();
      System.out.println(oldfilename + "  oldfilename");
        //renaming the file
        try{
            String userid = "35347477";
            String minute = String.valueOf(LocalDateTime.now().toLocalTime().getMinute());
            String hour = String.valueOf(LocalDateTime.now().toLocalTime().getHour());
            String second = String.valueOf(LocalDateTime.now().toLocalTime().getSecond());

            String newfilename = "img" +userid +"_"+hour+"_"+minute+"_"+second;

            System.out.println(newfilename + " new File name");
            filename.renameTo(new File("src\\sample\\Images\\" + newfilename));

        }catch (Exception renameex){
            System.out.println("cannot rename");
            renameex.printStackTrace();
        }

        window.close();

       // new ImageDetails(renamedfile.toString());
       // new CreatePostController().setChooseimagebtn (renamedfile.toString());

        return filename.toString();
    }


    //choosing image file
    private void chooseimagefile() throws IOException {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("choose image");
        //Set extension filter
        FileChooser.ExtensionFilter extFilterJPG = new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.JPG", "*.PNG", "*.JPEG", "*.JFIF");
        FileChooser.ExtensionFilter extFilterPNG = new FileChooser.ExtensionFilter("PNG files (*.png)", "*.PNG");

        chooser.getExtensionFilters().addAll(extFilterJPG, extFilterPNG);
        File file = chooser.showOpenDialog(null);
        File newfile = new File("src\\sample\\Images\\" + file.getName());
        //copying image
        try{
            Files.copy(file.toPath(), newfile.toPath());
            System.out.println("Copied");

        }catch (Exception copyex){
            System.out.println("cannot copy");
            copyex.printStackTrace();
        }

        window.close();
       // new CreatePostController().post(newfile);

        /*
        File filefolder  = new File("/sample\\Images");
                new ImageDetails(newfile.getName());
        //+ newfile.getName()
        Image image = new Image("/sample\\Images\\3534WIN_20200714_08_53_57_Pro.jpg" );
        new CreatePostController().uploadiv.setImage(image);
        //renaming imagefile
        //renameImageFile(newfile);*/

    }

}