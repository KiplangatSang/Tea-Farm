package sample.Farmer.Expenses.Farmer;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ExpensesDetails {
    private final StringProperty work;
    private final DoubleProperty cost;

    private final StringProperty date;



    public ExpensesDetails(String work, double cost, String date){
        this.work = new SimpleStringProperty(work);
        this.cost = new SimpleDoubleProperty(cost);
        this.date = new SimpleStringProperty(date);

    }

    //getters
    public String getWork() {
        return work.get();
    }
    public double getCost() {
        return cost.get();
    }

    public String getDate() {
        return date.get();
    }


    //setters

    public void setWork(String value) {
        work.set(value);
    }
    public void setCost(double value) {
        cost.set(value);
    }

    public void setDate(String value) {
        date.set(value);
    }


    //property setting
    public StringProperty workProperty() {
        return work;
    }
    public DoubleProperty costProperty() {
        return cost;
    }
    public StringProperty dateProperty() {
        return date;
    }


}
