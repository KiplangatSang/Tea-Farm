package sample.Farmer.Expenses.Farmer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;
import sample.Admin.Expenses.Admin.ExpensesAlertBox;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Chatroom.ViewPosts.PostsView;
import sample.Farmer.Login.Farmer.FarmerLoginDetails;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class ExpensesController implements Initializable {

    @FXML
    private MenuItem refreshmi;

    @FXML
    private ComboBox<Integer> yearselectcb;

    @FXML
    private ComboBox<String> monthselectcb;

    @FXML
    private Label totalexpenselb;

    @FXML
    private Label totalsalarieslb;

    @FXML
    private Label electricitybilllb;
    @FXML
    private Label waterbilllb;

    @FXML
    private TextField electricitybilltinputf;

    @FXML
    private TextField waterbilltinputf;


    @FXML
    private CheckBox paidbillcheckbox;

    @FXML
    private Button savebillbtn;

    @FXML
    private TableView<ExpensesDetails> intenalexpensestable;

    @FXML
    private TableColumn<ExpensesDetails, String> workexpensecolumn;

    @FXML
    private TableColumn<ExpensesDetails, Double> amountpaidcolumn;

    @FXML
    private TableColumn<ExpensesDetails, String> datepaidcolumn;

    @FXML
    private TextField workdonetf;

    @FXML
    private TextField amountpaidtf;

    @FXML
    private DatePicker datepaidcb;

    @FXML
    private Button saveexpensebtn;

    @FXML
    private Button tableDeleteButton;

    Double cost,electricitybilltinput= 0.0,totalcost,totalsalaries,electricitybill= 0.0 ,waterbilltinput = 0.0,waterbill = 0.0,servicecost,sprayingcost;

    DBConnection do1;
    ObservableList data;
    String date,month,work,datepaid ;
    int  year ,farmerid;


    String sqlQuery;
    final String classdatabase= "farmerexpenses";
    ObservableList distinctdates;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        do1= new DBConnection();
        setdate();
        setButtonActions();
        farmerid = FarmerLoginDetails.getUserid();

        try {
           // checkemployeesalary();
            setsqlqueryfortable(year,month);
            setLabelsData(year,month);
            setcomboboxesactions();

            setmonthcb();
            setyearcb();



        } catch (SQLException throwables) {
            new sample.Admin.Expenses.Admin.ExpensesAlertBox("Data Error ");

            throwables.printStackTrace();
        }

    }
    //setting comboboxes actions
    private void setcomboboxesactions() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{
                    try {
                        getSelectedatedata(year,month);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
        );
    }



    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {

        setLabelsData( year, month);
        setsqlqueryfortable(year, month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data

    private void setyearcb() throws SQLException {
        ObservableList<Integer>datayears  = FXCollections.observableArrayList();
        String query= " select distinct(year) from farmerexpenses";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }

    private void setmonthcb() {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
        monthselectcb.getItems().addAll(datamonths);

    }


    //setting buttion actions
    private void setButtonActions(){
        savebillbtn.setOnAction(e-> savebillsinput());
        saveexpensebtn.setOnAction(e-> {
            try {
                saveinput();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        tableDeleteButton.setOnAction(e-> {
            try {
                rundeletequery();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        refreshmi.setOnAction(e->refresh());
    }


    //Refresh
    private void refresh(){

        ExpensesView.closeWindow();
        new ExpensesView().display("Farmer Expenses");
    }

    //getting date
    public void setdate(){
        LocalDate currentDate = LocalDate.now();
        this.date = currentDate.toString();
        this.month = currentDate.getMonth().toString();
        this.year=  currentDate.getYear();

    }
    //sql query for setting table
    private void setsqlqueryfortable( int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select workdone ,cost ,datepaid  from farmerexpenses where  farmerid = '" + farmerid + "' && year = '" + year + "'";

        }   else {
             sqlquery = "select workdone ,cost ,datepaid  from farmerexpenses where  farmerid = '" + farmerid + "' && year = '" + year + "' && month = '" + month + "'";
        }
        System.out.println(sqlquery);
        setTable(sqlquery);
    }


    public void setTable(String sqlquery) throws SQLException {
        intenalexpensestable.getItems().clear();
        intenalexpensestable.setEditable(true);
        data = FXCollections.observableArrayList();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()) {
            data.add(new sample.Admin.Expenses.Admin.ExpensesDetails(rs.getString(1), rs.getDouble(2), rs.getString(3)));
            workexpensecolumn.setCellValueFactory(new PropertyValueFactory<>("work"));
            amountpaidcolumn.setCellValueFactory(new PropertyValueFactory<>("cost"));
            datepaidcolumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        }
        rs.close();
        con.close();
        intenalexpensestable.setItems(data);

        updateTableData();
    }

    public void getInput(){
        if(workdonetf.getText()!= "" && amountpaidtf.getText()!= "" && datepaidcb.getValue()!=null){
            try{
                work = workdonetf.getText();
                cost = Double.parseDouble(amountpaidtf.getText());
                date = datepaidcb.getValue().toString();

                //clearing inputs
                workdonetf.clear();
                amountpaidtf.clear();
                datepaidcb.setValue(null);}
            catch(Exception ex){
                new sample.Admin.Expenses.Admin.ExpensesAlertBox("Fill in Correct Values");
            }
        }else{
            new ExpensesAlertBox("Fill in all Values");
        }


    }

    // data insertion to db
    public void insertDatatoDB(int adminid,String work,double cost,String date,String month,int year) throws SQLException {
        DBConnection do1 = new DBConnection();

        String insertquery = "insert into farmerexpenses(farmerid,workdone,cost,datepaid,month,year)" +
                "values('"+farmerid +"','"+work+"','"+ cost +"','"+date+"','"+month+"','"+ year+"')";

        Connection connect = do1.connect();
        Statement stat =connect.prepareStatement(insertquery);
        stat.execute(insertquery);


    }

    // Saving input data
    private void saveinput() throws SQLException {
        ObservableList<ExpensesDetails> userinputdata= FXCollections.observableArrayList();
        getInput();
        System.out.println(work + cost+ date);
        userinputdata.addAll(new ExpensesDetails(work, cost, date));

        intenalexpensestable.setItems(userinputdata);
        insertDatatoDB(farmerid ,work, cost,date,month, year);

    }

    //save electricity bill and water bill
    private void savebillsinput(){
        ObservableList<ExpensesDetails> userinputdata= FXCollections.observableArrayList();
        do1 = new DBConnection();
        try{
            electricitybilltinput =Double.parseDouble(electricitybilltinputf.getText());

            userinputdata.addAll(new ExpensesDetails("Electricity", electricitybilltinput, date));
            intenalexpensestable.setItems(userinputdata);

            String electricityquery = "insert into farmerexpenses(farmerid,workdone,cost,datepaid,month,year)" +
                    "values('"+farmerid+"', 'Electricity','"+electricitybilltinput +"','"+date+"','"+month+"','"+ year+"')";

            Connection connect = do1.connect();
            Statement stat = connect.prepareStatement(electricityquery);
            stat.execute(electricityquery);
            stat.close();
            connect.close();

        }catch(Exception exception){
            electricitybilltinput =0.0;
        }
        try{
            waterbilltinput= Double.parseDouble(waterbilltinputf.getText());
            userinputdata.addAll(new ExpensesDetails("Water", waterbilltinput, date));
            intenalexpensestable.setItems(userinputdata);


            String waterquery = "insert into farmerexpenses(farmerid, workdone,cost,datepaid,month,year)" +
                    "values('"+farmerid+"','Water','"+waterbilltinput +"','"+date+"','"+month+"','"+ year+"')";

            Connection connect = do1.connect();
            Statement stat = connect.prepareStatement(waterquery);
            stat.execute(waterquery);
            stat.close();
            connect.close();

        }catch(Exception exception){
            waterbilltinput =0.0;
        }
        electricitybilllb.setText(electricitybilltinput.toString());
        waterbilllb.setText(waterbilltinput.toString());

        electricitybilltinputf.clear();
        waterbilltinputf.clear();
    }


    //get labels data

    // get Total Salaries
    public void getTotalSalaries(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(cost) from farmerexpenses where workdone = 'Salaries' &&  farmerid = '" + farmerid + "' &&  year = '" + year + "'";

        }   else {
             sqlquery = "select SUM(cost) from farmerexpenses where workdone = 'Salaries' &&  farmerid = '" + farmerid + "' &&  year = '" + year + "' && month = '" + month + "'";
        }
        Connection con =do1.connect();
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            totalsalaries = rs.getDouble(1);
        }
        rs.close();
        con.close();
    }


    // get Total Salaries
    public void getTotalExpenses(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(cost) from farmerexpenses where farmerid= '" + farmerid + "' && year = '" + year + "'";

        }   else {
             sqlquery = "select SUM(cost) from farmerexpenses where farmerid= '" + farmerid + "' && year = '" + year + "' && month = '" + month + "'";
        }
        Connection con =do1.connect();
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            totalcost = rs.getDouble(1);
        }
        rs.close();
        con.close();
    }
    //get electricity bill
    public void getelectricitybill(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(cost) from farmerexpenses where workdone = 'Electricity' && farmerid = '" + farmerid + "' && year = '" + year + "'";

        }   else {
             sqlquery = "select SUM(cost) from farmerexpenses where workdone = 'Electricity' && farmerid = '" + farmerid + "' && year = '" + year + "' && month = '" + month + "'";
        }
        Connection con =do1.connect();
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            electricitybill = rs.getDouble(1);
        }
        rs.close();
        con.close();
    }

    //get waterbill
    public void getwaterbill(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(cost) from farmerexpenses where workdone = 'Water' && farmerid= '"+farmerid+"' && year = '"+year+"'";

        }   else {
             sqlquery = "select SUM(cost) from farmerexpenses where workdone = 'Water' && farmerid= '"+farmerid+"' && year = '"+year+"' && month = '"+month+"'";
        }

        Connection con =do1.connect();
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            waterbill = rs.getDouble(1);
        }
        rs.close();
        con.close();    }

    //setting label data
    private void setLabelsData(int year, String month) throws SQLException {
        getTotalExpenses(year,month);
        getTotalSalaries(year,month);
        getelectricitybill(year,month);
        getwaterbill(year,month);

        totalexpenselb.setText(String.valueOf(totalcost));
        totalsalarieslb.setText(String.valueOf(totalsalaries));
        electricitybilllb.setText(String.valueOf(electricitybill));
        waterbilllb.setText(String.valueOf(waterbill));
    }

    //setting employee payments to table
    double  empsalary = 0;
    private void getemployeesalary() throws SQLException {
        String query= "select SUM(empsalary) from farmeremployees where farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        if(rs.next()){
            empsalary = rs.getDouble(1);
        }
        rs.close();
        con.close();
        setemployeesalary( empsalary);
    }

    //setting emp salary to expenses
    private void setemployeesalary(double empsalary) throws SQLException {
        String query = "insert into farmerexpenses(farmerid, workdone,cost,datepaid,month,year)" +
                "values('"+farmerid+"','Salaries','"+empsalary +"','"+date+"','"+month+"','"+ year+"')";

        Connection con = do1.connect();
        Statement stat  = con.prepareStatement(query);
        stat.execute(query);
        stat.close();
        con.close();
    }


    //checking if inputed
    private void checkemployeesalary() throws SQLException {
        String query= "select workdone from farmerexpenses where workdone = 'Salaries' && farmerid = '"+farmerid+"' && year= '"+year+"' && month = '"+month+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        if(rs.next()){
            System.out.println("salary inputed");
            // totalsalarieslb.setText(String.valueOf(rs.getDouble(1)));
        }else{
            System.out.println("No salary");
           // getemployeesalary();
        }
    }




    // updateing expense table
    private void updateTableData(){

        workexpensecolumn.setCellFactory(TextFieldTableCell.forTableColumn());
        amountpaidcolumn.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        datepaidcolumn.setCellFactory(TextFieldTableCell.forTableColumn());

        workexpensecolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<ExpensesDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<ExpensesDetails, String> event) {
               ExpensesDetails internalExpensesDetails = event.getRowValue();


                String oldWork = event.getOldValue();
                String newWork = event.getNewValue();

                //getting the change difference


                //getters
                Double cost= internalExpensesDetails.getCost();
                String datedone =internalExpensesDetails.getDate();

                //setters

                internalExpensesDetails.setWork(newWork);

                try {
                    updateStringdetails("farmerexpenses","workdone", newWork, "cost" ,cost,"workdone",oldWork);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        amountpaidcolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<ExpensesDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<ExpensesDetails, Double> event) {
               ExpensesDetails internalExpensesDetails = event.getRowValue();

                double dayTotal,monthlyTotal,yearlyTotal,changeDifference;
                Double oldPriceAmount = event.getOldValue();
                Double newPriceAmount = event.getNewValue();

                //getting the change difference
                changeDifference = newPriceAmount - oldPriceAmount;

                //getters

                //setters
                internalExpensesDetails.setCost(newPriceAmount);

                String columnnameValue= internalExpensesDetails.getWork();
                String columndatepaidvalue= internalExpensesDetails.getDate();
                try {
                    updateStringdetails("farmerexpenses","cost",newPriceAmount, "workdone" ,columnnameValue,"datepaid" ,columndatepaidvalue);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        datepaidcolumn.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<ExpensesDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<ExpensesDetails, String> event) {
                ExpensesDetails internalExpensesDetails = event.getRowValue();

                String oldDate = event.getOldValue();
                String newDate = event.getNewValue();

                //getters

                //setters

                internalExpensesDetails.setDate(newDate);
                String columnnameValue= internalExpensesDetails.getWork();
                Double columncost = internalExpensesDetails.getCost();
                try {
                    updateStringdetails("farmerexpenses","datepaid",newDate,"cost" ,columncost,"workdone",columnnameValue);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );
    }

    // update method
    // update methods with String and Double values as foreign keys
    private void updateStringdetails(String dataTable,String wheretoupdate,String newValue, String key1 ,double value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"' && farmerid = '"+farmerid+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    // update methods with String and String Values as foreign keys
    private void updateStringdetails(String dataTable,String wheretoupdate,double newValue, String key1 ,String value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  farmerid = '"+farmerid+"' && "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    private void rundeletequery() throws SQLException {
        getItemsToDelete();
        removeItemsFromTable();
    }

    private void getItemsToDelete() throws SQLException {
        String work,datedone;
        double cost;

        ExpensesDetails internalExpensesDetails = intenalexpensestable.getSelectionModel().getSelectedItem();
        work = internalExpensesDetails.getWork();
        cost =internalExpensesDetails.getCost();
        datedone = internalExpensesDetails.getDate();

        deleteSelectedItemsFromDB("farmerexpenses","workdone",work, "cost",cost, "datepaid",datedone);



    }


    private void removeItemsFromTable(){

        ObservableList<ExpensesDetails> removedData,tabledata;
        tabledata = intenalexpensestable.getItems();
        removedData =  intenalexpensestable.getSelectionModel().getSelectedItems();
        removedData.forEach(tabledata::remove);

    }

    private void deleteSelectedItemsFromDB(String Database,String key1,String value1, String key2,double value2, String key3,String value3) throws SQLException {
        String deleteQuery = "delete from "+Database+" where farmerid= '"+farmerid+"' && "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"' && "+key3+" = '"+value3+"'";

        System.out.println(deleteQuery);

        do1 = new DBConnection();
        Connection conn =do1.connect();
        Statement statement =(Statement)conn.prepareStatement(deleteQuery);
        statement.execute(deleteQuery);
        statement.close();
        conn.close();


    }


}

