package sample.Farmer.Fertilizer.Farmer;

import javafx.beans.property.*;

public class FertilizerDetails {
    private final StringProperty fertilizertype;
    private final IntegerProperty amount;
    private final StringProperty bagsize;
    private final DoubleProperty price;
    private final StringProperty dateSold;
    private final StringProperty orderid;
    private final StringProperty status;



    public FertilizerDetails(String fertilizertype,String bagsize,int amount,  double price, String dateSold, String orderid,String status){
        this.fertilizertype = new SimpleStringProperty(fertilizertype);
        this.bagsize = new SimpleStringProperty(bagsize);
        this.amount = new SimpleIntegerProperty(amount);
        this.price = new SimpleDoubleProperty(price);
        this.dateSold = new SimpleStringProperty(dateSold);
        this.orderid = new SimpleStringProperty(orderid);
        this.status = new SimpleStringProperty(status);


    }

    //getters
    public String getFertilizertype() {
        return fertilizertype.get();
    }
    public double getPrice() {
        return price.get();
    }
    public String getBagsize() {
        return bagsize.get();
    }
    public String getDateSold() {
        return dateSold.get();
    }

    public double getAmount() {
        return amount.get();
    }
    public String getOrderid() {
        return orderid.get();
    }

    public String getStatus() {
        return status.get();
    }


    //setters

    public void setFertilizertype(String value) {
        fertilizertype.set(value);
    }
    public void setPrice(double value) {
        price.set(value);
    }
    public void setBagsize(String value) {
        bagsize.set(value);
    }
    public void setAmount(int value) {
        amount.set(value);
    }
    public void setDateSold(String value) {
        dateSold.set(value);
    }
    public void setOrderid(String value) {
        orderid.set(value);
    }
    public void setStatus(String value) {
        status.set(value);
    }


    //property setting
    public StringProperty fertilizertypeProperty() {
        return fertilizertype;
    }
    public DoubleProperty priceProperty() {
        return price;
    }
    public StringProperty bagsizeProperty() {
        return bagsize;
    }
    public IntegerProperty amountProperty() {
        return amount;
    }
    public StringProperty datesoldProperty() {
        return dateSold;
    }
    public StringProperty orderidProperty() {
        return orderid;
    }
    public StringProperty statusProperty() {
        return status;
    }
}