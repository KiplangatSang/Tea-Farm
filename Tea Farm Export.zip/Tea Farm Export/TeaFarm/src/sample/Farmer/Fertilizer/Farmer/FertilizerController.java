package sample.Farmer.Fertilizer.Farmer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Expenses.Farmer.ExpensesController;
import sample.Farmer.Expenses.Farmer.ExpensesView;
import sample.Farmer.Login.Farmer.FarmerLoginDetails;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class FertilizerController implements Initializable {
    @FXML
    private MenuItem refreshmi;

    @FXML
    private Label totalfertilizercostlb;

    @FXML
    private Label totalfertilizerbagslb;

    @FXML
    private Label kgsorderedlb;

    @FXML
    private ListView fertilizertypelv;

    @FXML
    private TableView<FertilizerDetails> fertilizertableview;

    @FXML
    private TableColumn<FertilizerDetails,String> typecolumn;
    @FXML
    private TableColumn<FertilizerDetails,String> bagsizecolumn;

    @FXML
    private TableColumn<FertilizerDetails, Double> amountcolumn;

    @FXML
    private TableColumn<FertilizerDetails, Double> pricecolumn;

    @FXML
    private TableColumn<FertilizerDetails,String> datecolumn;

    @FXML
    private TableColumn<FertilizerDetails,String> orderidcolumn;

    @FXML
    private TableColumn<FertilizerDetails,String> statuscolumn;

    @FXML
    private ComboBox<?> fertilizertypecb;

    @FXML
    private ComboBox<?> bagssizecb;

    @FXML
    private TextField amounttf;

    @FXML
    private Button orderbtn;

    @FXML
    private Button tableDeleteButton;

    @FXML
    private ComboBox<Integer> yearselectcb;

    @FXML
    private ComboBox<String> monthselectcb;


    DBConnection do1;

    String  fertilizertype,bagsize,orderid,dateoforder,status,date,month;
    double cost;
    int noofbags,farmerid,year;
    ObservableList<FertilizerDetails> tabledata;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setDate();
        this.farmerid = FarmerLoginDetails.getUserid();

        do1 = new DBConnection();

        try {
            setyearcb();
            setmonthcb();
            setButtonActions();
            setcomboboxesactions();
            setBagssizecb();
            getFertilizertype();
            setfertilizerdeliverylvquery(year,month);
            settotalfertilizerkgslbquery(year,month);
            settotalfertilizernolbquery(year,month);
            settotalferytilizercostlbquery(year,month);
            setsqlqueryfortable(year,month);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    //set button actions
    private void setButtonActions(){
        orderbtn.setOnAction(e->{
            try {
                runinsertions();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        refreshmi.setOnAction(e->refresh());
    }


    //Refresh
    private void refresh(){

        FertilizerView.closeWindow();
        new FertilizerView().display("Farmer Fertilizer Orders");
    }

    //setting comboboxes actions
    private void setcomboboxesactions() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{
                    try {
                        getSelectedatedata(year,month);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
        );
    }



    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = (String) monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {
        setfertilizerdeliverylvquery(year, month);
        settotalfertilizerkgslbquery(year, month);
        settotalfertilizernolbquery(year, month);
        settotalferytilizercostlbquery(year, month);

        setsqlqueryfortable(year, month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data
    private void setyearcb() throws SQLException {
        ObservableList<Integer>datayears  = FXCollections.observableArrayList();
        String query=" select distinct(year) from fertilizerorders where farmerid= farmerid";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }
    private void setmonthcb() throws SQLException {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
        monthselectcb.getItems().addAll(datamonths);

    }


    //setting date and time
    private void setDate(){
        LocalDate currentDate = LocalDate.now();
        DayOfWeek getDayOfWeek =currentDate.getDayOfWeek();
        this.date = LocalDate.now().toString();
        this.month = currentDate.getMonth().toString();
        this.year= currentDate.getYear();
    }
//set bagsize cb
    private void setBagssizecb(){
        ObservableList bagsizes = FXCollections.observableArrayList();
        bagsizes.addAll("25 kg bag","50 kg bag","90 kg bag");
        bagssizecb.getItems().addAll(bagsizes);
    }
//set Fertilizer Types
    //set Fertilizer Types


    private void getFertilizertype() throws SQLException {
        ObservableList fertilizertypes = FXCollections.observableArrayList();
        String myquery = "select type from fertilizerprices";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(myquery);
        while(rs.next()){
            fertilizertypes.addAll(rs.getString(1));
        }
        rs.close();
        con.close();
        setFertilizeType( fertilizertypes);
    }

    private void setFertilizeType(ObservableList Fertilizertypes){

        fertilizertypecb.getItems().addAll(Fertilizertypes);
    }

    // getting prices

    private void setSelectedPrice(String type ,String bag,int noofbags) throws SQLException {
            String query = " select price from fertilizerprices where type = '" + type + "' && description = '" + bag + "'";
            System.out.println(query);
            double price = 0;
            Connection con = do1.connect();
            ResultSet rs = con.createStatement().executeQuery(query);
            while (rs.next()) {
             price = rs.getDouble(1);
            }
            rs.close();
            con.close();
            System.out.println(price);
            cost = price * noofbags;
    }


    //getting user input
    private void getUserInput(){
        if( fertilizertypecb.getValue() != "" && bagssizecb.getValue() != "" && amounttf.getText()!=""){
            if(fertilizertypecb.getValue() != null && bagssizecb.getValue() != "" && amounttf.getText()!=null){
                try{
                    fertilizertype =  fertilizertypecb.getValue().toString();
                    noofbags= Integer.parseInt(amounttf.getText());
                   String bagsizeinput =  bagssizecb.getValue().toString();
                    if(bagsizeinput == "25 kg bag"){
                        bagsize = "25.0";

                    }else if(bagsizeinput == "50 kg bag"){
                        bagsize = "50.0";

                    }else if(bagsizeinput == "90 kg bag"){
                        bagsize = "90.0";
                    }
                    status = "Received";
                    setSelectedPrice(fertilizertype,bagsize,noofbags);

                    fertilizertypecb.setValue(null);
                    bagssizecb.setValue(null);
                    amounttf.setText("");

                }catch (Exception e){
                    new FertilizerAlertBox("Null values not accepted 1");
                }

            }else{
                new  FertilizerAlertBox("null values not accepted");
            }
        }else{
            new  FertilizerAlertBox("Fill in all values");
        }

    }


    //saving user input

    //generating orderid
    private String generateorderid(int farmerid,String date ,int amount ){
        String orderid = date+"/"+farmerid+"/"+amount;
        this.orderid = orderid;
        return orderid;
    }

    //set insert sql query
    String query;
    public void setsqlinputinsert() throws SQLException {
        query = "insert into fertilizerorders(farmerid,fertilizertype ,bagsize,fertilizeramount , fertilizerprice ,date ,orderid, status,month,year)" +
                " values('"+farmerid+"','"+fertilizertype+"' ,'"+bagsize+"' ,'"+noofbags+"' , '"+cost+"' ,'"+date+"' ,'"+orderid+"', '"+status+"', '"+month+"', '"+year+"')";

        System.out.println(query);
        insertExpenseDatatoDB(farmerid,fertilizertype+" Purchase",cost, date, month, year);
    }

    // data insertion to db
    // expenses insert to expense table
    public void insertExpenseDatatoDB(int farmerid,String work,double cost ,String date, String month,int year){


        try{
            String insertquery = "insert into farmerexpenses(farmerid,workdone,cost,datepaid,month,year)" +
                    "values('"+farmerid+"','"+work+"','"+ cost +"','"+date+"','"+month+"','"+ year+"')";

            Connection connect = do1.connect();
            Statement stat =connect.prepareStatement(insertquery);
            stat.execute(insertquery);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    //saving data to database
    private void saveinputdatatoDb(String query) throws SQLException {
        Connection con = do1.connect();
        Statement statement = con.prepareStatement(query);
        statement.execute(query);
        statement.close();
        con.close();
    }

    //adding user input to table
    private void adduserinputtotable(String type,String bagsize,int amount,double price,String date,String orderid,String status) throws SQLException {
        ObservableList<FertilizerDetails> inputtabledata = FXCollections.observableArrayList();
       String bagsizekg = bagsize+ " kg bag";
        inputtabledata.addAll(new FertilizerDetails(type,bagsizekg,amount,price,date,orderid,status));
        fertilizertableview.setItems(inputtabledata);
        setsqlqueryfortable(year,month);
    }

    //perform insertions
    private void runinsertions() throws SQLException {
        getUserInput();
        generateorderid(farmerid,date ,noofbags);
        setsqlinputinsert();
        saveinputdatatoDb(query);
        adduserinputtotable(fertilizertype,bagsize,noofbags,cost,dateoforder,orderid,status);
        setfertilizerdeliverylvquery(year,month);
        settotalfertilizerkgslbquery(year,month);
        settotalfertilizernolbquery(year,month);
        settotalferytilizercostlbquery(year,month);

    }



    //sql query for setting table
    private void setsqlqueryfortable(int year,String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select fertilizertype,bagsize,fertilizeramount , fertilizerprice ,date ,orderid, status from fertilizerorders where farmerid = '" + farmerid + "' && year = '" + year + "'";

        }   else {
             sqlquery = "select fertilizertype,bagsize,fertilizeramount , fertilizerprice ,date ,orderid, status from fertilizerorders where farmerid = '" + farmerid + "' && year = '" + year + "' && month = '" + month + "'";
        }
        setTable(sqlquery);
    }

    //setting table
    public void setTable(String sqlquery) throws SQLException {
        fertilizertableview.getItems().clear();
        fertilizertableview.setEditable(true);

        setDate();
        do1 = new DBConnection();
        Connection conn = do1.connect();
        tabledata = FXCollections.observableArrayList();

        System.out.println(sqlquery);

        ResultSet rs = conn.createStatement().executeQuery(sqlquery);

        while (rs.next()){

            tabledata.add(new FertilizerDetails(rs.getString(1),rs.getString(2)+" kg bag",rs.getInt(3),rs.getDouble(4), rs.getString(5), rs.getString(6),rs.getString(7)));

            typecolumn.setCellValueFactory(new PropertyValueFactory<>("fertilizertype"));
            bagsizecolumn.setCellValueFactory(new PropertyValueFactory<>("bagsize"));
            amountcolumn.setCellValueFactory(new PropertyValueFactory<>("amount"));
            pricecolumn.setCellValueFactory(new PropertyValueFactory<>("price"));
            datecolumn.setCellValueFactory(new PropertyValueFactory<>("dateSold"));
            orderidcolumn.setCellValueFactory(new PropertyValueFactory<>("orderid"));
            statuscolumn.setCellValueFactory(new PropertyValueFactory<>("status"));

            //setting taable items
            fertilizertableview.setItems(tabledata);
            //updateTableData();
        }

    }

    //setting labels

    //setting sql quey for totalSeedlingcostlb
    private String settotalferytilizercostlbquery(int year,String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(fertilizerprice) from fertilizerorders where farmerid= '" + farmerid + "' && year = '" + year + "'";

        }   else {
             sqlquery = "select SUM(fertilizerprice) from fertilizerorders where farmerid= '" + farmerid + "' && year = '" + year + "' && month = '" + month + "'";
        }
        totalfertilizercostlb(sqlquery);
        return sqlquery;
    }

    //setting cost label
    private void totalfertilizercostlb(String totalSeedlingcostquery) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(totalSeedlingcostquery);
        while(rs.next()){
            totalfertilizercostlb.setText(String.valueOf(rs.getDouble(1)));
        }
        rs.close();
        con.close();
    }



    //setting sql query for totalSeedlingcostlb

    private String settotalfertilizernolbquery(int year,String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM( fertilizeramount) from fertilizerorders where farmerid= '" + farmerid + "' && year = '" + year + "'";

        }   else {
             sqlquery = "select SUM( fertilizeramount) from fertilizerorders where farmerid= '" + farmerid + "' && year = '" + year + "' && month = '" + month + "'";
        }
        settotalfertilizernolb(sqlquery);
        return sqlquery;
    }

    private void settotalfertilizernolb(String totalseedlingno) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(totalseedlingno);
        while(rs.next()){
            totalfertilizerbagslb.setText(String.valueOf(rs.getDouble(1)));
        }
        rs.close();
        con.close();
    }

    //setting sql query for totalSeedlingcostlb

    private String settotalfertilizerkgslbquery(int year,String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select SUM(bagsize * fertilizeramount) from fertilizerorders where farmerid= '" + farmerid + "' && year = '" + year + "'";

        }   else {
             sqlquery = "select SUM(bagsize * fertilizeramount) from fertilizerorders where farmerid= '" + farmerid + "' && year = '" + year + "' && month = '" + month + "'";
        }
        settotalfertilizerkglb(sqlquery);
        return sqlquery;
    }

    private void settotalfertilizerkglb(String totalseedlingno) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(totalseedlingno);
        while(rs.next()){
            kgsorderedlb.setText(String.valueOf(rs.getDouble(1)));
        }
        rs.close();
        con.close();
    }

    //setting seedlingdeliverylv
    private String setfertilizerdeliverylvquery(int year,String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select fertilizertype ,fertilizeramount,date  from fertilizerorders where farmerid = '"+farmerid+"' && status= 'Allocated' && year = '" + year + "'";
        }   else {
            sqlquery = "select fertilizertype ,fertilizeramount,date  from fertilizerorders where farmerid = '"+farmerid+"' && status= 'Allocated' && year = '" + year + "' && month = '" + month + "'";
        }

        setFertilizerdeliverylv(sqlquery);
        return sqlquery;
    }

    private void setFertilizerdeliverylv(String seedlingdeliveryquery) throws SQLException {
        ObservableList fertilizerondelivery = FXCollections.observableArrayList();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(seedlingdeliveryquery);
        while(rs.next()){
            fertilizerondelivery.addAll(rs.getString(1) +"  Amount : " +rs.getInt(2));
        }

        fertilizertypelv.setItems(fertilizerondelivery);

        rs.close();
        con.close();
    }
}


