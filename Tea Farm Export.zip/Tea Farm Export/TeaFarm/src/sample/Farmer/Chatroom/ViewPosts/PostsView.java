package sample.Farmer.Chatroom.ViewPosts;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import sample.Admin.Sales.Admin.SalesView;

import java.io.IOException;

public class PostsView {

    public  static Stage stage;

    public void display(String title)  {
        stage = new Stage();

        try {
            Parent root = FXMLLoader.load(getClass().getResource("Posts.fxml"));
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            //stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(false);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public static void closeWindow(){
        stage.close();
        new SalesView();
    }

   /* @Override
    public void start(Stage primaryStage) throws Exception {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("Posts.fxml"));
            primaryStage.setScene(new Scene(root));
            primaryStage.setTitle("Company Sales");
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }*/
}