package sample.Farmer.Chatroom.ViewPosts;

import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;
import javafx.collections.ObservableMap;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Modality;
import javafx.stage.Stage;

import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Chatroom.CreatePost.CreatePostView;
import sample.Farmer.Home.Farmer.MainView;
import sample.Farmer.Login.Farmer.FarmerLoginDetails;
import sample.Farmer.Login.Farmer.FarmerLoginView;

import javax.swing.plaf.basic.BasicBorders;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class PostsController implements Initializable {
    @FXML
    private MenuItem refreshmi;

    @FXML
    private AnchorPane postsap;

    @FXML
    private Label datelabel;

    @FXML
    private Label chatnamelb;

    @FXML
    private ScrollPane postssp;

    @FXML
    private ListView<String> chatpostslv;

    @FXML
    private Button createpostbtn;

    DBConnection do1;
    String chat,replies,imagepath,username;
    int userid;
    ObservableList<String> commentsob;
    ObservableList<PostsDetails> postmessagesob;



    @Override
    public void initialize(URL location, ResourceBundle resources) {
        datelabel.setText(LocalDate.now().toString());
        this.userid = FarmerLoginDetails.getUserid();
        this.username = FarmerLoginDetails.getUsername();
        do1 = new DBConnection();
        try {
            setrepliessqlquery();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        chatpostslv.setEditable(true);
        setlistviewactions();
        loadButtonActions();
    }


    private void loadButtonActions(){
        //postbtn.setOnAction(e->{
        createpostbtn.setOnAction(e->
                new CreatePostView().display("Create Post"));

        refreshmi.setOnAction(e->refresh());
    }


    //Refresh
    private void refresh(){

        PostsView.closeWindow();
        new PostsView().display("Chat Platform");
    }

    VBox contentvBox;
    VBox imagevb = new VBox();
    ImageView postsimageView;
    Image image;
    VBox chatvBox;
    TextFlow posttf;
    Text text;
    TitledPane repliestp;
    VBox repliesvbox;
    TextFlow repliestf;
    Text replytext;
    TitledPane userrepliestp;
    VBox userrepliesvbox;
    TextArea userrepliesta;
    Button postbtn;
    //set posts vbox with posts

    private void setPostsvb(int id,int userid,String username, String chat, String imagepath, String comments, String date, String month, int year){

        ObservableList<PostsDetails> postmessagesob  = FXCollections.observableArrayList();

        PostsDetails postsDetails = new PostsDetails(id,userid,username, chat,imagepath,comments, date, month,year);
        postsDetails.getUsername();
        chatnamelb.setText("Chat From " +  postsDetails.getUsername());
        //making content vbox
        String contentvbname = "contentvBox"+userid;
        contentvBox = new VBox();
        contentvBox.setId(contentvbname);
        postssp.setContent(contentvBox);
        //setting image vbox

        imagevb = new VBox();
        imagevb.setSpacing(10);
        contentvBox.getChildren().add(imagevb);


        //setting image view
        postsimageView = new ImageView();
        postsimageView.setFitHeight(300);
        postsimageView.setFitWidth(300);
        imagevb.setMargin(postsimageView, new Insets(10,10,10,10));
        imagevb.getChildren().add(postsimageView);

        // setting image
        image = new Image("/sample\\images\\"+postsDetails.getImagepath());
        postsimageView.setImage(image);



        //Message vbox
        chatvBox = new VBox();
        chatvBox.setSpacing(10);
        contentvBox.getChildren().add(chatvBox);

        //setting textflow
        posttf =  new TextFlow();
        posttf.setLineSpacing(10);
        posttf.setPadding(new Insets(10,10,10,10));
        chatvBox.getChildren().add(posttf);

        //setting text
        text = new Text();
        text.setText(postsDetails.getChat());
        posttf.getChildren().add(text);


        //set comments
        //making titledpane
        repliestp = new TitledPane();
        repliestp.setText("Comments");
        repliestp.setExpanded(false);
        repliestp.setOnMouseClicked(
                e->{
                    getComments(postsDetails.getId());
                }
        );
        contentvBox.getChildren().add(repliestp);

        //making comments vbox
        repliesvbox = new VBox();
        repliesvbox.setSpacing(10);
        repliestp.setContent(repliesvbox);




        //setting textflow
        repliestf =  new TextFlow();
        repliestf.setLineSpacing(5);
        repliestf.setPadding(new Insets(5,5,5,5));
        repliesvbox.getChildren().add(repliestf);


        //setting text
        replytext = new Text();
        replytext.setText(postsDetails.getComments());
        repliestf.getChildren().add(replytext);


        //set replybox for users to make comments
        //setting titled pane
        userrepliestp = new TitledPane();
        userrepliestp.setText("Reply");
        userrepliestp.setExpanded(false);
        contentvBox.getChildren().add(userrepliestp);


        //setting vbox
        userrepliesvbox = new VBox();
        userrepliesvbox.setSpacing(10);
        userrepliestp.setContent(userrepliesvbox);

        //setting textarea
        userrepliesta = new TextArea();
        userrepliesta.setPromptText("Enter Your Reply here");
        userrepliesvbox.setMargin(userrepliesta, new Insets(10,10,10,10));
        userrepliesvbox.getChildren().add(userrepliesta);

        //setting button
        postbtn = new Button("Post");
        postbtn.setPadding(new Insets(5,5,5,5));
        userrepliesvbox.setMargin(postbtn, new Insets(10,10,10,10));
        userrepliesvbox.getChildren().add(postbtn);

        //setting post button actions
        postbtn.setOnAction(e->{
                    try {
                        int  chatid  = postsDetails.getId();
                        int myuserid = this.userid;
                        String accountusername  = FarmerLoginDetails.getUsername();
                        String myreplies = "@"+accountusername+ " replied " + userrepliesta.getText();
                        String mydate = LocalDate.now().toString();
                        String mymonth = LocalDate.now().getMonth().toString();
                        int myyear = LocalDate.now().getYear();
                        String initialreplies = postsDetails.getComments();
                        String alleplies = initialreplies +"\n" + myreplies;

                        setReplies(postsDetails.getId(),postsDetails.getUserid(),alleplies);


                        //setinsertquery(chatid,myuserid,myreplies,mydate,mymonth,myyear);
                        replytext.setText(userrepliesta.getText());
                        userrepliesta.clear();
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
        );

    }

    //get replies
    //sql query
    private void setrepliessqlquery() throws SQLException {
        String query = "select * from chats order BY id DESC " ;
        getchats(query);

    }

    ObservableList<PostsDetails> data;
    Map<String, Integer> map = new HashMap<String, Integer>();
    ObservableMap<String, Integer> chatfindermap = FXCollections.observableMap(map);

    private void getchats(String query) throws SQLException {
        data = FXCollections.observableArrayList();
        postmessagesob = FXCollections.observableArrayList();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);

        while(rs.next()){

            setPostsvb(rs.getInt(1), rs.getInt(2),rs.getString(3),rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getInt(10));
            PostsDetails postsDetails = new PostsDetails(rs.getInt(1), rs.getInt(2), rs.getString(3),rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getInt(10));

            String chatdisplay = rs.getString(3) +" at "+ rs.getString(7) +"  " +rs.getString(8);
            int chatid = rs.getInt(1);
            data.add(postsDetails);



            chatfindermap.put(chatdisplay,chatid);
           //System.out.println(rs.getString(3)) + "Map Values");
            chatpostslv.getItems().add(chatdisplay);
        }

        rs.close();
        con.close();
    }
    private void setlistviewactions(){
        chatpostslv.setOnMouseClicked(e->{
                    try{
                        ObservableList <PostsDetails> selecteditem;
                        String  chat = chatpostslv.getSelectionModel().getSelectedItem();
                         int id = chatfindermap.get(chat);
                        System.out.println(chat +"chat");
                        String query = "select * from chats where id = '"+id+"' order by id DESC" ;
                        data = FXCollections.observableArrayList();
                        postmessagesob = FXCollections.observableArrayList();
                        Connection con = do1.connect();
                        ResultSet rs = con.createStatement().executeQuery(query);
                        while(rs.next()){
                            setPostsvb(rs.getInt(1), rs.getInt(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getInt(10));

                        }

                        rs.close();
                        con.close();
                    }catch (Exception ex){
                        ex.printStackTrace();
                    }
                }
        );


    }
    private void setfirstmessage() {
        chatpostslv.setOnMouseClicked(e -> {
                    try {
                        String chat = chatpostslv.getSelectionModel().getSelectedItem();
                        System.out.println(chat + "chat");
                        String query = "select * from chats where userid='" + chat + "' && time = time order by id DESC";
                        data = FXCollections.observableArrayList();
                        postmessagesob = FXCollections.observableArrayList();
                        Connection con = do1.connect();
                        ResultSet rs = con.createStatement().executeQuery(query);
                        while (rs.next()) {
                            setPostsvb(rs.getInt(1), rs.getInt(2),rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getInt(9));

                        }

                        rs.close();
                        con.close();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
        );
    }


    //upload replies
    private  void setReplies(int id,int userid,String message) throws SQLException {
        String query = "update  chats set comments = '"+message+"' where id= '"+id+"' && userid ='"+userid+"'";
        System.out.println(query);
        Connection con = do1.connect();
        Statement statement = con.prepareStatement(query);
        statement.execute(query);
        statement.close();
        con.close();
    }


    //set replies to database.
    //datebase query
    private  void setinsertquer(int chatid,int userid,String replies,String date ,String month,int year) throws SQLException {
        String query = "Insert into chats(chatid,userid,reply,date,month,year) values '"+ chatid+"' ,'"+ userid+"', '"+ replies+"' , '"+ date +"' , '"+ month+"' , '"+ year+"'";
        savechatstodb(query);
    }
    //upload to db
    private void savechatstodb(String query) throws SQLException {
        Connection con = do1.connect();
        Statement statement = con.prepareStatement(query);
        statement.execute(query);
    }

    // getting comments
    private void getComments(int chatid)  {
        replytext.setText("");
        String query = "select comments from chats where id = '"+chatid+"'";
        try {
            Connection con = do1.connect();
            ResultSet rs = con.createStatement().executeQuery(query);
            while(rs.next()){

                String replymessage = rs.getString(1);
                System.out.println(replymessage +"replymessage");

                ObservableList<String > replymessages = FXCollections.observableArrayList();
                replymessages.add(replymessage);
                replytext.setText(replymessage);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }

}