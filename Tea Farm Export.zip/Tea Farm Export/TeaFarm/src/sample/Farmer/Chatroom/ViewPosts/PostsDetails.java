package sample.Farmer.Chatroom.ViewPosts;


import javafx.beans.property.*;

public class PostsDetails {
    private final IntegerProperty id;
    private final IntegerProperty userid;
    private final StringProperty chat;
    private final StringProperty imagepath;
    private final StringProperty comments;
    private final StringProperty date;
    private final StringProperty month;
    private final IntegerProperty year;
    public static StringProperty username;





    public PostsDetails(int id,int userid,String username,String chat, String imagepath, String comments, String date, String month, int year){

        this.id = new SimpleIntegerProperty(id);
        this.userid = new SimpleIntegerProperty(userid);
        this.username = new SimpleStringProperty(username);
        this.chat = new SimpleStringProperty( chat);
        this.imagepath =  new SimpleStringProperty(imagepath);
        this.comments = new SimpleStringProperty(comments);
        this.date =  new SimpleStringProperty(date);
        this.month =  new SimpleStringProperty(month);
        this.year = new SimpleIntegerProperty(year);

    }

    //getters
    public int getId(){return id.get();}
    public int getUserid(){return userid.get();}
    public  String getUsername() {
        return username.get();
    }

    public String getChat(){return chat.get();}
    public String getImagepath() {
        return imagepath.get();
    }

    public String getComments() {
        return comments.get();
    }
    public String getDate() {
        return date.get();
    }
    public String getMonth() {
        return month.get();
    }
    public int getYear(){return year.get();}


    //setters
    public void setId(int value) {
        id.set(value);
    }
    public void setUserid(int value) {
        userid.set(value);
    }
    public void setUsername(String value) {
        username.set(value);
    }

    public void setChat(String value) {
        chat.set(value);
    }
    public void setImagepath(String value) { imagepath.set(value); }
    public void setComments(String value) {
        comments.set(value);
    }
    public void setDate(String value) {
        date.set(value);
    }
    public void setMonth(String value) {
        month.set(value);
    }
    public void setYear(int value) {
        year.set(value);
    }


    //property setting
    public IntegerProperty idProperty(){return id;}
    public IntegerProperty useridProperty(){return userid;}
    public StringProperty usernameProperty() {
        return username;
    }
    public StringProperty chatProperty(){return chat;}
    public StringProperty imagepathProperty() {
        return imagepath;
    }
    public StringProperty commentsProperty() {
        return comments;
    }
    public StringProperty dateProperty() {
        return date;
    }
    public StringProperty monthProperty() {
        return month;
    }
    public IntegerProperty yearProperty(){return year;}

}
