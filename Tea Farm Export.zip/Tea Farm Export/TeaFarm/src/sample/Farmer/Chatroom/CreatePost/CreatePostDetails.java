package sample.Farmer.Chatroom.CreatePost;

public class CreatePostDetails {
}
