package sample.Farmer.Sales.Farmer;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.DoubleStringConverter;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Login.Farmer.FarmerLoginDetails;
import sample.Farmer.Profit.ProfitView;


import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;


public class SalesController  implements Initializable {

    @FXML
    private MenuItem refreshmi;

    @FXML
    private Label dateLabel;

    @FXML
    private ComboBox<Integer> yearselectcb;

    @FXML
    private ComboBox<String> monthselectcb;

    @FXML
    private Label totalsaleslb;

    @FXML
    private Label tealeaveskglb;

    @FXML
    private Label tealeavessaleslb;

    @FXML
    private Label fertilizerbagslb;

    @FXML
    private Label fertilizersaleslb;
    @FXML
    private TableView<SalesDetails> salesTable;

    @FXML
    private TableColumn<SalesDetails, String> columnItemSold;

    @FXML
    private TableColumn<SalesDetails, Double> columnPrice;

    @FXML
    private TableColumn<SalesDetails, Double> columnAmount;

    @FXML
    private TableColumn<SalesDetails, String> columnDate;

    @FXML
    private ComboBox<?> itemInputcb;
    @FXML
    private TextField priceInputtf;

    @FXML
    private TextField amounttf;

    @FXML
    private DatePicker dateInputtf;

    @FXML
    private Button saveInputbtn;

    @FXML
    private Button tableDeleteButton;

    DBConnection do1;
    ObservableList data;
    String   item ,dateEntered,month;

    Double price,amount;
    String date;
    int year,farmerid;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        do1 = new  DBConnection();
        setMonth();
        setItemInputcb();
        this.farmerid = FarmerLoginDetails.getUserid();
        buttonActions();

        try {
            setmonthcb();
            setyearcb();
            setLabels(year,month);
            setsqlqueryfortable(year,month);
            setcomboboxesactions();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    //setting comboboxes actions
    private void setcomboboxesactions() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{
                    try {
                        getSelectedatedata(year,month);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
        );
    }

    private  void  setItemInputcb(){
        ObservableList itemsold = FXCollections.observableArrayList();
        itemsold.addAll( "Fertilizer", "TeaLeaves");
        itemInputcb.getItems().addAll(itemsold);
    }

    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {

        setLabels(year, month);
        setsqlqueryfortable(year, month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data

    private void setyearcb() throws SQLException {
        ObservableList<Integer>datayears  = FXCollections.observableArrayList();
        String query= " select distinct(year) from farmersales";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }

    private void setmonthcb() {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
        monthselectcb.getItems().addAll(datamonths);

    }



    //fetching selected data
    // setting sql table queries for the days to display

    public void buttonActions(){
        saveInputbtn.setOnAction(e->{
            try {
                saveInputData();
                setLabels(year,month);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            clearuserinput();

        });

        tableDeleteButton.setOnAction(e-> {

            try {
                rundeletequery();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        });
        refreshmi.setOnAction(e->refresh());
    }


    //Refresh
    private void refresh(){

        SalesView.closeWindow();
        new SalesView().display("Farmer Sales");
    }

    // set month and date
    public void setMonth(){
        LocalDate currentDate = LocalDate.now();

        this.dateEntered = currentDate.toString();
        this.month = currentDate.getMonth().toString();
        this.year = currentDate.getYear();
        dateLabel.setText(dateEntered);
    }




    //get user input and clear fields
    private  void getuserinput(){
        item = itemInputcb.getValue().toString();
        price = Double.parseDouble(priceInputtf.getText());
        amount = Double.parseDouble(amounttf.getText());
        date = dateInputtf.getValue().toString();

    }
    // clearing input
    private void clearuserinput(){
        priceInputtf.clear();
        itemInputcb.getItems().clear();
        amounttf.clear();
        dateInputtf.setValue(null);
    }

    //save Input data
    public void saveInputData() throws SQLException {
        getuserinput();
        price = amount * price;
       data = FXCollections.observableArrayList();

        data.addAll(new SalesDetails(item,price,amount,date));
        salesTable.setItems(data);
        savesales(farmerid,item,price,amount,date);
        setsqlqueryfortable(year,month);
    }

    // setting input to sales table
    private void savesales(int farmerid,String item,double price,double amount, String datesold) throws SQLException {

        String insertquery = "Insert into farmersales(farmerid,item,price,amount,datesold,month,year)values('"+ farmerid+"','"+ item+"','"+ price+"','"+ amount+"','"+ datesold+"','"+ month+"','" +year+ "')";
        Connection connect = do1.connect();
        Statement stat = connect.prepareStatement(insertquery);
        stat.execute(insertquery);
        stat.close();
        connect.close();


    }



    //sql query for setting table
    private void setsqlqueryfortable(int year, String month) throws SQLException {
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "select item,price,amount,datesold  from farmersales where farmerid = '"+farmerid+"' &&  year = '" + year + "'";

        }   else {
             sqlquery = "select item,price,amount,datesold  from farmersales where farmerid = '"+farmerid+"' &&  year = '" + year + "' && month = '" + month + "'";
        }
        System.out.println(sqlquery);
        setTable(sqlquery);
    }


    // set sales table

    public  void setTable(String sqlquery) throws SQLException {
        salesTable.getItems().clear();
        salesTable.setEditable(true);
        data = FXCollections.observableArrayList();
        setMonth();
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while (rs.next()) {
            data.addAll(new SalesDetails(rs.getString(1),rs.getDouble(2),rs.getDouble(3),rs.getString(4)));

            columnItemSold.setCellValueFactory(new PropertyValueFactory<>("item"));
            columnPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
            columnAmount.setCellValueFactory(new PropertyValueFactory<>("amount"));
            columnDate.setCellValueFactory(new PropertyValueFactory<>("dateSold"));
        }

        salesTable.setItems(data);
        updateTableData();
    }

    private void updateTableData(){

        columnItemSold.setCellFactory(TextFieldTableCell.forTableColumn());
        columnPrice.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        columnAmount.setCellFactory(TextFieldTableCell.forTableColumn(new DoubleStringConverter()));
        columnDate.setCellFactory(TextFieldTableCell.forTableColumn());


        columnItemSold.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<SalesDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<SalesDetails, String> event) {
               SalesDetails salesDetails = event.getRowValue();

                String oldItemSold = event.getOldValue();
                String newItemSold= event.getNewValue();

                //setters

                salesDetails.setItem(newItemSold);

                //getters
                Double itemprice = salesDetails.getAmount();
                salesDetails.getDateSold();

                try {
                    updateStringdetails("farmersales","item",newItemSold, "price" ,itemprice,"item" ,oldItemSold);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        columnPrice.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<SalesDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<SalesDetails, Double> event) {
               SalesDetails salesDetails = event.getRowValue();

                double dayTotal,monthlyTotal,yearlyTotal,changeDifference;
                Double oldPriceAmount = event.getOldValue();
                Double newPriceAmount = event.getNewValue();

                //getting the change difference
                changeDifference = newPriceAmount - oldPriceAmount;

                //getters

                //setters


                salesDetails.setAmount(newPriceAmount);


                String columnnameValue= salesDetails.getItem();
                String columnDateSold= salesDetails.getDateSold();

                try {
                    updateDoubledetails("farmersales","price",newPriceAmount, "item" ,columnnameValue,"month" ,columnDateSold);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        columnAmount.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<SalesDetails, Double>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<SalesDetails, Double> event) {
               SalesDetails salesDetails = event.getRowValue();

                double dayTotal,monthlyTotal,yearlyTotal,changeDifference;
                Double oldAmountSold = event.getOldValue();
                Double newAmountSold = event.getNewValue();

                //getting the change difference
                changeDifference = newAmountSold - oldAmountSold;

                //getters

                //setters


                salesDetails.setAmount(newAmountSold);


                String columnnameValue= salesDetails.getItem();
                String columnDateSold= salesDetails.getDateSold();
                try {
                    updateDoubledetails("farmersales","amount",newAmountSold,  "item" ,columnnameValue,"month" ,columnDateSold);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );

        columnDate.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<SalesDetails, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<SalesDetails, String> event) {
               SalesDetails salesDetails = event.getRowValue();

                //getters
                String oldDateSold = event.getOldValue();
                String newDateSold = event.getNewValue();

                //setters

                salesDetails.setDateSold(newDateSold);


                String columnnameValue= salesDetails.getItem();
                Double price = salesDetails.getPrice();
                try {
                    updateStringdetails("farmersales","datesold",newDateSold, "price" ,price,"item" ,columnnameValue);
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        } );
    }

    //Update database methods

    // update methods with String and Double values as foreign keys
    private void updateStringdetails(String dataTable,String wheretoupdate,String newValue, String key1 ,double value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where farmerid = '"+farmerid+"' && "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";
        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }

    // update methods with String and String Values as foreign keys
    private void updateDoubledetails(String dataTable,String wheretoupdate,Double newValue, String key1 ,String value1,String key2 ,String value2) throws SQLException {
        do1 = new DBConnection();
        Connection conn = do1.connect();
        String sqlQuery = "Update "+dataTable+ " set "+wheretoupdate +" = '"+newValue+"' where  "+key1+" ='"+value1+"' && "+key2+" ='"+value2+"'";        System.out.println(sqlQuery);
        Statement statement = (Statement)conn.prepareStatement(sqlQuery);
        statement.execute(sqlQuery);
        statement.close();
        conn.close();

    }
    private void rundeletequery() throws SQLException {
        getItemsToDelete();
        removeItemsFromTable();
    }

    private void getItemsToDelete() throws SQLException {
        String item,datesold;
        double price;

        SalesDetails salesDetails = salesTable.getSelectionModel().getSelectedItem();
        item = salesDetails.getItem();
        datesold =salesDetails.getDateSold();
        price = salesDetails.getPrice();

        deleteSelectedItemsFromDB("farmersales","item",item, "price",price, "datesold",datesold);






    }


    private void removeItemsFromTable(){

        ObservableList<SalesDetails> removedData,tabledata;
        tabledata = salesTable.getItems();
        removedData =  salesTable.getSelectionModel().getSelectedItems();
        removedData.forEach(tabledata::remove);

    }

    private void deleteSelectedItemsFromDB(String Database,String key1,String value1, String key2,double value2, String key3,String value3) throws SQLException {
        String deleteQuery = "delete from "+Database+" where "+key1+" = '"+value1+"' && "+key2+" = '"+value2+"' && "+key3+" = '"+value3+"'";

        System.out.println(deleteQuery);

        do1 = new DBConnection();
        Connection conn =do1.connect();
        Statement statement =(Statement)conn.prepareStatement(deleteQuery);
        statement.execute(deleteQuery);
        statement.close();
        conn.close();


    }

    double totalsales,totalTeaLeavessales,totalTeaLeavessold,totalfertilizersales;
    int totalfertilizersold,itemsum;
    double sumprice;
    //get sum of item
    private int getItemSum(String item, int year, String month) throws SQLException {
        Connection con =  do1.connect();
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "SELECT SUM(amount) FROM farmersales where farmerid = '"+farmerid+"' && item ='" + item + "' && year = '" + year + "'";

        }   else {
            sqlquery = "SELECT SUM(amount) FROM farmersales where farmerid = '"+farmerid+"' && item ='" + item + "' && year = '" + year + "' && month = '" + month + "'";
        }
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            itemsum = rs.getInt(1);
        }
        rs.close();
        con.close();
        return itemsum;
    }
    //get sum of item
    private double getPriceSum(String item,int year, String month) throws SQLException {
        Connection con =  do1.connect();
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "SELECT SUM(PRICE) FROM farmersales where farmerid = '"+farmerid+"' && item ='" + item + "' && year = '" + year + "'";

        }   else {
             sqlquery = "SELECT SUM(PRICE) FROM farmersales where farmerid = '"+farmerid+"' && item ='" + item + "' && year = '" + year + "' && month = '" + month + "'";
        }
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            sumprice = rs.getDouble(1);
        }
        rs.close();
        con.close();
        return sumprice;
    }


    //gettottalsales
    private double getTotalSales(  int year, String month) throws SQLException {
        Connection con =  do1.connect();
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "SELECT SUM(PRICE) FROM farmersales where farmerid = '"+farmerid+"' && year = '" + year + "'";

        }   else {
            sqlquery = "SELECT SUM(PRICE) FROM farmersales where farmerid = '"+farmerid+"' && year = '" + year + "' && month  = '" + month + "'";
        }
        ResultSet rs = con.createStatement().executeQuery(sqlquery);
        while(rs.next()){
            totalsales = rs.getDouble(1);
        }
        rs.close();
        con.close();
        return  totalsales;
    }

    //gettotalseedlings sales and amount sold
    private double gettotalTeaLeavesSold (String item, int year, String month) throws SQLException {
        getItemSum(item,  year,  month);
        totalTeaLeavessold = itemsum;
        return totalTeaLeavessold;
    }

    private double gettotalTeaLeavesSales (String item, int year, String month) throws SQLException {
        getPriceSum(item,  year,  month);
        totalTeaLeavessales =  sumprice;
        return totalTeaLeavessales;
    }

    //get fertilizers bags sold and amount
    private int getTotalFertilizerSold(String item,int year, String month) throws SQLException {
        getItemSum(item,  year,  month);
        totalfertilizersold = itemsum;
        return totalfertilizersold;
    }
    private double getTotalFertilizerSales (String item, int year, String month) throws SQLException {
        getPriceSum(item, year,  month);
        totalfertilizersales = sumprice;
        return totalfertilizersales;
    }

    // setting labels
    private void setLabels(int year, String month) throws SQLException {
        getTotalSales(year,  month);
        totalsaleslb.setText(String.valueOf(totalsales));

        gettotalTeaLeavesSold ("TeaLeaves", year,  month);
        tealeaveskglb.setText(String.valueOf(totalTeaLeavessold));

        gettotalTeaLeavesSales ("TeaLeaves", year,  month);
        tealeavessaleslb.setText(String.valueOf(totalTeaLeavessales));


        getTotalFertilizerSold("Fertilizer", year,  month);
        fertilizerbagslb.setText(String.valueOf(totalfertilizersold));
        getTotalFertilizerSales ("Fertilizer", year,  month);
        fertilizersaleslb.setText(String.valueOf(totalfertilizersales));
    }

}



