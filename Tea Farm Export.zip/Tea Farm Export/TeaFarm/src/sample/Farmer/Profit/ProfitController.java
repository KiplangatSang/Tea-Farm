package sample.Farmer.Profit;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.Admin.Profit.ProfitDetails;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Fertilizer.Farmer.FertilizerView;
import sample.Farmer.Login.Farmer.FarmerLoginDetails;


import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class ProfitController implements Initializable {

    @FXML
    private MenuItem refreshmi;

    @FXML
    private Label netProfitlb;

    @FXML
    private Label percentageProfitlb;

    @FXML
    private Label growthPercentagelb;

    @FXML
    private Label expensetotallb;

    @FXML
    private Label totalsaleslb;

    @FXML
    private Label datelb;

    @FXML
    private TableView<ProfitDetails> profitTable;

    @FXML
    private TableView<ProfitDetails> profitTable2;

    @FXML
    private TableColumn<ProfitDetails,String> columnExpenses;

    @FXML
    private TableColumn<ProfitDetails,Double> columnCost;

    @FXML
    private TableColumn<ProfitDetails,String> columnSales;

    @FXML
    private TableColumn<ProfitDetails,Double> columnRevenue;

    @FXML
    private ComboBox<String> monthselectcb;

    @FXML
    private ComboBox<Integer> yearselectcb;


    DBConnection do1;
    ObservableList data = FXCollections.observableArrayList();
    String month,date;
    int dayOfMonth,dayOfYear,year,monthOfYear,farmerid;
    public double expensecost, totalsales ,grossprofit,netprofit,profitpercent;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        getDateTime();
        do1 = new DBConnection();
         this.farmerid = FarmerLoginDetails.getUserid();
        try {
            setyearcb();
            setmonthcb();
            setsqlqueryfortable(year,month);
            setlabels(year,month);
            setcomboboxesactions();
            checkMonthlyProfit();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

    }


    //setting comboboxes actions
    private void setcomboboxesactions() throws SQLException {
        monthselectcb.setOnAction(e->{
            try {
                getSelectedatedata(year,month);

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e->{
                    try {
                        getSelectedatedata(year,month);
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
        );
        refreshmi.setOnAction(e->refresh());
    }


    //Refresh
    private void refresh(){

        ProfitView.closeWindow();
        new ProfitView().display("Farmer Profit");
    }

    //getting selected month data

    //getting selected dates
    public void getSelectedatedata(int year, String month) throws SQLException {
        String mymonth ="";int myyear;

        System.out.println(yearselectcb.getValue());
        try {
            myyear = Integer.parseInt(String.valueOf(yearselectcb.getValue()));
        }
        catch (Exception e){
            myyear = year;
        }
        mymonth  = monthselectcb.getValue();

        setselecteddatedata(myyear,mymonth);

    }

    private void setselecteddatedata(int year,String month) throws SQLException {

        setlabels(year, month);
        setsqlqueryfortable(year, month);
    }

    //setting month and year selection comboboxes
    //getting months and years of data

    private void setyearcb() throws SQLException {
        ObservableList<Integer>datayears  = FXCollections.observableArrayList();
        String query= " select distinct(year) from farmerprofit";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            datayears.add(rs.getInt(1));
        }
        rs.close();
        con.close();
        yearselectcb.getItems().addAll(datayears);
    }

    private void setmonthcb() {
        ObservableList<String> datamonths = FXCollections.observableArrayList();
        datamonths.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );
        monthselectcb.getItems().addAll(datamonths);

    }



    //fetching selected data
    // setting sql table queries for the days to display

    public void buttonActions(){

    }





    //setting month
    public Month getDateTime() {
        LocalDate currentDate = LocalDate.now();
        DayOfWeek dow = currentDate.getDayOfWeek();
        int dom = currentDate.getDayOfMonth();
        int doy = currentDate.getDayOfYear();
        Month m = currentDate.getMonth();
        int year = currentDate.getYear();
        month = m.toString();

        this.date =currentDate.toString();
        this.dayOfMonth = dom;
        this.monthOfYear = currentDate.getMonthValue();
        this.dayOfYear = doy;
        this.year = year;

        return m;
    }
//

    //inserting items to database
    public void insertitemstodbtable(String tablename,String column1, String value1,String column2, double value2,String date,String month,int year) throws SQLException {
        DBConnection connection = new DBConnection();
        String query = "insert into "+tablename+"("+column1+","+column2+",date,month,year)values('"+value1+"','"+value2+"','"+date+"','"+month+"','"+year+"')";
        System.out.println("Profit insert " +query );
        Connection con = connection.connect();
        Statement statement = con.prepareStatement(query);
        statement.execute(query);
        statement.close();
        con.close();
    }

    //setting sql query for table
    private String setsqlqueryfortable( int year, String month) throws SQLException {
        profitTable.getItems().clear();
        String salesquery ="";
        String expensequery ="";
        if(month == "" || month== null){

            salesquery = "Select item,price from farmersales where  year ='" + year + "' && farmerid = '" + farmerid + "'";
            expensequery = "Select workdone,cost from farmerexpenses where  year ='" + year + "'  && farmerid = '" + farmerid + "'";

        }   else {
             salesquery = "Select item,price from farmersales where  year ='" + year + "' && month='" + month + "' && farmerid = '" + farmerid + "'";
             expensequery = "Select workdone,cost from farmerexpenses where  year ='" + year + "' && month='" + month + "' && farmerid = '" + farmerid + "'";
        }
        setTable(salesquery,expensequery);
        return salesquery ;
    }


    // set profitTable table
    private void setTable(String sqlquery1,String sqlquery2) throws SQLException {
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(sqlquery2);
        while (rs.next()) {
            data.add(new sample.Admin.Profit.ProfitDetails(rs.getString(1),rs.getDouble(2)));
            columnExpenses.setCellValueFactory(new PropertyValueFactory<>("expenses"));
            columnCost.setCellValueFactory(new PropertyValueFactory<>("cost"));

        }
        rs.close();
        con.close();


        ObservableList SalesData = FXCollections.observableArrayList();
        Connection con1 = do1.connect();
        ResultSet rs1 = con1.createStatement().executeQuery(sqlquery1);
        while (rs1.next()) {
            SalesData.add(new sample.Admin.Profit.ProfitDetails(rs1.getDouble(2),rs1.getString(1)));
            columnSales.setCellValueFactory(new PropertyValueFactory<>("sales"));
            columnRevenue.setCellValueFactory(new PropertyValueFactory<>("revenue"));
        }
        rs1.close();
        con1.close();

        profitTable2.setItems(SalesData);
        profitTable.setItems(data);
    }

    //fetch total Sales
    public double getTotalSales(int year, String month) throws SQLException {
        do1 = new DBConnection();
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "SELECT sum(price) from farmersales where year= '" + year + "'  && farmerid = '" + farmerid + "'";

        }   else {
            sqlquery = "SELECT sum(price) from farmersales where year= '" + year + "' && month ='" + month + "' && farmerid = '" + farmerid + "'";
        }
        Connection connect1 = do1.connect();
        ResultSet rs1 = connect1.createStatement().executeQuery(sqlquery );
        while (rs1.next()) {
            this.totalsales = rs1.getDouble(1);

        }
        rs1.close();
        connect1.close();
        return totalsales;
    }

    //fetch total expense from db
    public double getTotalCost(int year, String month) throws SQLException {
        do1 = new DBConnection();
        String sqlquery ="";
        if(month == "" || month== null){
            sqlquery = "SELECT sum(cost) from farmerexpenses where year ='" + year + "'  &&  farmerid = '" + farmerid + "'";

        }   else {
            sqlquery = "SELECT sum(cost) from farmerexpenses where year ='" + year + "' &&  month ='" + month + "' &&  farmerid = '" + farmerid + "'";
        }
        Connection connect1 = do1.connect();
        ResultSet rs1 = connect1.createStatement().executeQuery(sqlquery );

        while (rs1.next()){
            this.expensecost = rs1.getDouble(1);

        }
        rs1.close();
        connect1.close();
        return  expensecost;
    }

    //calculating gross profit
    public double getGrossProfit(double expensecost, double sales){
        grossprofit = sales -expensecost;
        return grossprofit;
    }


    //Calculating percentage  profit growth
    public double getPercentageProfit(double grossprofit, double sales){
        profitpercent = (grossprofit/sales)*100;
        return profitpercent;
    }

    //get label data
    public void getlabeldata(int year, String month) throws SQLException {
        expensecost = 1;
        grossprofit =1;
        totalsales = 1;
        getDateTime();
        getTotalSales( year,  month);
        getTotalCost( year, month);

        getGrossProfit(expensecost,totalsales);
        getPercentageProfit(grossprofit,totalsales);
    }


    //set labels
    private void setlabels(int year, String month) throws SQLException {
        getlabeldata(year,month);
        try{
            Double.parseDouble(String.valueOf(profitpercent));
        netProfitlb.setText(String.valueOf(grossprofit));
        growthPercentagelb.setText("");
        percentageProfitlb.setText(String.valueOf(profitpercent));
        expensetotallb.setText(String.valueOf(expensecost));
        totalsaleslb.setText(String.valueOf(totalsales));}
        catch(Exception profitex){
            profitpercent = 0;
            netProfitlb.setText(String.valueOf(grossprofit));
            growthPercentagelb.setText("");
            percentageProfitlb.setText(String.valueOf(profitpercent));
            expensetotallb.setText(String.valueOf(expensecost));
            totalsaleslb.setText(String.valueOf(totalsales));
        }
    }

    //check monthly profit in database
    private double checkMonthlyProfit() throws SQLException {
        String query = "Select profit from farmerprofit where farmerid = '"+farmerid+"' && month= '"+month+"' && year = '"+year+"'";
       double profit = 0;
        Connection con = do1.connect();
        ResultSet rs  = con.createStatement().executeQuery(query);
        if(rs.next()){
            profit = rs.getDouble(1);
            updateDatabasevalues();
        }else{
            setDatabasevalue();
        }
        return  profit;
    }

    //inserting database values
    private void setDatabasevalue() throws SQLException {
        try{
            Double.parseDouble(String.valueOf(profitpercent));
            String query = "insert into farmerprofit(farmerid,sales,expenses,profit,percentageprofit,month,monthofyear,year) " +
                    "values('"+farmerid+"','"+totalsales+"','"+expensecost+"','"+grossprofit+"','"+profitpercent+"','"+month+"','"+monthOfYear+"','"+year+"') ";

            Connection con = do1.connect();
            Statement stat = con.prepareStatement(query);
            stat.execute(query);
            stat.close();
            con.close();
        }catch (Exception e){
            profitpercent = 0;
            String query = "insert into farmerprofit(farmerid,sales,expenses,profit,percentageprofit,month,monthofyear,year) " +
                    "values('"+farmerid+"','"+totalsales+"','"+expensecost+"','"+grossprofit+"','"+profitpercent+"','"+month+"','"+monthOfYear+"','"+year+"') ";

            Connection con = do1.connect();
            Statement stat = con.prepareStatement(query);
            stat.execute(query);
            stat.close();
            con.close();
        }


    }

    //updating db values
    private void updateDatabasevalues() throws SQLException {


        String query = "Update farmerprofit set sales = '"+totalsales+"', expenses = '"+expensecost+"', profit = '"+grossprofit+"', percentageprofit = '"+profitpercent+ "' where farmerid = '"+farmerid+"' && month ='"+month+"' && monthofyear = '"+monthOfYear+"' &&  year = '"+year+"'";

        Connection con = do1.connect();
        Statement stat = con.prepareStatement(query);
        stat.execute(query);
        stat.close();
        con.close();

    }
}
