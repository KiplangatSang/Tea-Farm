package sample.Farmer.Registration.Farmer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Login.Farmer.FarmerLoginView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FarmerRegistrationAlertBox {

    private static Scene scene1;
    private static Stage window1;
    static Stage window;
    static Scene scene;
    public FarmerRegistrationAlertBox(){

    }

    //has one Okey button
    public static void dataerror(String message){
        window = new Stage();
        Label label = new Label();
        label.setText(message);

        Button button = new Button();
        button.setText("Okey");
        button.setOnAction(e ->{
            closeWindow();
            new FarmerRegistrationView();
        });

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.getChildren().add(label);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20,20,20,20));
        hbox1.getChildren().add(button);


        BorderPane pane = new BorderPane();
        pane.setCenter(hbox);
        pane.setBottom(hbox1);
        scene = new Scene(pane,300,200);

        //window
        window.setResizable(false);
        window.setScene(scene);
        window.initModality(Modality.APPLICATION_MODAL);
        window.show();
    }
    public static void closeWindow(){
        // new AdminRegistrationView().closeWindow();
        // new AdminRegistrationView().display( "Login/Register");
        window.close();

    }

    public static void closeWindow1(){
        window1.close();

    }
    public static void closeWindow2(){
        window1.close();
        //RegisterCowsView.closeWindow();
        //  new AdminRegistrationView().display( "Login/Register");

    }

    //has two buttons to accept and to decline cancel
    public static void cancelWindow(String message) {
        window1 = new Stage();
        Label label1 = new Label();
        label1.setStyle("-fx-background-color:red");
        label1.setPadding(new Insets(10, 10, 10, 10));
        label1.setText(message);

        Button okeybtn = new Button();
        okeybtn.setText("Yes");
        // okeybtn.setStyle("-fx-background-color:red");
        okeybtn.setOnAction(e -> closeWindow2());
        Button cancelbtn = new Button();
        cancelbtn.setText("No");
        cancelbtn.setStyle("-fx-background-color:green");
        cancelbtn.setOnAction(e -> closeWindow1());

        Region region = new Region();
        region.setMinWidth(70);

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10, 10, 10, 10));
        hbox.getChildren().add(label1);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20, 20, 20, 20));
        hbox1.getChildren().addAll(okeybtn, region, cancelbtn);


        BorderPane pane = new BorderPane();
        pane.setCenter(hbox);
        pane.setBottom(hbox1);
        scene1 = new Scene(pane, 300, 200);

        //window
        window1.setResizable(false);
        window1.setScene(scene1);
        window1.initModality(Modality.APPLICATION_MODAL);
        window1.show();
    }


    // Login guide to recover password
    //recovering passwords using the recovery question


    public static String recoveryAnswerInput;
    public static void getUserName(String message){

        window1 = new Stage();


        Label label1 = new Label();

        label1.setPadding(new Insets(10,10,10,10));
        label1.setText(message);

        //textfield to input the answer
        TextField recoveryAnswertf = new TextField();
        recoveryAnswertf.setPromptText("Input Answer");
        recoveryAnswertf.setPadding(new Insets(10,10,10,10));



        System.out.println(recoveryAnswertf.getText() + "getUserName");




        //accept button
        Button okeybtn = new Button();
        okeybtn.setText("Okey");
        okeybtn.setStyle("-fx-background-color:green");


        okeybtn.setOnAction(e ->{
            try {
                String user =recoveryAnswertf.getText();
                RecoveryQuestionAlertBoxLink(recoveryAnswertf.getText() + "\n Answer The Recovery question", recoveryAnswertf.getText());
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });

        Region region = new Region();
        region.setMinWidth(70);

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.getChildren().add(label1);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20,20,20,20));
        hbox1.getChildren().addAll(recoveryAnswertf,region,okeybtn);


        BorderPane pane = new BorderPane();
        pane.setCenter(hbox);
        pane.setBottom(hbox1);
        scene1 = new Scene(pane,300,200);

        //window
        window1.setResizable(false);
        window1.setScene(scene1);
        window1.initModality(Modality.APPLICATION_MODAL);
        window1.show();

        recoveryAnswertf.clear();
    }

    static String dbUsername;
    static String dbrecoveryquestion;
    static String dbrecoveryanswer;

    //getting recovery question
    private static void getrecoveryquestionfromdb(String Username) throws SQLException {
        DBConnection do1 = new DBConnection();
        Connection con = do1.connect();
        String query = "SELECT username,recoveryquestion,recoveryanswer FROM farmer_users where username ='" + Username + "'";
        System.out.println(query);

        ResultSet rs = con.createStatement().executeQuery(query);
        while (rs.next()) {
            dbUsername = rs.getString(1);
            dbrecoveryquestion = rs.getString(2);
            dbrecoveryanswer = rs.getString(3);

        }
        rs.close();
        con.close();
        System.out.println(dbUsername + dbrecoveryquestion  + dbrecoveryanswer +"  getrecoveryquestionfromdb");
    }

    //Link to Recovery answer alertbox
    //has one Okey button
    public static void RecoveryQuestionAlertBoxLink(String message,String Username) throws SQLException {


        if(!Username.equals(null)  && !Username.equals("") && Username !="" && Username!= null ) {
            closeWindow1();

            getrecoveryquestionfromdb(Username);
            window = new Stage();
            Label label = new Label();
            label.setText(message);

            Button button = new Button();
            button.setText("Okey");
            button.setOnAction(e ->{
                recoverAccount(dbUsername, dbrecoveryquestion);
            });

            HBox hbox = new HBox();
            hbox.setMaxHeight(250);
            hbox.setPadding(new Insets(10,10,10,10));
            hbox.getChildren().add(label);

            HBox hbox1 = new HBox();
            hbox1.setPadding(new Insets(20,20,20,20));
            hbox1.getChildren().add(button);


            BorderPane pane = new BorderPane();
            pane.setCenter(hbox);
            pane.setBottom(hbox1);
            scene = new Scene(pane,300,200);

            //window
            window.setResizable(false);
            window.setScene(scene);
            window.initModality(Modality.APPLICATION_MODAL);
            window.show();
        }
        else if(Username.equals(null)  && Username.equals("") && Username =="" && Username == null ){
            dataerror("Fill in all  fields");
        }
        else{
            dataerror("Fill in all required fields");

        }


    }

    // recovery Answer AlertBox
    public static void recoverAccount(String username, String message){
        closeWindow();
        window1 = new Stage();


        Label label1 = new Label();
        //label1.setStyle("-fx-background-color:red");
        label1.setPadding(new Insets(10,10,10,10));
        label1.setText(message);

        //textfield to input the answer
        TextField recoveryAnswertf = new TextField();
        recoveryAnswertf.setPromptText("Input Answer");
        recoveryAnswertf.setPadding(new Insets(10,10,10,10));

        //accept button
        Button okeybtn = new Button();
        okeybtn.setText("Okey");
        okeybtn.setStyle("-fx-background-color:green");


        okeybtn.setOnAction(e ->{
            System.out.println(recoveryAnswertf.getText() + " recoverAccount");
            // recoveryAnswerInput = recoveryAnswertf.getText();
            new FarmerRegistrationDetails(recoveryAnswertf.getText());
            compareUserAnswerDbanswer(username, recoveryAnswertf.getText(), dbrecoveryanswer);
        });

        Region region = new Region();
        region.setMinWidth(70);

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.getChildren().add(label1);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20,20,20,20));
        hbox1.getChildren().addAll(recoveryAnswertf,region,okeybtn);


        BorderPane pane = new BorderPane();
        pane.setCenter(hbox);
        pane.setBottom(hbox1);
        scene1 = new Scene(pane,300,200);

        //window
        window1.setResizable(false);
        window1.setScene(scene1);
        window1.initModality(Modality.APPLICATION_MODAL);
        window1.show();

        recoveryAnswertf.clear();
    }


    // compare user anser to db answer
    private static void compareUserAnswerDbanswer(String Username, String Useranswer, String dbAnswer){
        String lowerCaserUseranswer = Useranswer.toLowerCase();
        String lowerCaserdbAnswer = dbAnswer.toLowerCase();

        System.out.println(lowerCaserUseranswer+ "lowerCaserUseranswer \n" + lowerCaserdbAnswer+ " lowerCaserdbAnswer \n  compareUserAnswerDbanswer");
        if(lowerCaserUseranswer.equals(lowerCaserdbAnswer)){
            closeWindow1();
            resetUserPassword(Username, "Reset Your Password",dbAnswer);
        }
        else if(!lowerCaserUseranswer.equals(lowerCaserdbAnswer)){

            System.out.println(lowerCaserUseranswer);
            System.out.println(lowerCaserUseranswer);
            closeWindow1();
            dataerror("Wrong Answer input");
        }
        else if(lowerCaserdbAnswer == lowerCaserUseranswer){
            System.out.println(lowerCaserUseranswer);
            System.out.println(lowerCaserUseranswer);
            closeWindow1();
            resetUserPassword(Username, "Reset Your Password",dbAnswer);


        }
        else{
            System.out.println(lowerCaserUseranswer);
            System.out.println(lowerCaserUseranswer);
            closeWindow1();
            dataerror("Wrong Answer");

        }
    }

    //reset password
    // recovery Answer AlertBox
    public static void resetUserPassword(String username, String message,String recoveryQAnswer){
        window1 = new Stage();

        Label label1 = new Label();
        //label1.setStyle("-fx-background-color:red");
        label1.setPadding(new Insets(10,10,10,10));
        label1.setText(message);

        //textfield to input the answer
        TextField passwordupdatetf = new TextField();
        passwordupdatetf.setPromptText("Input Answer");
        passwordupdatetf.setPadding(new Insets(10,10,10,10));


        //Textfield to confirm password
        TextField confirmpasswordupdatettf = new TextField();
        confirmpasswordupdatettf.setPromptText("Confirm Password");
        confirmpasswordupdatettf.setPadding(new Insets(10,10,10,10));


        //accept button
        Button okeybtn = new Button();
        okeybtn.setText("Okey");
        okeybtn.setStyle("-fx-background-color:green");


        okeybtn.setOnAction(e ->{
            try {
                checkPasswordUpdate(username,recoveryQAnswer, passwordupdatetf.getText(),confirmpasswordupdatettf.getText());
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }


        });

        Region region = new Region();
        region.setMinWidth(70);

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.getChildren().add(label1);
        hbox.setMargin(label1, new Insets(10,10,10,10));

        VBox vbox = new VBox();
        vbox.setPadding(new Insets(20,20,20,20));
        vbox.getChildren().addAll(passwordupdatetf,confirmpasswordupdatettf);
        vbox.setMargin(passwordupdatetf, new Insets(10,10,10,10));
        vbox.setMargin(confirmpasswordupdatettf, new Insets(10,10,10,10));

        HBox btnhbox = new HBox();
        btnhbox.getChildren().add(okeybtn);
        btnhbox.setMargin(okeybtn,new Insets(10,10,10,30));

        BorderPane pane = new BorderPane();
        pane.setTop(hbox);
        pane.setCenter(vbox);
        pane.setBottom(btnhbox);
        scene1 = new Scene(pane,400,300);

        //window
        window1.setResizable(false);
        window1.setScene(scene1);
        window1.initModality(Modality.APPLICATION_MODAL);
        window1.show();

    }


    //verify passwords
    private static String checkPasswordUpdate(String Username, String recoveryQAnswer, String password, String confirmPassword) throws SQLException {
        if (!Username.equals(null) && !recoveryQAnswer.equals(null) && !password.equals(null) && !confirmPassword.equals(null)){

            if(!Username.equals("") && !recoveryQAnswer.equals("") && !password.equals("") && !confirmPassword.equals("")){
                if(password.equals(confirmPassword)){
                    updateUserPasswordInDB(Username,recoveryQAnswer,password);
                    System.out.println("updated");
                }
                else{
                    dataerror("Passwords are not the same");
                }
            }
            else{
                dataerror("Fill in all the Fields");
            }

        }
        else{
            dataerror("Fill in all the null values");

        }
        return password;
    }

    // update user password in db
    private static void  updateUserPasswordInDB(String Username, String recoveryQAnswer, String password) throws SQLException {
        String query = "Update farmer_users set password = '"+ password+"' where username = '"+Username+"' && recoveryanswer ='"+recoveryQAnswer+"'";
        DBConnection do1 = new DBConnection();
        Connection conn = do1.connect();
        conn.createStatement().execute(query);
        conn.close();
        dataerror(" Congratulation \n Password is updated");
        closeWindow1();
    }


    //Direct user to create Choose  a recovery question
    public static void guideToSetRecoveryQuestion(String message,String Username){
        window = new Stage();
        Label label = new Label();
        label.setText(message);

        Button button = new Button();
        button.setText("Okey");
        button.setOnAction(e ->{
            closeWindow();
            setAccountRecoveryView("Choose a recovery question and input answer",Username);
        });

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.getChildren().add(label);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20,20,20,20));
        hbox1.getChildren().add(button);


        BorderPane pane = new BorderPane();
        pane.setCenter(hbox);
        pane.setBottom(hbox1);
        scene = new Scene(pane,300,200);

        //window
        window.setResizable(false);
        window.setScene(scene);
        window.initModality(Modality.APPLICATION_MODAL);
        window.show();
    }




    //setting account recovery questions
    //Setting recovery questions

    static ObservableList recoveryquestions;

    private static void recoveryquestions() {
        recoveryquestions = FXCollections.observableArrayList();
        String question1 = "What is the name of your favourite pet";
        String question2 = "Which Year did you complete High School";
        String question3 = "Which was your favourite year";
        String question4 = "What was the name of your primary School";
        String question5 = "What was the name of your best Teacher";
        String question6 = "What was the name of your childhood friend";
        String question7 = "What was the name of your father's name";
        String question8 = "What is your favourite color";
        String question9 = "What is your favourite dish";


        recoveryquestions.addAll(question1, question2, question3, question4,question5,question6,question7,question8,question9);

    }


    private static void setAccountRecoveryView(String message,String username){
        recoveryquestions();
        window1 = new Stage();

        Label label1 = new Label();
        //label1.setStyle("-fx-background-color:red");
        label1.setPadding(new Insets(10,10,10,10));
        label1.setText(message);

        //setting combobox
        ComboBox<String> accountrecoverycombobox = new ComboBox<>();
        accountrecoverycombobox.getItems().addAll();
        accountrecoverycombobox.setPromptText("Click to choose a question");
        accountrecoverycombobox.setPadding(new Insets(5,5,5,5));

        //setting combobox values
        accountrecoverycombobox.getItems().addAll(recoveryquestions);

        //textfield to input the answer
        TextField recoveryAnswertf = new TextField();
        recoveryAnswertf.setPromptText("Input Answer");
        recoveryAnswertf.setPadding(new Insets(10,10,10,10));




        //get input
        String accountrecoveryquestion = accountrecoverycombobox.getValue();
        String accountrecoveryAnswer = recoveryAnswertf.getText();






        //accept button
        Button okeybtn = new Button();
        okeybtn.setText("Save");
        okeybtn.setStyle("-fx-background-color:green");


        okeybtn.setOnAction(e ->{
            //storing recovery question and  answer
            storeRecoveryQuestionAndAnswer(accountrecoverycombobox.getValue(),recoveryAnswertf.getText(),username);
        });

        Region region = new Region();
        region.setMinWidth(70);

        VBox vbox = new VBox();
        // vbox.setMaxHeight(250);
        vbox.setPadding(new Insets(10,10,10,10));
        vbox.getChildren().addAll(label1,accountrecoverycombobox);



        HBox hbox2 = new HBox();
        hbox2.setPadding(new Insets(20,20,20,20));
        hbox2.getChildren().addAll(recoveryAnswertf,region,okeybtn);



        VBox vBox = new VBox();
        vBox.setPadding(new Insets(20,20,20,20));
        vBox.getChildren().addAll(hbox2);

        BorderPane pane = new BorderPane();
        pane.setCenter(vbox);
        pane.setBottom(vBox);
        scene1 = new Scene(pane,500,300);

        //window
        window1.setResizable(false);
        window1.setScene(scene1);
        window1.initModality(Modality.APPLICATION_MODAL);
        window1.show();

        recoveryAnswertf.clear();


    }


    //store recoveryQuestion and answer to db
    private static void storeRecoveryQuestionAndAnswer(String recoveryQChoice, String recoveryQAnswer, String username) {
        // check if the input is not empty
        if (!recoveryQChoice.equals(null) && !recoveryQAnswer.equals(null)) {
            if (!recoveryQChoice.equals("") && !recoveryQAnswer.equals("")) {
                try {
                    // getRecoveryInput();
                    DBConnection do1 = new DBConnection();
                    String updateQuery = "UPDATE farmer_users  SET recoveryquestion = '" + recoveryQChoice + "',recoveryanswer = '" + recoveryQAnswer + "' WHERE username ='" + username + "'";

                    Connection conn = do1.connect();
                    Statement statement = conn.prepareStatement(updateQuery);
                    statement.execute(updateQuery);

                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }

                closeWindow();
                closeWindow1();
                FarmerRegistrationView.closeWindow();
                registrationsuccessalert("You have Successfully Registered Congracts");
            }
        } else if (recoveryQChoice == null && recoveryQAnswer == null) {
            dataerror("Fill in  all Fields");
        } else {
            dataerror("Fill in  all Fields");
        }
    }





    //Registration alert
    //has one Okey button
    public static void registrationsuccessalert(String message){
        window = new Stage();
        Label label = new Label();
        label.setText(message);

        Button button = new Button();
        button.setText("Okey");
        button.setOnAction(e ->{
            closeWindow();
            new FarmerRegistrationView();
        });

        HBox hbox = new HBox();
        hbox.setMaxHeight(250);
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.getChildren().add(label);

        HBox hbox1 = new HBox();
        hbox1.setPadding(new Insets(20,20,20,20));
        hbox1.getChildren().add(button);


        BorderPane pane = new BorderPane();
        pane.setCenter(hbox);
        pane.setBottom(hbox1);
        scene = new Scene(pane,300,200);

        //window
        window.setResizable(false);
        window.setScene(scene);
        window.initModality(Modality.APPLICATION_MODAL);
        window.show();
    }



}
