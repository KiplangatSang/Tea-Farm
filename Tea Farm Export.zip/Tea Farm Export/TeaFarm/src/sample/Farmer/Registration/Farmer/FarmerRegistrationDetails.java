package sample.Farmer.Registration.Farmer;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class FarmerRegistrationDetails {
    public static StringProperty username;
    public static IntegerProperty userid;

    public FarmerRegistrationDetails(String username){
        this.username = new SimpleStringProperty(username);
      //  this.userid = new SimpleIntegerProperty(userid);
    }


    //getters
    public static String getUsername() {
        return username.get();
    }
  /*  public static int getUserid() {
        return userid.get();
    }*/
    //setters

    public void setUsername(String value) {
        username.set(value);
    }
   /* public void setUserid(int value) {
        userid.set(value);
    }*/

    //property setting
    public StringProperty usernameProperty() {
        return username;
    }
   /* public IntegerProperty useridProperty() {
        return userid;
    }*/

}
