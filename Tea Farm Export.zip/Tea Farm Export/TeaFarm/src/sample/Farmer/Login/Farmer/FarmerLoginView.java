package sample.Farmer.Login.Farmer;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;


import java.io.IOException;

public class FarmerLoginView  {
    /*
   public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        try {
            Parent root = FXMLLoader.load(getClass().getResource("FarmerLogin.fxml"));
            primaryStage.setScene(new Scene(root));
            primaryStage.setTitle("Farm System");
            primaryStage.setResizable(false);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }}*/





    public static Stage stage;

    public  void display(String title) {
        stage = new Stage();

        try {
            Parent loginroot = FXMLLoader.load(getClass().getResource("FarmerLogin.fxml"));
            stage.setScene(new Scene(loginroot, 700, 590));
            stage.setTitle(title);
            stage.setResizable(false);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void closeWindow() {
        stage.close();
    }
}