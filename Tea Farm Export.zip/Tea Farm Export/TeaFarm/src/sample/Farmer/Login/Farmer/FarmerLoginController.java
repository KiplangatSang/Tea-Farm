
package sample.Farmer.Login.Farmer;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import org.apache.commons.codec.digest.DigestUtils;
import sample.Admin.Login.Admin.AdminLoginView;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Home.Farmer.MainView;
import sample.Farmer.Registration.Farmer.FarmerRegistrationDetails;
import sample.Farmer.Registration.Farmer.FarmerRegistrationView;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

public class FarmerLoginController implements Initializable {
    @FXML
    private Button registerviewbtn;

    @FXML
    private ComboBox<?> loginusernamecb;

    @FXML
    private PasswordField loginpasswordtxt;

    @FXML
    private Button loginbtn;

    @FXML
    private Button forgotpasswordbtn;

    @FXML
    private Button adminviewbtn;

    @FXML
    private Button aboutusbtn;

    @FXML
    private Button refreshbtn;


    DBConnection do1;
    String username, password;
    int farmerid;
    String dbUsername, dbPassword, dbrecoveryquestion, UsernameInputFromAlert, dbrecoveryanswer;
    String userloginname;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        try {
            getUsernamesFromDB();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        loadButtonActions();

    }

    //loading button Actions
    private void loadButtonActions() {
        forgotpasswordbtn.setOnAction(e -> {
            FarmerRegistrationAlertBox.getUserName("Enter Username and Press Okey");
        });

        loginbtn.setOnAction(e -> {
            try {
                loginUser();
            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
        });

        registerviewbtn.setOnAction(e-> new FarmerRegistrationView().display("Register")
        );
        adminviewbtn.setOnAction(e->{
            FarmerLoginView.closeWindow();
           // new AdminLoginView().display("Admin Login");
            new AdminLoginView().display("Admin Login");
        } );
        refreshbtn.setOnAction(e->{
            FarmerLoginView.closeWindow();
            new FarmerLoginView().display("Farmer Login");
        });

    }


    //get user login input
    private void getUserLoginInput() {
      String usernametxt = loginusernamecb.getValue().toString();

              String userpasswordtxt =loginpasswordtxt.getText();
        try {
            if(usernametxt!= "" && userpasswordtxt != ""){
                if(usernametxt!= null && userpasswordtxt != null){
                    try{ Integer.parseInt(usernametxt);
                        Double.parseDouble(usernametxt);
                        FarmerRegistrationAlertBox.dataerror("No numbers accepted");
                    }
                    catch(Exception e){
                        getUsernamePasswordInput(loginusernamecb.getValue().toString(),loginpasswordtxt.getText());
                    }
                }
                else{
                    FarmerRegistrationAlertBox.dataerror("No null values");
                }
            }else{
                FarmerRegistrationAlertBox.dataerror("Fill in all Fields");
            }

        } catch (Exception e) {
            FarmerRegistrationAlertBox.dataerror("Input Your Details");
        }
    }

    private void getUsernamePasswordInput(String Username,String Password) throws SQLException, ClassNotFoundException {
        this.username = Username;
        this.password = DigestUtils.md5Hex(Password);
        authenticateuser(username, password);
    }


    //fetching username and password from db
    private void fetchUserDetails(String Username) throws SQLException {
        do1 = new DBConnection();
        Connection con = do1.connect();
        String query = "SELECT username,password,farmerid  FROM farmer_users where username ='" + Username + "'";

        ResultSet rs = con.createStatement().executeQuery(query);


        if (rs.next()) {
            this.dbUsername = rs.getString(1);
            this.dbPassword = rs.getString(2);
            this.farmerid= rs.getInt(3);

        } else {
            FarmerRegistrationAlertBox.dataerror("User Name Not Registered");
        }
        con.close();

    }

    //validate and authenticate user
    private String authenticateuser(String username, String password) throws SQLException, ClassNotFoundException {
        fetchUserDetails(username);

         if (username.equals(dbUsername) && password.equals(dbPassword)) {

            FarmerLoginView.closeWindow();
            this.userloginname = username;

            new FarmerLoginDetails(username,farmerid,password);
           MainView mainView =  new  MainView();
            mainView.display(username + " Farmsystem");

        } else if (username.equals(dbUsername) && !password.equals(dbPassword)) {
            FarmerRegistrationAlertBox.dataerror("Wrong Password");
        } else {
            FarmerRegistrationAlertBox.dataerror("Input correct credentials");
        }
        new FarmerRegistrationDetails(userloginname);
        return userloginname;
    }

    //Login user
    //set login cb.
    private void getUsernamesFromDB() throws SQLException {

        ObservableList usernames = FXCollections.observableArrayList();
        do1 = new DBConnection();
        Connection con = do1.connect();
        String query = "SELECT username  FROM farmer_users";
        ResultSet rs = con.createStatement().executeQuery(query);

            while (rs.next()) {
                usernames.add(rs.getString(1));
        }

        loginusernamecb.getItems().addAll(usernames);
    }


    private void loginUser() throws SQLException, ClassNotFoundException {
        getUserLoginInput();
    }


    //get recovery question
    private void getrecoveryquestionfromdb(String Username) throws SQLException {
        do1 = new DBConnection();
        Connection con = do1.connect();
        String query = "SELECT username,recoveryquestion FROM farmer_users where username ='" + Username + "'";
        System.out.println(query);

        ResultSet rs = con.createStatement().executeQuery(query);
        if (rs.next()) {
            while (rs.next()) {
                dbUsername = rs.getString(1);
                dbrecoveryquestion = rs.getString(2);
            }
        }
    }


    //check user input
    private void getusernamefromuser() {
        UsernameInputFromAlert = FarmerRegistrationDetails.getUsername();
        System.out.println(UsernameInputFromAlert);
    }


    //disabling login site
    private void disableLoginView() {
        loginpasswordtxt.isDisabled();
        loginusernamecb.isDisabled();
        loginbtn.isDisabled();

    }


    //Logout user
    private void logoutUser() {

    }

    //recover passwords
    public void recoverPassword() throws SQLException {
        //getting username
        getusernamefromuser();
        getrecoveryquestionfromdb(UsernameInputFromAlert);
        FarmerRegistrationAlertBox.closeWindow1();

        //getting recovery question from database
        // AdminLoginAlertBox.recoverAccount(dbrecoveryquestion);
        String recoveryanswer = FarmerRegistrationAlertBox.recoveryAnswerInput;
        FarmerRegistrationAlertBox.closeWindow1();
        if (recoveryanswer.equals(dbrecoveryanswer)) {
            FarmerRegistrationAlertBox.dataerror("You must set a new password");
            new FarmerRegistrationView();
            disableLoginView();
        } else {
            FarmerRegistrationAlertBox.dataerror("This is not the correct answer!");
        }


    }

    //updating password after recovery
    private void validateUserPasswords() {

    }


    private void updatePassword() throws SQLException {
        getusernamefromuser();
        //disablePartlyRegistrationView();

        String insertQuery = "UPDATE registration  SET password = '" + password + "'WHERE username ='" + UsernameInputFromAlert + "'";

        do1 = new DBConnection();
        Connection conn = do1.connect();
        Statement statement = conn.prepareStatement(insertQuery);
        statement.execute(insertQuery);
    }


}





          /*
           registerbtn.setOnAction(e-> {
                try {
                    storeUserRegistrationDetails();
                } catch (SQLException | ClassNotFoundException throwables) {
                    throwables.printStackTrace();
                }
            });



           saveRecoveryItemsbtn.setOnAction(e-> {
                try {
                    storeRecoveryQuestionAndAnswer();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            });*/

       /* //get user registrationinput
        private void getUserRegistrationInput(){
            firstname =fnametxt.getText();
            lastname=lnametxt.getText();
            username = usernametxt.getText();
            password = passwordtxt.getText();
            confirmpassword=confirmpasswordtxt.getText();
            month = LocalDate.now().getMonth().toString();
            year = LocalDate.now().getYear();

            System.out.println(password);System.out.println(confirmpassword);
        }

        //Setting recovery questions
        private void recoveryquestions(){
            recoveryquestions = FXCollections.observableArrayList();
            String question1= "What is the name of your favourite pet";
            String question2 = "What is your favourite cows name";
            String question3 ="Which was your favourite year";
            String question4 ="What was the name of your primary School";

            recoveryquestions.addAll(question1,question2,question3,question4);

        }


        //Setting recovery combobox
        public void setRecoveryquestioncb() {
            recoveryquestions();
            recoveryquestioncb.setItems(recoveryquestions);
        }




        // get recovery  details input
        private void getRecoveryInput(){
            recoveryquestion = recoveryquestioncb.getValue().toString();
            recoveryanswer = recoveryanswertxt.getText();
        }

        //store registration Details
        private String   storeUserRegistrationDetails() throws SQLException, ClassNotFoundException {
            getUserRegistrationInput();
            createdatabase(username);

            getusernamefromuser();
            String updatecheckquery = "SELECT (username) FROM registration where username ='" + UsernameInputFromAlert + "'";


            do1 = new DBConnection();
            if (UsernameInputFromAlert != "" || UsernameInputFromAlert != null) {
                Connection con = do1.connecttoDB("registration");
                ResultSet rs = con.createStatement().executeQuery(updatecheckquery);

                if (rs.next()) {
                    updatePassword();
                } else {
                    String query = "insert into registration(firstname,lastname,username,password,recoveryquestion,recoveryanswer,month,year) values('" + firstname + "','" + lastname + "','" + username + "','" + password + "','" + recoveryquestion + "','" + recoveryanswer + "','" + month + "','" + year + "') ";
                    if (password != null ||password != "" && password.equals(confirmpassword)) {

                        con.createStatement().execute(query);
                        con.close();
                        System.out.println(username+"farmsystem");
                        new CreateDatabase().performdbCreation(username+"farmsystem");
                    } else {
                        AdminLoginAlertBox.dataerror("Passwords are not the same");
                    }
                }
            }
            userloginname = username;
            System.out.println(userloginname);        new AdminRegistrationDetails(userloginname);
            return userloginname;

        }
        //store recoveryQuestion and answer to db
        private void storeRecoveryQuestionAndAnswer() throws SQLException {

            getUserRegistrationInput();
            getRecoveryInput();
            do1 =new DBConnection();
            String updateQuery = "UPDATE registration  SET recoveryquestion = '"+recoveryquestion+"',recoveryanswer = '"+recoveryanswer+"' WHERE username ='"+username+"'";

            Connection conn =do1.connecttoDB("registration");
            Statement statement = conn.prepareStatement(updateQuery);
            statement.execute(updateQuery);

        }
*/


        /*
        //Disabling registration site
        private void disableRegistrationView(){
            fnametxt.isDisabled();
            lnametxt.isDisabled();
            usernametxt.isDisabled();;
            passwordtxt.isDisabled();;
            confirmpasswordtxt.isDisabled();;
            recoveryquestioncb.isDisabled();;
            recoveryanswertxt.isDisabled();;
            registerbtn.isDisabled();
        }

        //disabling registration for updating password
        private void disablePartlyRegistrationView(){
            getusernamefromuser();
            registerbtn.setText("Update");
            fnametxt.isDisabled();
            lnametxt.isDisabled();
            usernametxt.setText(UsernameInputFromAlert);
            recoveryquestioncb.isDisabled();;
            recoveryanswertxt.isDisabled();;
            registerbtn.isDisabled();
        }
*/


