package sample.Farmer.Home.Farmer;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;

import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;


import sample.DatabaseConnections.CreateDBTables.CreateDatabase;
import sample.DatabaseConnections.DBConnection;
import sample.Farmer.Chatroom.ViewPosts.PostsView;
import sample.Farmer.Expenses.Farmer.ExpensesView;
import sample.Farmer.Fertilizer.Farmer.FertilizerView;
import sample.Farmer.Login.Farmer.FarmerLoginDetails;
import sample.Farmer.Login.Farmer.FarmerLoginView;
import sample.Farmer.Profit.ProfitView;
import javafx.scene.image.ImageView;

import sample.Farmer.Sales.Farmer.SalesView;
import sample.Farmer.Seedlings.Farmer.SeedlingsView;
import sample.Images.ImageDetails;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;


public class MainViewController implements Initializable {


    @FXML
    private ComboBox<Integer> yearselectcb;

    @FXML
    private ComboBox<String> monthselectcb;

    @FXML
    private MenuBar file;

    @FXML
    private MenuItem logoutmi;

    @FXML
    private MenuItem refreshmi;

    @FXML
    private Label datelb;

    @FXML
    private HBox linechartHBox;

    @FXML
    private Button tealeavesbtn;

    @FXML
    private Button fertilizerbtn;

    @FXML
    private Button Expensesbtn;

    @FXML
    private Button seedlingsbtn;

    @FXML
    private Button chatroombtn;

    @FXML
    private Button salesbtn;

    @FXML
    private Button profitbtn;


    @FXML
    private Circle imagecircle;

    @FXML
    private Label useramelabel;

    @FXML
    private Button changeprofilebtn;

    @FXML
    private ListView<?> fertilizerlv;

    @FXML
    private ListView<?> seedlingslv;

    @FXML
    private ListView<?> teasaleslv;


    @FXML
    private Label profitlb;

    @FXML
    private Label expenselb;

    @FXML
    private Label saleslb;



    ObservableList distinctdates,nextTreatmentDates,requiredFeedsData,distinctfeeds,monthsOfData;

    CreateDatabase dbcreater;
    DBConnection do1;


    String month,today,username;
    int dayOfMonth, dayOfYear, year;
    int farmerid;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        do1 = new DBConnection();
      this.farmerid = FarmerLoginDetails.getUserid();
      this.username = FarmerLoginDetails.getUsername();
      useramelabel.setText(username);

        getDateTime();
        loadButtonActions();
        setdatelabel();
        setComboboxes();

        try {
            setprofilepic(farmerid);
            setData( year,  month);
            getRequiredfertilizer();
            getRequiredSeedlings();

        } catch (SQLException | MalformedURLException throwables) {
            throwables.printStackTrace();
        }

    }

    //profile image





    //set date labels
    private void setdatelabel() {
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("E,MMM dd yyyy");
        String formattedDate = myDateObj.format(myFormatObj);
        datelb.setText(formattedDate);
    }


    //Button Actions
    public void loadButtonActions() {
        salesbtn.setOnAction(e -> new SalesView().display("Sales"));
        profitbtn.setOnAction(e -> new ProfitView().display("Profits"));
        seedlingsbtn.setOnAction(e -> new SeedlingsView().display("Seedling Orders"));
      Expensesbtn.setOnAction(e -> new ExpensesView().display(" Expenses"));
     fertilizerbtn.setOnAction(e -> new FertilizerView().display("Fertilizer"));
        chatroombtn.setOnAction(e-> new PostsView().display("Post Messages"));
        changeprofilebtn.setOnAction(e-> {
                    try {
                        changeprofile();
                    } catch (MalformedURLException | SQLException malformedURLException) {
                        malformedURLException.printStackTrace();
                    }
                }
        );

        monthselectcb.setOnAction(e -> {
            try {
                getSelectedmonthdata();
            } catch (SQLException throwables) {
                try {
                    getSelectedyeardata();
                } catch (SQLException sqlException) {
                    sqlException.printStackTrace();
                }
                throwables.printStackTrace();
            }
        });
        yearselectcb.setOnAction(e-> {
            try {

                monthselectcb.setValue("");
                getSelectedyeardata();
                selectMonthsFromDB();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });


        refreshmi.setOnAction(e->refresh());
        logoutmi.setOnAction(e->logout());
    }

    //Logout
    private void logout(){

        MainView.closeWindow();
       new FarmerLoginView().display("Farmer Login");
    }

    //Refresh
    private void refresh(){

        MainView.closeWindow();
        new MainView().display("Tea Farm Management");
    }

    //set comboboxes
    private void setComboboxes(){
        try {
            setYearselectcb( "farmersales");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        selectMonthsFromDB();


    }



    public Month getDateTime() {
        LocalDate currentDate = LocalDate.now();
        DayOfWeek dow = currentDate.getDayOfWeek();
        int dom = currentDate.getDayOfMonth();
        int doy = currentDate.getDayOfYear();
        Month m = currentDate.getMonth();
        year = currentDate.getYear();
        month = m.toString();
        today = currentDate.now().toString();


        this.dayOfMonth = dom;
        this.dayOfYear = doy;

        return m;
    }

    //getting distinct dates from db
    //getting distinct dates from db
    //getting months of data

    private void setYearselectcb(String Database) throws SQLException {
        ObservableList distinctyears =FXCollections.observableArrayList();
        Connection conn = do1.connect();
        String query = "Select distinct(year) from "+Database;
        System.out.println(query);
        ResultSet rs = conn.createStatement().executeQuery(query);
        while (rs.next()) {
            distinctyears.add(rs.getInt(1));
        }
        rs.close();
        conn.close();
        yearselectcb.getItems().addAll(distinctyears);

    }

    private void selectMonthsFromDB() {

        distinctdates = FXCollections.observableArrayList();
        distinctdates.addAll("January","February", "March", "April", "May" ,
                "June","July" , "August","September","October", "November","December"
        );

        setMonthSelectcb(distinctdates);
    }
    //adding months of data to combobox
    private void setMonthSelectcb(ObservableList monthlist){
        monthselectcb.setItems(monthlist);
    }


    //getting selected time data
    //getting selected month data
    private void getSelectedmonthdata() throws SQLException {


        try{
            int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
            String  selectedMonth = monthselectcb.getValue().toString();
            setData(selectedyear,selectedMonth);
        }
        catch(Exception e){

            int selectedyear = this.year;
            String  selectedMonth = monthselectcb.getValue().toString();
            setData(selectedyear,selectedMonth);

        }
    }


    //getting selected year data
    private void getSelectedyeardata() throws SQLException {


        try{
            int selectedyear = Integer.parseInt(yearselectcb.getValue().toString());
            setYearlydata( selectedyear);
        }
        catch(Exception e){

            int selectedyear = this.year;
            setYearlydata( selectedyear);
        }
    }



    //setting homeviewdata
    private void setData(int year, String month) throws SQLException {

        // labels
        setMonthlyLabels(year,month);
        //set List Views
        getListViews( year,  month);
    }


    //setting profile photo
    private void setprofilepic(int farmerid) throws SQLException, MalformedURLException {
        imagecircle.setStroke(Color.SEAGREEN);
        String profilename = "noprofile.jpg";
        String query = "Select profilephoto from farmer_users  where farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        ResultSet  rs = con.createStatement().executeQuery(query);
        if(rs.next()){
            if(!rs.getString(1).equals("")){
          profilename = rs.getString(1);}
            else{
                profilename = "noprofile.jpg";
            }
        }else if(!rs.next()){
            profilename = "noprofile.jpg";
        }
        else{
            profilename = "noprofile.jpg";
        }
        rs.close();
        con.close();
        System.out.println(profilename);
        File file ;
        Image image;
        if(profilename != " ") {

           file = new File("src\\sample\\Farmer\\Home\\Farmer\\Profiles\\profilesImages\\" + profilename);
        }
        else{
            file = new File("src\\sample\\Farmer\\Home\\Farmer\\Profiles\\profilesImages\\noprofile.jpg");
        }

        image = new Image(file.toURI().toURL().toExternalForm());
        imagecircle.setFill(new ImagePattern(image));
    }

    //change profile
    private File changeprofile() throws MalformedURLException, SQLException {
        FileChooser fileChooser = new FileChooser();
        File profilepic =fileChooser.showOpenDialog(null);

        Image image = new Image(profilepic.toURI().toURL().toExternalForm());
        imagecircle.setFill(new ImagePattern(image));


        //copying file
        File newfile = null;

        try{
            newfile = new File("src\\sample\\Farmer\\Home\\Farmer\\Profiles\\profilesImages\\" + profilepic.getName());
            System.out.println("Created");
        }
        catch(Exception ex1){
            System.out.println("cannot create file");
        }
        try{
            System.out.println(newfile.toPath());
            Files.copy(profilepic.toPath(), newfile.toPath());

            System.out.println("Copied");
        }catch (Exception copyex) {
            copyex.printStackTrace();
            System.out.println("cannot copy");
            if (profilepic.exists()) {
                File filefolder = new File("src\\sample\\Farmer\\Home\\Farmer\\Profiles\\profilesImages");


            }

        }
        updateprofilepic(profilepic.getName(), farmerid);
                return profilepic;
    }
    // update profile pic
    private void updateprofilepic(String profilepic,int farmerid) throws SQLException {

        String query = "update  farmer_users set profilephoto = '"+profilepic+"' where farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        Statement stat = con.prepareStatement(query);
        stat.execute(query);
        stat.close();
        con.close();
    }


    //getting year data

    // setting yearly graph data

    private void setYearlydata(int year) throws SQLException {
        setYearlyLabels( year);
    }
    //setting monthly data



    //setting listviews

    //setting listviews
    private void getListViews(int year, String month) {
        try {
         ;
            getRequiredfertilizer( );
            getRequiredSeedlings();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }

    //getting ordered fertilizer
    private ObservableList getRequiredfertilizer() throws SQLException {
        ObservableList<String> requiredfertlist = FXCollections.observableArrayList();
        String query = "Select fertilizertype, fertilizeramount from fertilizerorders where farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            requiredfertlist.addAll(rs.getString(1) + " Amount " + rs.getString(2));
        }
        setRequiredfertilizerlv(requiredfertlist);
        return requiredfertlist;
    }

    //setting required fertilizer lv
    private void  setRequiredfertilizerlv(ObservableList  brokenmachinerylist){
        fertilizerlv.setItems(brokenmachinerylist);

    }



    //getting required fertilizer
    private ObservableList getRequiredSeedlings() throws SQLException {
        ObservableList<String> requiredSeedlinglist = FXCollections.observableArrayList();
        String query = "Select seedlingtype,seedlingamount from seedlingsorders where farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            requiredSeedlinglist.addAll(rs.getString(1) + " Amount  " + rs.getString(2));
        }
        setSeedlingslv(requiredSeedlinglist);
        return requiredSeedlinglist;
    }

    //setting required fertilizer lv
    private void  setSeedlingslv(ObservableList brokenmachinerylist){
        seedlingslv.setItems(brokenmachinerylist);

    }





    // Labels
    double sales=0,expenses=0;
    //setting monthly labels
    private void setMonthlyLabels(int year, String month) throws SQLException {
        getSales(year,  month);
        getExpenses( year,  month);
        getProfit( sales,  expenses);

    }

    //set monthly sales lb
    private double getSales(int year, String month) throws SQLException {
        double sales = 0;
        String query = "Select SUM(price) from farmersales where year = '"+year+"' && month = '"+month+"' && farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            sales = rs.getDouble(1);
        }
        setSaleslb(String.valueOf(sales));
        this.sales = sales;
        return sales;
    }

    //setting sales label
    private void setSaleslb(String sales){
        saleslb.setText(sales);
    }


    //setting expenses
    private double getExpenses(int year, String month) throws SQLException {
        double expenses = 0;
        String query = "Select SUM(cost) from farmerexpenses where year = '"+year+"' && month = '"+month+"' &&farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            expenses = rs.getDouble(1);
        }
        setExpenseslb(String.valueOf(expenses));
        this.expenses=expenses;
        return expenses;
    }

    //setting expense label
    private void setExpenseslb(String expenses){
        expenselb.setText(expenses);
    }

    //get profit
    private double getProfit(double Sales, double Expenses){
        double profit = Sales - Expenses;
        setProfitlb(String.valueOf(profit));
        return profit;
    }

    //setting profit label
    private void setProfitlb(String profit){
        profitlb.setText(profit);
    }

    // set yearly labels
    private void setYearlyLabels(int year) throws SQLException {
        getYearSales(year);
        getYearExpenses(year);
        getYearProfit( sales,  expenses);

    }

    //set monthly sales lb
    private double getYearSales(int year) throws SQLException {
        double sales = 0;
        String query = "Select SUM(price) from farmersales where year = '"+year+"' && farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            sales = rs.getDouble(1);
        }
        setYearSaleslb(String.valueOf(sales));
        this.sales = sales;
        return sales;
    }

    //setting sales label
    private void setYearSaleslb(String sales){
        saleslb.setText(sales);
    }


    //setting expenses
    private double getYearExpenses(int year) throws SQLException {
        double expenses = 0;
        String query = "Select SUM(cost) from farmerexpenses where year = '"+year+"' && farmerid = '"+farmerid+"'";
        Connection con = do1.connect();
        ResultSet rs = con.createStatement().executeQuery(query);
        while(rs.next()){
            expenses = rs.getDouble(1);
        }
        setYearExpenseslb(String.valueOf(expenses));
        this.expenses=expenses;
        return expenses;
    }

    //setting expense label
    private void setYearExpenseslb(String expenses){
        expenselb.setText(expenses);
    }

    //get profit
    private double getYearProfit(double Sales, double Expenses){
        double profit = Sales - Expenses;
        setYearProfitlb(String.valueOf(profit));
        return profit;
    }

    //setting profit label
    private void setYearProfitlb(String profit){
        profitlb.setText(profit);
    }






}
















