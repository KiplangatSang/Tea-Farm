package sample.DatabaseConnections;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    public Connection connect(){
        try {

            String  url ="jdbc:mysql://localhost:3306/teafarm";
            String user ="root";
            String  password ="";

            Class.forName("com.mysql.jdbc.Driver");
            Connection conn =(Connection) DriverManager.getConnection(url,user,password);

            return  conn;

        } catch (ClassNotFoundException | SQLException e) {
           System.out.println("no connection");
        }
        return null;
    }
}
