package sample.DatabaseConnections.CreateDBTables;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import sample.DatabaseConnections.DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class CreateDBTables {
    ObservableList tablesqlqueries;
    String RegistrationTableQuery;

    public void createdatabasetables() throws SQLException, ClassNotFoundException {
        setRegistrationTablesqlqueries();
        createRegistrationTables(RegistrationTableQuery,"Registration");

    }
    public void createdatatables( String Database) throws SQLException, ClassNotFoundException {
        createTablesqueries();
        System.out.println("creating tables");
        createDBTables(Database,tablesqlqueries);
    }


   private void createRegistrationTables(String sqlQuery,String databasename) throws SQLException, ClassNotFoundException {
       String  url ="jdbc:mysql://localhost:3306/" + databasename ;
       String user ="root";
       String  password ="";
       Class.forName("com.mysql.jdbc.Driver");
       Connection conn =(Connection) DriverManager.getConnection(url,user,password);
       Statement statement = (Statement)conn.prepareStatement(sqlQuery);
       statement.execute(sqlQuery);
       statement.close();
       conn.close();

   }
private void setRegistrationTablesqlqueries(){
    RegistrationTableQuery ="Create TABLE registration(id int not null AUTO_INCREMENT,firstname varchar(255),lastname varchar(255),username varchar(255),password varchar(255),recoveryquestion varchar(255) ,recoveryanswer varchar(255),month varchar(255), year int,PRIMARY KEY(id) )";

}
    private ObservableList createTablesqueries(){

        tablesqlqueries= FXCollections.observableArrayList();

     //   String createCalvingtable = "create table calvingdata(id int not null AUTO_INCREMENT ,cowname varchar(255), cowid int, dateofcalving varchar(255),lactatingdays int ,noofcalves int ,month varchar(255),year int,PRIMARY KEY(id,cowname,cowid,dateofcalving))";
      //  String createServicetable = "create table servingdata(id int not null AUTO_INCREMENT,cowname varchar(255), cowid int,cost double, dateserved varchar(255),daysafterserving int ,daysremaining int ,month varchar(255),year int,PRIMARY KEY(id,cowname,cowid));";

        // String createmilkpricestable = "create table milkprices(id int not null AUTO_INCREMENT,month varchar(255), price double, year int, PRIMARY KEY(id,month,year))";
       // String createdewormingdatatable ="create table dewormingdata(id int not null AUTO_INCREMENT, lastDewormingDay varchar(255),duration int,year int,primary KEY(id))";
       // String createfeedstable ="create table feeds(id int not null AUTO_INCREMENT, feedtype varchar(255), feedamount double,rate double,highlyrequiredtorefill varchar(255),projectedDayOfExhaustion varchar(255),lastupdate varchar(255),daysremaining int,price double,month varchar(255),year int,primary KEY(id))";
      //  String createmilkdetailstable ="create table milkdetails(id int not null AUTO_INCREMENT, cowID int,cowName varchar(255), morningAmount double,noonAmount double,eveningAmount double,dayTotal double,monthlyTotal double,yearTotal double,Date varchar(255),month varchar(255),dayOfMonth int,dayOfYear int,dateMilked varchar(255),year int,primary KEY(id))";
     //   String createsprayingdatatable ="create table sprayingdata(id int not null AUTO_INCREMENT, lastSprayDay varchar(255),sprayDuration int,year int,primary KEY(id))";
      //  String createtreatmenttatable ="create table treatment(id int not null AUTO_INCREMENT, treatment varchar(255),cowid int, cowname varchar(255), cost double,vet varchar(255),Date varchar(255),nextTreatment varchar(255),month varchar(255), year int,primary KEY(id))";
     //   String cowsdata ="create table cowsdata( name varchar(255),cowID int,age double,breed varchar(255),Gender varchar(255),Milked varchar(255),numberOfCalves varchar(255),parent varchar(255), dateEntered varchar(255), month varchar(255),year int)";



        String createMachinerytable = "create table Machinery(id int not null AUTO_INCREMENT, machinename varchar(255),regNo int,dateRegistered varchar(255),status varchar(255),statusUpdate varchar(255),expense double,income double,month varchar(255), year int, PRIMARY KEY(id,machinename,regNo));";
        String createsalestable = "create table sales(id int not null AUTO_INCREMENT, item varchar(255),price double,month varchar(255), year int,PRIMARY KEY(id,item))";
        String createemployeedatatable = "create table employeedata(id int not null AUTO_INCREMENT,empname varchar(255),empid int,empage int,empgender varchar(255),empsalary double,empdepartment varchar(255),dateemployed varchar(255) ,year int,PRIMARY key(id,empname,empid))";
        String createprofittable ="create table profit(id int not null AUTO_INCREMENT, internalexpenses double,externalexpenses double,sales double ,profit double ,profitpercentage double,month varchar(255) ,year int,primary KEY(id))";
        String createinternalCoststable = "create table expenses(id int not null AUTO_INCREMENT, workdone varchar(255),cost double,datepaid varchar(255),month varchar(255), year int, PRIMARY KEY(id));";
        String fertilizertable = "create table fertilizer(id int AUTO_INCREMENT not null ,Type varchar(255),amount double,pricePerSack double,dateApplied varchar(255),dateEntered varchar(255),month varchar(255),year int, PRIMARY KEY(id ,type))";
        String createCowSalestable = "create table cowsales(id int AUTO_INCREMENT not null,cowid int ,cowname varchar(255),gender varchar(255),age int,breed varchar(255),milked varchar(255),numberOfCalves int,price double,parent varchar(255),dateEntered varchar(255),date varchar(255),month varchar(255),year int, PRIMARY KEY(id ,cowid,cowname))";



        tablesqlqueries.addAll(createCowSalestable,createinternalCoststable,createsalestable,createemployeedatatable,createprofittable);
        return tablesqlqueries;
    }

    private void createDBTables(String Database,ObservableList sqlqueries){

        sqlqueries.forEach((query)->{
            try {
                DBConnection do1 = new DBConnection();
                Connection conn = do1.connect();
               String tablequery = (String) query;
                Statement statement = (Statement)conn.prepareStatement(tablequery);
                statement.execute(tablequery);
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        });

    }
}
