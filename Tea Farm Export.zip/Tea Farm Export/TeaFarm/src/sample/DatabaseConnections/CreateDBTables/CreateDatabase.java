package sample.DatabaseConnections.CreateDBTables;

import java.sql.*;

public class CreateDatabase {
    private static boolean answer;

    public static String performdbCreation(String databaseName) throws SQLException, ClassNotFoundException {
        String success = "database has been created by creator method";
        checkifdbExists(databaseName);
        String  databasepresent = String.valueOf(answer);

        System.out.println(answer + " in performdbCreation method");
             if(databasepresent == "false"){

                // createdatabase(databaseName);
                // System.out.println("Database never exists");

             }
             else if(databasepresent == "true"){
                // System.out.println("Database exists and is functional");
             }
    return success;
    }


    public static void checkifdbExists(String databaseName) {
        //tablescreation = new CreateDBTables();
        Connection con;
        ResultSet rs = null;

        String url = "jdbc:mysql://localhost:3306/";
        String user = "root";
        String password = "";

        try {

            Class.forName("com.mysql.jdbc.Driver");

            con = DriverManager.getConnection(url, user, password);

            //String dbName = "farmsystem1";
            //String registrationDbtxt= "Registration";

            if (con != null) {

                System.out.println("check if a database exists" + databaseName);

                rs = con.getMetaData().getCatalogs();
                if (rs.next()) {
                    while (rs.next()) {

                        String catalogs = rs.getString(1);
                        System.out.println("connection created to " +catalogs);

                        checkdbname(catalogs,databaseName);
                        if(answer== true){
                            break;
                        }
                        else{
                            if(!rs.next()){
                                checkdbname(catalogs,databaseName);
                            }
                        }

                        System.out.println(answer);
                    }

                    }
                else{
                   // createdatabase(databaseName);

                }
                rs.close();
                con.close();
                }
            }
        catch(Exception ex){
            ex.printStackTrace();
        }


    }

    private static boolean checkdbname(String catalogs, String dbname){
        if(catalogs.equals(dbname)){
            answer = true;
            return  answer;
        }
        else {
            answer = false;
            return  answer;
        }
    }


    private static void createdatabase(String databaseName) throws SQLException, ClassNotFoundException {
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost/";
        //  Database credentials
        String USER = "root";
        String PASS = "";

        Connection conn = null;
        Statement stmt = null;

       // String Database = "farmsystem1";

        //STEP 2: Register JDBC driver
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        //STEP 3: Open a connection
        System.out.println("Connecting to database...");
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            //STEP 4: Execute a query
            System.out.println("Creating database...");
            stmt = conn.createStatement();
            String querry = "CREATE DATABASE " + "" + databaseName;
            System.out.println(querry);
            String sql = querry;
            stmt.executeUpdate(sql);
            System.out.println("Database created successfully...");

            stmt.close();
            conn.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        CreateDBTables tablescreation = new CreateDBTables();

        //tablescreation.createdatabasetables();
        tablescreation.createdatatables(databaseName);

    }


}
